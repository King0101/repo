package com.test.academy;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Properties;

import javax.naming.AuthenticationException;
import javax.naming.AuthenticationNotSupportedException;
import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.DatatypeConverter;

//import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel. WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 * Servlet implementation class MyAcademy
 */
@WebServlet("/MyAcademy")
public class MyAcademy extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	
	public MyAcademy() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Servlet#getServletConfig()
	 */
	public ServletConfig getServletConfig() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String tempURI =  request.getRequestURI();
		Connection con = null;
		
		try
		{
			con= getConnection();
			
			if (con != null) 
			{
				//To verify the login credentials.
				if(tempURI.contains("getUserInfo")) 
				{
					getUserInfo(response, con);
				}
				
				//To get the calendar data available in Tbl_Training_Calendar table.
				else if (tempURI.contains("getSchdTrngInfo")) 
				{
					getScheduledTrainingInfo(response,con);
				}
				
				//To get the Existing Area available in Tbl_Training_Topics table.
				else if (tempURI.contains("getAvailableArea")) 
				{
					getAvailableAreaInfo(response,con);
				}
				//To get the Existing Streams available in Tbl_Employee_Details table.
				else if (tempURI.contains("getAvailableStreams")) 
				{
					getAvailableStreamsInfo(response,con);
				}
				else if(tempURI.contains("getAllDomains"))
				{
					getAllDomains(response,con);
				}
				else if (tempURI.contains("getAvailableFunctArea")) 
				{
					getAvailableFunctAreaInfo(response,con);
				}
				else if (tempURI.contains("getEmpSkillProfGraphData")) 
				{
					getEmpSkillProfGraphDataInfo(response,con);
				}
				else if (tempURI.contains("getAllTrainingDocs")) 
				{
					getAllTrainingDocs(response,con);
				}
				
			}			
			else // connection is null
			{
				response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
				response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
				response.setHeader("Expires", "0"); // Proxies.
				response.sendError(HttpServletResponse.SC_SERVICE_UNAVAILABLE);
			}			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
			response.sendError(HttpServletResponse.SC_FORBIDDEN);
		}
		
		if(con != null)
		{
			try
			{
				con.close();
			}
			catch(Exception e)
			{
				response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
				response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
				response.setHeader("Expires", "0"); // Proxies.
				response.sendError(HttpServletResponse.SC_FORBIDDEN);
				e.printStackTrace();
			}
		}
	}

	private void getAllTrainingDocs(HttpServletResponse response, Connection con) throws IOException {
		// To get all the document details uploaded into server
		JSONArray ArrayOfDocs = new JSONArray();
		try{
			String path = new File("/").getAbsolutePath();
			String absolutePath = path+"apache-tomcat-8.0.36/apache-tomcat-8.0.36/TelstraAcademyPortalDocs/TrainingCatalogue";
			File docs = new File(absolutePath);
			File[] list = docs.listFiles();
			for(int i=0; i<list.length; i++){
					JSONObject docsObj = new JSONObject();
					docsObj.put("Name", list[i].getName());
					double actsz = (double)list[i].length()/(double)1024;
					double sz = round(actsz,2);
					String len = sz+" KB";
					docsObj.put("Size",len);
					docsObj.put("Path", list[i].getAbsolutePath());
					Long lastmoddt = list[i].lastModified();
					Date mddt = new Date(lastmoddt);
					String dt = new SimpleDateFormat("dd-MM-yyyy").format(mddt);
					docsObj.put("Modifiedon",dt);
					ArrayOfDocs.add(docsObj);
				}
			response.setContentType("text/json");
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
			response.getWriter().write(ArrayOfDocs.toJSONString());
		}
		catch(Exception e){
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
			response.sendError(HttpServletResponse.SC_FORBIDDEN);
			e.printStackTrace();	
		}
	}

	private double round(double actsz, int i) {
		// TODO Auto-generated method stub
	    long factor = (long) Math.pow(10, i);
	    actsz = actsz * factor;
	    long tmp = Math.round(actsz);
	    return (double) tmp / factor;

	}

	private void getAllDomains(HttpServletResponse response, Connection con) throws IOException {
		// TO get all available Streams(Domains) from Tbl_Domain
		JSONArray allStreamArray = new JSONArray();		
		try
		{
			Statement stmt = con.createStatement();
				//SQL Query to get all the Training Area available from the Tbl_Training_Topics table 			
			ResultSet allstreamRS = stmt.executeQuery("select domain from Tbl_Domain order by domain");
				
			while(allstreamRS.next())
			{
				allStreamArray.add(allstreamRS.getString("domain"));
			}
			response.setContentType("text/json");
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
			response.getWriter().write(allStreamArray.toJSONString());  	//Response to send the Streams available in Employee Details table
			stmt.close();
		}
		catch(Exception e)
		{
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
			response.sendError(HttpServletResponse.SC_FORBIDDEN);
			e.printStackTrace();	
		}		
	}

	private void getEmpSkillProfGraphDataInfo(HttpServletResponse response, Connection con) throws IOException {
		// TODO Get Emp Skill Proficiency Details for Dash Board
		
		String[] proflist = {"Expert","Proficient","Intermediate","Basic","Not Applicable"};
		
		JSONArray dshbrdArray3 = new JSONArray();		
		try
		{
			Statement stmt = con.createStatement();
        	PreparedStatement prpdstmtdshbrd = null;
        	PreparedStatement prpdstmtdshbrd1 = null;
        	
			ResultSet dshBrdStreamRS = stmt.executeQuery("select distinct(Stream) as strm from Tbl_Employee_Details where Stream not in ('N/A','TBD') order by Stream");
			while(dshBrdStreamRS.next())
			{
				JSONArray dshbrdArray2 = new JSONArray();
				String dshBrdStream = dshBrdStreamRS.getString("strm");
				for(int i=0; i<5; i++)
				{
					String tempprof = proflist[i];
					JSONArray dshbrdArray1 = new JSONArray();

					//SQL Query to get the Skill set for a particular stream 
		        	String sqldshbrd1 = "select A.Skill_Name from Tbl_Skill_Set A inner join (select Skill_ID from Tbl_Proficiency where Stream = ? group by Skill_ID) as q1 on A.Skill_ID = q1.Skill_ID order by A.Skill_Name";
		        	prpdstmtdshbrd1 = con.prepareStatement(sqldshbrd1);
		        	prpdstmtdshbrd1.setString(1, dshBrdStream);
		        	ResultSet dshbrd1RS = prpdstmtdshbrd1.executeQuery();
		        	prpdstmtdshbrd1.clearParameters();
		        	while(dshbrd1RS.next())
		        	{
		        		JSONObject dshbrd1Obj1 = new JSONObject();
		        		String skilldshbd = dshbrd1RS.getString("Skill_Name");
			        	dshbrd1Obj1.put("x",skilldshbd);
						//SQL Query to get the Emp proficiency details for Dash Board 
			        	String sqldshbrd= "select COUNT(Proficiency) as cnt from Tbl_Proficiency where Stream = ? and Proficiency = ? and Last_Modified_Date is not null and Skill_ID in (select Skill_ID from Tbl_Skill_Set where Skill_Name=?) and Emp_ID in (select Emp_ID from Tbl_Employee_Details where Project = 'Telstra')";
			        	prpdstmtdshbrd = con.prepareStatement(sqldshbrd);
			        	prpdstmtdshbrd.setString(1, dshBrdStream);
			        	prpdstmtdshbrd.setString(2, tempprof);
			        	prpdstmtdshbrd.setString(3, skilldshbd);
			        	ResultSet dshbrdRS = prpdstmtdshbrd.executeQuery();
			        	prpdstmtdshbrd.clearParameters();
			        	if(dshbrdRS.next())
			        		dshbrd1Obj1.put("y",dshbrdRS.getInt("cnt"));
			        	else   	
			        		dshbrd1Obj1.put("y",0);
			        	dshbrdArray1.add(dshbrd1Obj1);
		        	}
		        	
		        	JSONObject dshbrdObj2 = new JSONObject();
		        	dshbrdObj2.put("key", tempprof);
		        	if(tempprof.equals("Expert"))
		        		dshbrdObj2.put("color", "green");
		        	else if(tempprof.equals("Proficient"))
		        		dshbrdObj2.put("color", "#52D017");
		        	else if(tempprof.equals("Intermediate"))
		        		dshbrdObj2.put("color", "yellow");
		        	else if(tempprof.equals("Basic"))
		        		dshbrdObj2.put("color", "red");
		        	else if(tempprof.equals("Not Applicable"))
		        		dshbrdObj2.put("color", "#ADD8E6");
		        	dshbrdObj2.put("values", dshbrdArray1);
		        	dshbrdArray2.add(dshbrdObj2);
				}
				JSONObject dshbrdObj3 = new JSONObject();
				dshbrdObj3.put("dshstream", dshBrdStream);
				dshbrdObj3.put("dshbrddata", dshbrdArray2);
				dshbrdArray3.add(dshbrdObj3);
			}
			response.setContentType("text/json");
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
			response.getWriter().write(dshbrdArray3.toJSONString());
			stmt.close();
		}
		catch(Exception e)
		{
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
			response.sendError(HttpServletResponse.SC_FORBIDDEN);
			e.printStackTrace();
		}
	}

	private void getAvailableFunctAreaInfo(HttpServletResponse response, Connection con) throws IOException {
		// To get all available Functional Area from the Training Topics Table
		JSONArray FunctAreaArray = new JSONArray();		
		try
		{
			Statement stmt = con.createStatement();
				//SQL Query to get all the Training Area available from the Tbl_Training_Topics table 			
			ResultSet FunctAreaRS = stmt.executeQuery("select distinct(Functional_Area) from Tbl_Training_Topics");
				
			while(FunctAreaRS.next())
			{
				JSONObject FunctAreaObj = new JSONObject();
				FunctAreaObj.put("functArea", FunctAreaRS.getString("Functional_Area"));
				FunctAreaArray.add(FunctAreaObj);
			}
			response.setContentType("text/json");
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
			response.getWriter().write(FunctAreaArray.toJSONString());  	//Response to send the Streams available in Employee Details table
			stmt.close();
		}
		catch(Exception e)
		{
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
			response.sendError(HttpServletResponse.SC_FORBIDDEN);
			e.printStackTrace();	
		}
	}

	private void getAvailableStreamsInfo(HttpServletResponse response, Connection con) throws IOException {
		JSONArray streamArray = new JSONArray();		
		try
		{
			Statement stmt = con.createStatement();
				//SQL Query to get all the Training Area available from the Tbl_Training_Topics table 			
			ResultSet streamRS = stmt.executeQuery("select distinct(Stream) from Tbl_Employee_Details where Stream not in ('N/A','TBD') order by Stream");
				
			while(streamRS.next())
			{
				JSONObject streamObj = new JSONObject();
				streamObj.put("stream", streamRS.getString("Stream"));
				streamArray.add(streamObj);
			}
			response.setContentType("text/json");
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
			response.getWriter().write(streamArray.toJSONString());  	//Response to send the Streams available in Employee Details table
			stmt.close();
		}
		catch(Exception e)
		{
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
			response.sendError(HttpServletResponse.SC_FORBIDDEN);
			e.printStackTrace();	
		}				
	}

	//Function to get all the existing Training Information from the table
	private void getAvailableAreaInfo(HttpServletResponse response, Connection con) throws IOException 
	{
		JSONArray areaArray = new JSONArray();
		
		try
		{
			Statement stmt = con.createStatement();
			//SQL Query to get all the Training Area available from the Tbl_Training_Topics table 			
			ResultSet areaRS = stmt.executeQuery("select distinct(Training_Area) as TrngArea, Functional_Area from Tbl_Training_Topics group by Training_Area, Functional_Area");
				
			while(areaRS.next())
			{
				JSONObject areaObj = new JSONObject();
				areaObj.put("area", areaRS.getString("TrngArea"));
				areaObj.put("functionalarea", areaRS.getString("Functional_Area"));
				
				areaArray.add(areaObj);
			}
			response.setContentType("text/json");
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
			response.getWriter().write(areaArray.toJSONString());  	//Response to send the topics available in topics table
			stmt.close();
		}
		catch(Exception e)
		{
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
			response.sendError(HttpServletResponse.SC_FORBIDDEN);
			e.printStackTrace();	
		}		
	}

	//Function to find all the scheduled training.
	private void getScheduledTrainingInfo(HttpServletResponse response, Connection con) throws IOException 
	{
		JSONArray schdTngArray = new JSONArray();
		
		try
		{
			Statement stmt = con.createStatement();
			
			//SQL Query to get the Scheduled Training details from the Tbl_Training_Calendar table.
			ResultSet schdTngRs = stmt.executeQuery("select q1.Training_Area, q1.Functional_Area, q1.Training_Topic_Name, q1.Planned_Date, q1.Planned_Hrs, q1.Start_Time, q1.Location, q1.Status, C.Emp_Name "
					+ "from (select A.Training_Topic_Name, A.Training_Area, A.Functional_Area, B.Planned_Date, B.Status, B.Planned_Hrs,B.Start_Time, B.Location, B.Trainer "
					+ "from  Tbl_Training_Topics A inner join Tbl_Training_Calendar B on B.Training_Topic_ID = A.Training_Topic_ID "
					+ "where B.Status <> 'Cancelled') as q1 inner join Tbl_Employee_Details C on q1.Trainer = C.Emp_ID");
			
			while(schdTngRs.next())
			{
				JSONObject schdTngObj = new JSONObject();
				schdTngObj.put("title", schdTngRs.getString("Training_Topic_Name"));
				schdTngObj.put("schdTrngArea", schdTngRs.getString("Training_Area"));
				schdTngObj.put("schdFuncArea", schdTngRs.getString("Functional_Area"));
				schdTngObj.put("start", schdTngRs.getString("Planned_Date"));
				schdTngObj.put("end", schdTngRs.getString("Planned_Date"));
				schdTngObj.put("starttime", schdTngRs.getString("Start_Time"));
				schdTngObj.put("schdTrngHrs", schdTngRs.getString("Planned_Hrs"));
				schdTngObj.put("schdTrngSts", schdTngRs.getString("Status"));
				schdTngObj.put("schdTrngLoc", schdTngRs.getString("Location"));
				schdTngObj.put("schdTrngTrnr", schdTngRs.getString("Emp_Name"));
				schdTngObj.put("className", "helloclass");
				
				schdTngArray.add(schdTngObj);
			}
			response.setContentType("text/json");
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
			response.getWriter().write(schdTngArray.toJSONString()); 	//Response to send the scheduled training details
			stmt.close();
		}
		catch(Exception e)
		{
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
			response.sendError(HttpServletResponse.SC_FORBIDDEN);
			e.printStackTrace();	
		}
	}

	//Function to find all the training topics
	private void getUserInfo(HttpServletResponse response, Connection con) throws IOException 
	{
		JSONArray topicArray = new JSONArray();
		
		try
		{
			Statement stmt = con.createStatement();
			//SQL Query to get all the Training Topics planned from the Tbl_Training_Topics table 			
			ResultSet topicRS = stmt.executeQuery("select Training_Topic_Name, Training_Area, Functional_Area from Tbl_Training_Topics order by Training_Topic_Name");
				
			while(topicRS.next())
			{
				JSONObject topicObj = new JSONObject();
				topicObj.put("topic", topicRS.getString("Training_Topic_Name"));
				topicObj.put("Area", topicRS.getString("Training_Area"));
				topicObj.put("FunctionalArea", topicRS.getString("Functional_Area"));
				topicArray.add(topicObj);
			}
			response.setContentType("text/json");
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
			response.getWriter().write(topicArray.toJSONString());  	//Response to send the topics available in topics table
			stmt.close();
		}
		catch(Exception e)
		{
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
			response.sendError(HttpServletResponse.SC_FORBIDDEN);
			e.printStackTrace();	
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doPut(req, resp);	
	}
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String tempUpdtURI =  request.getRequestURI();

		Connection con = null;
			try 
			{
				con= getConnection();
				
				if (con != null) 
				{
					//To verify the login credentials.
					if (tempUpdtURI.contains("loginurl"))
					{
						login(request, response, con);
					}
					
					//To fetch the Scheduled Training from database for Report generation.
					else if (tempUpdtURI.contains("getScheduledTrainingReporturl"))
					{
						scheduledTrainingReport(request, response, con);
					}
					
					//To fetch Training attendance for report generation.
					else if(tempUpdtURI.contains("getTrainingAttendanceReporturl"))
					{
						trainingAttendanceReport(request, response, con);						
					}
					
					//To fetch Training attendance Per Functional Area for report generation.
					else if(tempUpdtURI.contains("getAttendancePerFunctAreaRpturl"))
					{
						getAttendancePerFunctAreaRpt(request, response, con);						
					}
					
					//To select the planned Training for Register attendance. 
					else if(tempUpdtURI.contains("getrainingdateurl"))
					{
						getTrainingDate(request,response,con);
					}
						
					//To fetch the training information from the Tbl_Training_Calendar based on the Trainer Employee ID.
					else if(tempUpdtURI.contains("searchTrainingurl")) 
					{   
						getTrainingBasedOnTrainer(request,response,con);
					}
						
					//To update the training status to Tbl_Training_Calendar by the trainer.
					else if (tempUpdtURI.contains("UpdateCancelTrainingStatusurl"))
					{
						updateTrainingStatus(request,response,con);
					}
						
					//to add or update the training attendance in Tbl_Training_Attendance
					else if (tempUpdtURI.contains("AddUpdateRecordStatusurl"))
					{
						updateTrainingAttendance(request,response,con);
					}
						
					//To Insert new training schedules to Tbl_Training_Calendar.
					else if (tempUpdtURI.contains("InsertToCalendar")) 
					{
						insertTrainingToCalendar(request,response,con);
					}
					
					//To check the availability of Employee in Tbl_Employee_Details.
					else if (tempUpdtURI.contains("checkEmpAvailability")) 
					{
						checkEmpAvailability(request,response,con);
					}
					
					else if(tempUpdtURI.contains("searchEmployee"))
					{
						checkEmpAvailability(request,response,con);
					}
					
					//To insert employee details to Tbl_Employee_Details.
					else if (tempUpdtURI.contains("InsertToEmpDetails")) 
					{
						insertEmployeeDetails(request,response,con);
					}
					
					//To update employee details to Tbl_Employee_Details.
					else if (tempUpdtURI.contains("updateEmpDetails")) 
					{
						updateEmpDetails(request,response,con);
					}
					
					//To upload training schedules from an excel file to Tbl_Training_Calendar.
					else if (tempUpdtURI.contains("UploadDetails")) 
					{
						uploadTrainingDetails(request,response,con);
					}
					else if(tempUpdtURI.contains("AddNewTrainingurl"))
					{
						addNewTrainingDetails(request,response,con);
					}
					else if(tempUpdtURI.contains("getAvailableSkills"))
					{
						getAvailableSkillsDetail(request,response,con);
					}
					else if(tempUpdtURI.contains("SkillDelete"))
					{
						SkillDeleteDetail(request,response,con);
					}
					else if(tempUpdtURI.contains("SkillAdd"))
					{
						SkillAddDetail(request,response,con);
					}
					else if(tempUpdtURI.contains("getAvailableProficiency"))
					{
						getAvailableProficiencyDetail(request,response,con);
					}
					else if(tempUpdtURI.contains("ProficiencyAdd"))
					{
						ProficiencyAddDetail(request,response,con);
					}
					else if(tempUpdtURI.contains("getSkillCount"))
					{
						getSkillCountDetail(request,response,con);
					}
					else if(tempUpdtURI.contains("getEmpSkilHdr"))
					{
						getEmpSkillSummaryHdrDetail(request,response,con);
					}
					else if(tempUpdtURI.contains("getEmpSkillSummary"))
					{
						getEmpSkillSummaryDetail(request,response,con);
					}
					else if(tempUpdtURI.contains("getEmpSkillProfGraphDataperStrm"))
					{
						getEmpSkillProfGraphDataperStrm(request,response,con);
					}
					else if(tempUpdtURI.contains("downloadFile"))
					{
						downloadFile(request,response,con);
					}
				}
				else // connection is null
				{
					response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
					response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
					response.setHeader("Expires", "0"); // Proxies.
					response.sendError(HttpServletResponse.SC_SERVICE_UNAVAILABLE);
				}
				
			}
			catch(Exception e)
			{
				response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
				response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
				response.setHeader("Expires", "0"); // Proxies.
				response.sendError(HttpServletResponse.SC_FORBIDDEN);
				e.printStackTrace();
			}
			
			if(con != null)
			{
				try
				{
					con.close();
				}
				catch(Exception e)
				{
					response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
					response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
					response.setHeader("Expires", "0"); // Proxies.
					response.sendError(HttpServletResponse.SC_FORBIDDEN);
					e.printStackTrace();
				}
			}
		}
	
	private void downloadFile(HttpServletRequest request, HttpServletResponse response, Connection con) throws IOException, ParseException {
		// To read the data from file which needs to be downloaded

		String filepath = "";
		String filename = ""; 
		String extension = "";
        String flline = null;
		StringBuffer fileUrlPath = new StringBuffer();
        JSONObject fileDetObj = new JSONObject();
        JSONParser fparser = new JSONParser();
       	BufferedReader fileDtlreader = request.getReader();
       	flline = fileDtlreader.readLine();
       	fileUrlPath.append(flline);
 
        Object fobj = fparser.parse(fileUrlPath.toString());
        fileDetObj = (JSONObject) fobj;        
        filepath = (String)fileDetObj.get("url");
        filename = (String)fileDetObj.get("filename");
        int index = filename.indexOf(".");
        extension = filename.substring(index+1); 
        
        if(extension.equals("xlsx")){
        	 
    		//response.setContentType("APPLICATION/OCTET-STREAM"); 
    		response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
    		
    		response.setHeader("Content-Disposition","attachment; filename=\"" + filename + "\"");   
    		 
    		FileInputStream fileInputStream = new FileInputStream(filepath);
    		    		       
            Workbook workbook = new XSSFWorkbook(fileInputStream);
            
            ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
            workbook.write(outByteStream);

            byte[] outArray = outByteStream.toByteArray();
            OutputStream outStream = response.getOutputStream();
            outStream.write(outArray);
            outStream.flush();
            workbook.close();
        }
        else if(extension.equals("txt"))
        {
    		response.setContentType("text/html");  
    		PrintWriter out = response.getWriter();
    		response.setContentType("APPLICATION/OCTET-STREAM");
    		response.setHeader("Content-Disposition","attachment; filename=\"" + filename + "\"");   
    		FileInputStream fileInputStream = new FileInputStream(filepath);
    		int i;   
    		while ((i=fileInputStream.read()) != -1) {  
    			out.write(i);   
    		}
    		fileInputStream.close();
    		out.close(); 	
        }
	}

	private void getEmpSkillProfGraphDataperStrm(HttpServletRequest request, HttpServletResponse response,
			Connection con) throws IOException {
		// TODO Fetch Data for Skill Matrix Dash Board, based on the selected Stream
    	String StreamDsh = "";
		BufferedReader streamreader = request.getReader();
		StreamDsh = streamreader.readLine();
		
		String[] proflist = {"Expert","Proficient","Intermediate","Basic","Not Applicable"};
		
		JSONArray strdshbrdArray2 = new JSONArray();
		JSONArray strdshbrdArray3 = new JSONArray();
		try
		{
        	PreparedStatement prpdstmtdshbrdstr = null;
        	PreparedStatement prpdstmtdshbrdstr1 = null;

				for(int i=0; i<5; i++)
				{
					String tempprof = proflist[i];
					JSONArray strdshbrdArray1 = new JSONArray();
					//SQL Query to get the Skill set for a particular stream 
		        	String sqldshbrdstr1 = "select A.Skill_Name from Tbl_Skill_Set A inner join (select Skill_ID from Tbl_Proficiency where Stream = ? group by Skill_ID) as q1 on A.Skill_ID = q1.Skill_ID order by A.Skill_Name";
		        	prpdstmtdshbrdstr1 = con.prepareStatement(sqldshbrdstr1);
		        	prpdstmtdshbrdstr1.setString(1, StreamDsh);
		        	ResultSet dshbrdstr1RS = prpdstmtdshbrdstr1.executeQuery();
		        	prpdstmtdshbrdstr1.clearParameters();
		        	while(dshbrdstr1RS.next())
		        	{
		        		JSONObject dshbrdstr1Obj1 = new JSONObject();
		        		String skilldshbrd = dshbrdstr1RS.getString("Skill_Name");
		        		dshbrdstr1Obj1.put("x",skilldshbrd);
		        		//SQL Query to get the Emp proficiency details for Dash Board 
			        	String sqldshbrdstr= "select COUNT(Proficiency) as cnt from Tbl_Proficiency where Stream = ? and Proficiency = ? and Last_Modified_Date is not null and Skill_ID in (select Skill_ID from Tbl_Skill_Set where Skill_Name=?) and Emp_ID in (select Emp_ID from Tbl_Employee_Details where Project = 'Telstra')";
			        	prpdstmtdshbrdstr = con.prepareStatement(sqldshbrdstr);
			        	prpdstmtdshbrdstr.setString(1, StreamDsh);
			        	prpdstmtdshbrdstr.setString(2, tempprof);
			        	prpdstmtdshbrdstr.setString(3, skilldshbrd);
			        	ResultSet dshbrdstrRS = prpdstmtdshbrdstr.executeQuery();
			        	prpdstmtdshbrdstr.clearParameters();
			        	if(dshbrdstrRS.next())
			        		dshbrdstr1Obj1.put("y",dshbrdstrRS.getInt("cnt"));
			        	else			        		
			        		dshbrdstr1Obj1.put("y",0);
		        		strdshbrdArray1.add(dshbrdstr1Obj1);
		        	}
        	
		        	JSONObject dshbrdstrObj2 = new JSONObject();
		        	dshbrdstrObj2.put("key", tempprof);
		        	if(tempprof.equals("Expert"))
		        		dshbrdstrObj2.put("color", "green");
		        	else if(tempprof.equals("Proficient"))
		        		dshbrdstrObj2.put("color", "#52D017");
		        	else if(tempprof.equals("Intermediate"))
		        		dshbrdstrObj2.put("color", "yellow");
		        	else if(tempprof.equals("Basic"))
		        		dshbrdstrObj2.put("color", "red");
		        	else if(tempprof.equals("Not Applicable"))
		        		dshbrdstrObj2.put("color", "#ADD8E6");
		        	dshbrdstrObj2.put("values", strdshbrdArray1);
		        	strdshbrdArray2.add(dshbrdstrObj2);
				}
				JSONObject dshbrdstrObj3 = new JSONObject();
				dshbrdstrObj3.put("dshstream", StreamDsh);
				dshbrdstrObj3.put("dshbrddata", strdshbrdArray2);
				strdshbrdArray3.add(dshbrdstrObj3);
			
			response.setContentType("text/json");
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
			response.getWriter().write(strdshbrdArray3.toJSONString());
		}
		catch(Exception e)
		{
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
			response.sendError(HttpServletResponse.SC_FORBIDDEN);
			e.printStackTrace();
		}
		
		
	}

	private void getEmpSkillSummaryHdrDetail(HttpServletRequest request, HttpServletResponse response, Connection con) throws IOException {
		// TODO Auto-generated method stub
    	String Stream = "";
		BufferedReader skillDetailreader = request.getReader();
		Stream = skillDetailreader.readLine();
		JSONArray skillRecordHdrArray = new JSONArray();
		JSONObject skillRecordHdrObj = new JSONObject();
		JSONObject skillRecordHdrObj1 = new JSONObject();
        try 
        {        	
        	//Get the Skill Name and Expected Proficiency for selected Stream along with Employee Name and their competency.
        	PreparedStatement prpdstmtgtEpSkHdrDl = null;

            //SQL Query to get all existing skill details based on the Stream 
        	String sqlgtEpSkHdrDl = "select A.Emp_Name from (select distinct(Emp_ID) as EmpID from Tbl_Proficiency where Stream = ? and Last_Modified_Date is not null) as q1 inner join Tbl_Employee_Details A on A.Emp_ID = q1.EmpID where a.Project = 'Telstra' order by Emp_ID";
        	prpdstmtgtEpSkHdrDl = con.prepareStatement(sqlgtEpSkHdrDl);
        	prpdstmtgtEpSkHdrDl.setString(1, Stream);
        	ResultSet gtEpSkHdrDlRS = prpdstmtgtEpSkHdrDl.executeQuery();
        	prpdstmtgtEpSkHdrDl.clearParameters();

			skillRecordHdrObj.put("item", "Skill Set");
			skillRecordHdrObj1.put("item", "Expected Competency");
			skillRecordHdrArray.add(skillRecordHdrObj);
			skillRecordHdrArray.add(skillRecordHdrObj1);
			while(gtEpSkHdrDlRS.next())
			{
				JSONObject skillRecordHdrObj2 = new JSONObject();
				skillRecordHdrObj2.put("item", gtEpSkHdrDlRS.getString("Emp_Name"));
				skillRecordHdrArray.add(skillRecordHdrObj2);
			}
			response.setContentType("text/json");
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
			response.getWriter().write(skillRecordHdrArray.toJSONString());  	//Response to send the training scheduled on a date
        }
	    catch (Exception e)
        {
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
	    	response.sendError(HttpServletResponse.SC_FORBIDDEN);
	    	e.printStackTrace();			        	
	    }		
	}

	private void getEmpSkillSummaryDetail(HttpServletRequest request, HttpServletResponse response, Connection con) throws IOException {
		// To get the Employee Skill Summary details for reporting
		String stream = "";
    	BufferedReader skillDetailreader = request.getReader();
    	stream = skillDetailreader.readLine();
 		
 		JSONArray skillRecordArray = new JSONArray();
        try 
        {        	
        	//Get the Skill Name and Expected Proficiency for selected Stream along with Employee Name and their competency.
        	PreparedStatement prpdstmtGtEpSSDet = null;

            //SQL Query to get all existing skill details based on the Stream 
        	String sqlGtEpSSDet = "select Skill_ID, Skill_Name, Competency from Tbl_Skill_Set where Stream = ? order by Skill_ID";
        	prpdstmtGtEpSSDet = con.prepareStatement(sqlGtEpSSDet);
        	prpdstmtGtEpSSDet.setString(1, stream);
        	ResultSet skillPerStreamRS = prpdstmtGtEpSSDet.executeQuery();
        	prpdstmtGtEpSSDet.clearParameters();
		
			while(skillPerStreamRS.next())
			{
				JSONArray skillProfArray = new JSONArray();
				JSONObject skillDtlKeyObj = new JSONObject();
				JSONObject skillObj = new JSONObject();
				JSONObject skillObj1 = new JSONObject();
				skillObj.put("item",skillPerStreamRS.getString("Skill_Name"));
				skillProfArray.add(skillObj);
				String SkillID = skillPerStreamRS.getString("Skill_ID");
				String comp = skillPerStreamRS.getString("Competency");
				skillObj1.put("item",comp);
				skillProfArray.add(skillObj1);
				JSONArray empProfJObj = getEmpProficiency(SkillID,comp,stream,con);
				int empSkillCnt = getProfEmpCnt(SkillID,stream,con);
				for(int i=0;i<empSkillCnt;i++)
				{
					skillProfArray.add(empProfJObj.get(i));
				}
				skillDtlKeyObj.put("key", skillProfArray);
				skillRecordArray.add(skillDtlKeyObj);
			}
			response.setContentType("text/json");
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
			response.getWriter().write(skillRecordArray.toJSONString());  	//Response to send the training scheduled on a date
        }
	    catch (Exception e)
        {
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
	    	response.sendError(HttpServletResponse.SC_FORBIDDEN);
	    	e.printStackTrace();			        	
	    }		
	}

	private int getProfEmpCnt(String skillID, String stream, Connection con) {
		// TODO Auto-generated method stub
		int cnt = 0;
		try{
	    	PreparedStatement prpdstmtgetProfEmpCnt = null;
	    	String getProfEmpCntsql = "select COUNT(distinct(Emp_ID)) from Tbl_Proficiency where Skill_ID=? and Stream = ? and Last_Modified_Date is not null and Emp_ID in (select Emp_ID from Tbl_Employee_Details where Project = 'Telstra')";
	    	prpdstmtgetProfEmpCnt = con.prepareStatement(getProfEmpCntsql);
	    	prpdstmtgetProfEmpCnt.setString(1, skillID);
	    	prpdstmtgetProfEmpCnt.setString(2, stream);
	        ResultSet getProfEmpCntRS = prpdstmtgetProfEmpCnt.executeQuery();
	        prpdstmtgetProfEmpCnt.clearParameters();
	        
	        while(getProfEmpCntRS.next())
	        {
				cnt = getProfEmpCntRS.getInt(1);
			}
		}
		catch (Exception e)
		{
			return 0;
		}
		
		return cnt;
	}

	private JSONArray getEmpProficiency(String skillID, String expComp, String stream, Connection con) {
		// TODO Auto-generated method stub
		String tempSkillId = skillID;
		JSONArray empProfArray = new JSONArray();
		
		try{
	    	PreparedStatement prpdstmtGtEpSSDetl = null;
	    	String GtEpSSDetsqll = "select Proficiency from Tbl_Proficiency where Stream = ? and Skill_ID = ?  and Last_Modified_Date is not null and Emp_ID in (select Emp_ID from Tbl_Employee_Details where Project = 'Telstra') order by Emp_ID";
	    	prpdstmtGtEpSSDetl = con.prepareStatement(GtEpSSDetsqll);
	    	prpdstmtGtEpSSDetl.setString(1, stream);
	    	prpdstmtGtEpSSDetl.setString(2, tempSkillId);
	        ResultSet empSkillSummaryRS = prpdstmtGtEpSSDetl.executeQuery();
	        prpdstmtGtEpSSDetl.clearParameters();
	        
	        while(empSkillSummaryRS.next())
	        {
				JSONObject tempskillProfObj = new JSONObject();
				String empcomp = empSkillSummaryRS.getString("Proficiency");
				tempskillProfObj.put("item", empcomp);				
				String[] colorcd = getColorCodeForReport(empcomp,expComp);
				tempskillProfObj.put("bgcolorcode",colorcd[0]);
				tempskillProfObj.put("colorcode",colorcd[1]);
				empProfArray.add(tempskillProfObj);
			}
		}
		catch (Exception e)
		{
			return null;
		}
		return empProfArray;		
	}

	private void getAttendancePerFunctAreaRpt(HttpServletRequest request, HttpServletResponse response,
			Connection con) throws IOException {
		// Fetch the Training Attendance Report per Functional Area
		String startDate = null;
		String endDate = null;
        String trline = null;
		StringBuffer ReportDate = new StringBuffer();
        JSONObject jsonObj = new JSONObject();
        JSONParser tparser = new JSONParser();
		JSONArray trainingFunctAttendanceArray = new JSONArray();

        try 
        {
	        PreparedStatement prpdstmtGetAtPrFuncAr = null;
        	BufferedReader ReportDatereader = request.getReader();
        	trline = ReportDatereader.readLine();
        	ReportDate.append(trline);
  
            Object tobj = tparser.parse(ReportDate.toString());
            jsonObj = (JSONObject) tobj;        
            startDate = (String)jsonObj.get("startDate");
            endDate = (String)jsonObj.get("endDate");

            //SQL Query to get all training attendance for Report generation
            String sqlGetAtPrFuncAr = "select B.Functional_Area, count(distinct(A.Training_Topic_ID)) As Topic_Count, COUNT(distinct(A.Emp_ID)) as Emp_Count from Tbl_Training_Attendance A inner join  Tbl_Training_Topics B on A.Training_Topic_ID = B.Training_Topic_ID where A.Date between ? and ? and A.Status = 'Attended' group by B.Functional_Area";
            prpdstmtGetAtPrFuncAr = con.prepareStatement(sqlGetAtPrFuncAr);
            prpdstmtGetAtPrFuncAr.setString(1, startDate);
            prpdstmtGetAtPrFuncAr.setString(2, endDate);
          
            ResultSet FunctattendanceReportRs = prpdstmtGetAtPrFuncAr.executeQuery();
            prpdstmtGetAtPrFuncAr.clearParameters();
		
			while(FunctattendanceReportRs.next())
			{
				JSONObject trainingObj = new JSONObject();
				trainingObj.put("FunctArea", FunctattendanceReportRs.getString("Functional_Area"));
				trainingObj.put("TopicCount", FunctattendanceReportRs.getString("Topic_Count"));
				trainingObj.put("EmpCount", FunctattendanceReportRs.getString("Emp_Count"));				
				trainingFunctAttendanceArray.add(trainingObj);
			}
			response.setContentType("text/json");
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
			response.getWriter().write(trainingFunctAttendanceArray.toJSONString());  	//Response to send the training attendance for report generation
        }
        catch (Exception e)
        {
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
        	response.sendError(HttpServletResponse.SC_FORBIDDEN);
        	e.printStackTrace();			        	
	    }
	}

	//To get the SkillCompetency Count for the Skill Summary Report
	private void getSkillCountDetail(HttpServletRequest request, HttpServletResponse response, Connection con) throws IOException {
		String skillName = "";
		String stream = "";
     
        try 
        {
	        PreparedStatement prpdstmtGtSkCnDtl = null;
	        PreparedStatement prpdstmtGtSkCnDtl1 = null;
	        PreparedStatement prpdstmtGtSkCnDtl2 = null;
	        PreparedStatement prpdstmtGtSkCnDtl3 = null;
	        PreparedStatement prpdstmtGtSkCnDtl4 = null;
	        PreparedStatement prpdstmtGtSkCnDtl5 = null;
	        JSONArray skillCountArray = new JSONArray();
	        
        	BufferedReader skillNamereader = request.getReader();
        	stream = skillNamereader.readLine();
        	
            //SQL Query to get all existing skill details based on the Stream 			
            String sqlGtSkCnDtl = "select Skill_Name, Competency from Tbl_Skill_Set where Stream = ?";
            prpdstmtGtSkCnDtl = con.prepareStatement(sqlGtSkCnDtl);
            prpdstmtGtSkCnDtl.setString(1, stream);
            
        	ResultSet skillPerStreamRS = prpdstmtGtSkCnDtl.executeQuery();
        	prpdstmtGtSkCnDtl.clearParameters();
		
			while(skillPerStreamRS.next())
			{
				skillName = skillPerStreamRS.getString("Skill_Name");
				JSONObject skillCountObj = new JSONObject();
				skillCountObj.put("Name",skillName);
				String comp = skillPerStreamRS.getString("Competency");
				skillCountObj.put("Competency",comp);
				
				String sqlGtSkCnDtl1 = "select COUNT(distinct(Emp_ID)) as excount from Tbl_Proficiency where Proficiency = 'Expert' and Last_Modified_Date is not null and Skill_ID in (select Skill_ID from Tbl_Skill_Set where Skill_Name = ? and Stream = ?) and Emp_ID in (select Emp_ID from Tbl_Employee_Details where Project = 'Telstra')";
	            prpdstmtGtSkCnDtl1 = con.prepareStatement(sqlGtSkCnDtl1);
	            prpdstmtGtSkCnDtl1.setString(1, skillName);
	            prpdstmtGtSkCnDtl1.setString(2, stream);
				ResultSet skillIDExpertRS = prpdstmtGtSkCnDtl1.executeQuery();
				prpdstmtGtSkCnDtl1.clearParameters();
				while(skillIDExpertRS.next())
				{
					skillCountObj.put("expCount",skillIDExpertRS.getString("excount"));
					String[] colorcd = getColorCodeForReport("Expert",comp);
					skillCountObj.put("expColorbg",colorcd[0]);
					skillCountObj.put("expColor",colorcd[1]);
				}
				
	            String sqlGtSkCnDtl2 = "select COUNT(distinct(Emp_ID)) as profcount from Tbl_Proficiency where Proficiency = 'Proficient' and Last_Modified_Date is not null and Skill_ID in (select Skill_ID from Tbl_Skill_Set where Skill_Name = ? and Stream = ?) and Emp_ID in (select Emp_ID from Tbl_Employee_Details where Project = 'Telstra')";
				prpdstmtGtSkCnDtl2 = con.prepareStatement(sqlGtSkCnDtl2);
				prpdstmtGtSkCnDtl2.setString(1, skillName);
				prpdstmtGtSkCnDtl2.setString(2, stream);
	            ResultSet skillIDProfRS = prpdstmtGtSkCnDtl2.executeQuery();
	            prpdstmtGtSkCnDtl2.clearParameters();
				while(skillIDProfRS.next())
				{
					skillCountObj.put("profCount",skillIDProfRS.getString("profcount"));
					String[] colorcd = getColorCodeForReport("Proficient",comp);
					skillCountObj.put("profColorbg",colorcd[0]);
					skillCountObj.put("profColor",colorcd[1]);
				}
				
	            String sqlGtSkCnDtl3 = "select COUNT(distinct(Emp_ID)) as intercount from Tbl_Proficiency where Proficiency = 'Intermediate' and Last_Modified_Date is not null and Skill_ID in (select Skill_ID from Tbl_Skill_Set where Skill_Name = ? and Stream = ?) and Emp_ID in (select Emp_ID from Tbl_Employee_Details where Project = 'Telstra')";
	            prpdstmtGtSkCnDtl3 = con.prepareStatement(sqlGtSkCnDtl3);
	            prpdstmtGtSkCnDtl3.setString(1, skillName);
	            prpdstmtGtSkCnDtl3.setString(2, stream);
	            ResultSet skillIDInterRS = prpdstmtGtSkCnDtl3.executeQuery();
	            prpdstmtGtSkCnDtl3.clearParameters();
				while(skillIDInterRS.next())
				{
					skillCountObj.put("interCount",skillIDInterRS.getString("intercount"));
					String[] colorcd = getColorCodeForReport("Intermediate",comp);
					skillCountObj.put("interColorbg",colorcd[0]);
					skillCountObj.put("interColor",colorcd[1]);
				}
				
	            String sqlGtSkCnDtl4 = "select COUNT(distinct(Emp_ID)) as basiccount from Tbl_Proficiency where Proficiency = 'Basic' and Last_Modified_Date is not null and Skill_ID in (select Skill_ID from Tbl_Skill_Set where Skill_Name = ? and Stream = ?) and Emp_ID in (select Emp_ID from Tbl_Employee_Details where Project = 'Telstra')";
				prpdstmtGtSkCnDtl4 = con.prepareStatement(sqlGtSkCnDtl4);
				prpdstmtGtSkCnDtl4.setString(1, skillName);
				prpdstmtGtSkCnDtl4.setString(2, stream);
	            ResultSet skillIDBasicRS = prpdstmtGtSkCnDtl4.executeQuery();
				while(skillIDBasicRS.next())
				{
					skillCountObj.put("basCount",skillIDBasicRS.getString("basiccount"));
					String[] colorcd = getColorCodeForReport("Basic",comp);
					skillCountObj.put("basColorbg",colorcd[0]);
					skillCountObj.put("basColor",colorcd[1]);
				}
				
	            String sqlGtSkCnDtl5 = "select COUNT(distinct(Emp_ID)) as nacount from Tbl_Proficiency where Proficiency = 'Not Applicable' and Last_Modified_Date is not null and Skill_ID in (select Skill_ID from Tbl_Skill_Set where Skill_Name = ? and Stream = ?) and Emp_ID in (select Emp_ID from Tbl_Employee_Details where Project = 'Telstra')";
				prpdstmtGtSkCnDtl5 = con.prepareStatement(sqlGtSkCnDtl5);
				prpdstmtGtSkCnDtl5.setString(1, skillName);
				prpdstmtGtSkCnDtl5.setString(2, stream);
	            ResultSet skillIDNARS = prpdstmtGtSkCnDtl5.executeQuery();
				while(skillIDNARS.next())
				{
					skillCountObj.put("naCount",skillIDNARS.getString("nacount"));
					String[] colorcd = getColorCodeForReport("Not Applicable",comp);
					skillCountObj.put("naColorbg",colorcd[0]);
					skillCountObj.put("naColor",colorcd[1]);
				}
				skillCountArray.add(skillCountObj);
			}           			
			
			response.setContentType("text/json");
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
			response.getWriter().write(skillCountArray.toJSONString());  	//Response to send the Competency Count for each Skill Set per stream
        }
	    catch (Exception e)
        {
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
	    	response.sendError(HttpServletResponse.SC_FORBIDDEN);
	    	e.printStackTrace();			        	
	    }
	}

	private String[] getColorCodeForReport(String actprof, String expcomp) {
		// TODO Auto-generated method stub
		boolean colorCodeSet = false;
		String[] compArray = {"Expert","Proficient","Intermediate","Basic","Not Applicable"};
		String[] colorcdArray = new String[2];
		if(actprof.equals(expcomp))
		{
			colorcdArray[0] = "#52D017";
			colorcdArray[1] = "black";
			colorCodeSet = true;
		}
		else if(actprof.equals("Not Applicable"))
		{
			colorcdArray[0] = "#ADD8E6";
			colorcdArray[1] = "black";
			colorCodeSet = true;
		}
		else
		{
			for(int i=0; i<5; i++)
			{
				if(expcomp.equals(compArray[i]))
				{
					if((actprof.equals(compArray[i+1])))
					{
						colorcdArray[0] = "yellow";
						colorcdArray[1] = "black";
						colorCodeSet = true;
					}
					else
					{
						for(int j=i-1; j >= 0; j--)
						{
						if((actprof.equals(compArray[j])))
							{
								colorcdArray[0] = "green";
								colorcdArray[1] = "white";
								colorCodeSet = true;
							}
						}
					}
				}
			}
		}
		if(colorCodeSet == false)
		{
			colorcdArray[0] = "red";
			colorcdArray[1] = "white";
			colorCodeSet = true;
		}
		return colorcdArray;
	}

	//To add the proficiency details to the database
	private void ProficiencyAddDetail(HttpServletRequest request, HttpServletResponse response, Connection con) throws IOException {
		String line = "";
		String stream = "";
		String skillName = "";
		String  empID = "";
		String proficiency = "";
		String skillID = "";
		String loginEmpID = "";
		int updBatchSize = 0;
		int insBatchSize = 0;
		
		Date DateTime = new Date();
		String currentDateTime= new SimpleDateFormat("yyyy-MM-dd").format(DateTime);

        StringBuffer addProficiencyDetails = new StringBuffer();
        JSONArray jsonArray = new JSONArray();
        JSONParser parser = new JSONParser();
        try{
	        PreparedStatement prpdstmtProfAdDt = null;
	        PreparedStatement prpdstmtProfAdDt1 = null;
	        PreparedStatement prpdstmtProfAdDt2 = null;
	        PreparedStatement prpdstmtProfAdDt3 = null;
	        
			BufferedReader reader = request.getReader();
	    	while ((line = reader.readLine()) != null)
	    		addProficiencyDetails.append(line);
	    	
			Object obj = parser.parse(addProficiencyDetails.toString());
			jsonArray = (JSONArray) obj;
			
	        String updtsql = "select * from Tbl_Proficiency where Emp_ID = ? and Skill_ID in (select Skill_ID from Tbl_Skill_Set where Skill_Name = ?)";
        	String srchsql = "select Skill_ID from Tbl_Skill_Set where Skill_Name = ? and Stream = ?";
        	String updtProfSql = "update Tbl_Proficiency set Proficiency = ?, Last_Modified_Date = ?, Last_Modified_By = ? where Emp_ID = ? and Skill_ID in (select Skill_ID from Tbl_Skill_Set where Skill_Name = ?)";
        	String addsql = "insert into Tbl_Proficiency values(?,?,?,?,?,?)";
        	
        	prpdstmtProfAdDt3 = con.prepareStatement(addsql);
        	prpdstmtProfAdDt1 = con.prepareStatement(updtProfSql);
	        prpdstmtProfAdDt = con.prepareStatement(updtsql);
        	prpdstmtProfAdDt2 = con.prepareStatement(srchsql);

        	
            for(int i = 0; i < jsonArray.size();i++)
            {
            	JSONObject jobj =  (JSONObject) jsonArray.get(i);
    	        empID = (String) jobj.get("empID");
    	        skillName = (String) jobj.get("skillName");
    	        proficiency = (String) jobj.get("proficiency");
    	        stream = (String) jobj.get("stream");
    	        loginEmpID = (String) jobj.get("loginEmpID"); 
    	        prpdstmtProfAdDt.setString(1, empID);
    	        prpdstmtProfAdDt.setString(2, skillName);
    	        ResultSet proficiencySearchRS =  prpdstmtProfAdDt.executeQuery();
    	        prpdstmtProfAdDt.clearParameters();
    	        
    	        if(proficiencySearchRS.next())
    	        {
    	        	prpdstmtProfAdDt1.setString(1, proficiency);
    	        	prpdstmtProfAdDt1.setString(2, currentDateTime);
    	        	prpdstmtProfAdDt1.setString(3, loginEmpID);
    	        	prpdstmtProfAdDt1.setString(4, empID);
    	        	prpdstmtProfAdDt1.setString(5, skillName);
    	        	prpdstmtProfAdDt1.addBatch();
    	        	updBatchSize++;
    	        } 	        
    	        else
    	        {   
    	        	prpdstmtProfAdDt2.setString(1, skillName);
    	        	prpdstmtProfAdDt2.setString(2, stream);
    	        	ResultSet skillSearchRS =  prpdstmtProfAdDt2.executeQuery();
    	        	prpdstmtProfAdDt2.clearParameters();
    	        	if(skillSearchRS.next())
    	        	{
    	        		skillID = skillSearchRS.getString(1);
    	        	}
                	prpdstmtProfAdDt3.setString(1, stream);
                	prpdstmtProfAdDt3.setString(2, skillID);
                	prpdstmtProfAdDt3.setString(3, proficiency);
                	prpdstmtProfAdDt3.setString(4, empID);
                	prpdstmtProfAdDt3.setString(5, loginEmpID);
                	prpdstmtProfAdDt3.setString(6, currentDateTime);
                	prpdstmtProfAdDt3.addBatch();
                	insBatchSize++;
                }
            }
            if(updBatchSize > 0)
            {
            	prpdstmtProfAdDt1.executeBatch();
            	prpdstmtProfAdDt1.clearBatch();
            }
            if(insBatchSize > 0)
            {
            	prpdstmtProfAdDt3.executeBatch();
            	prpdstmtProfAdDt3.clearBatch();
            }
        }
        catch(Exception e)
		{
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
        	response.sendError(HttpServletResponse.SC_FORBIDDEN);
        	e.printStackTrace();
        }		

		
	}

	//To get the existing proficiency detail for a particular emp id and stream
	private void getAvailableProficiencyDetail(HttpServletRequest request, HttpServletResponse response,
			Connection con) throws IOException {
		String line = "";
		String empID = "";
		String stream = "";

        StringBuffer getProficiencyDetails = new StringBuffer();
        JSONArray jsonArray = new JSONArray();
        JSONArray ProficiencyRecordArray = new JSONArray();  
        
        JSONParser parser = new JSONParser();
        try{
	        PreparedStatement prpdstmtGtAlPyDl = null;
	        PreparedStatement prpdstmtGtAlPyDl1 = null;
	        PreparedStatement prpdstmtGtAlPyDl2 = null;
	        
			BufferedReader reader = request.getReader();
	    	while ((line = reader.readLine()) != null)
	    		getProficiencyDetails.append(line);
	    	
	        Object obj = parser.parse(getProficiencyDetails.toString());
	        JSONObject jobj =  (JSONObject) obj;
	        stream = (String) jobj.get("stream");
	        empID = (String) jobj.get("empID");

	        //SQL Query to select the skill details from the Skill set table.            	
	        String sqlGtAlPyDl = "select A.Skill_Name, A.Skill_Detail, A.Competency, B.Proficiency from Tbl_Skill_Set A inner join Tbl_Proficiency B on A.Skill_ID = B.Skill_ID where B.Emp_ID = ? and B.Stream = ?";
	        prpdstmtGtAlPyDl = con.prepareStatement(sqlGtAlPyDl);
	        prpdstmtGtAlPyDl.setString(1, empID);
	        prpdstmtGtAlPyDl.setString(2, stream);
	        ResultSet proficiencyRS= prpdstmtGtAlPyDl.executeQuery();
	        prpdstmtGtAlPyDl.clearParameters();
			while(proficiencyRS.next())
			{
				JSONObject skillObj = new JSONObject();
				skillObj.put("skillName",proficiencyRS.getString("Skill_Name"));
				skillObj.put("skilldetail",proficiencyRS.getString("Skill_Detail"));
				skillObj.put("competency",proficiencyRS.getString("Competency"));
				skillObj.put("proficiency",proficiencyRS.getString("Proficiency"));
				String expcomp = proficiencyRS.getString("Competency");
				String actprof = proficiencyRS.getString("Proficiency");
				String[] colorcd = getColorCodeForReport(actprof,expcomp);
				skillObj.put("setBgColor", colorcd[0]);
				skillObj.put("setColor", colorcd[1]);			
				ProficiencyRecordArray.add(skillObj);
			}
			response.setContentType("text/json");
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
			response.getWriter().write(ProficiencyRecordArray.toJSONString()); 
        }
        catch(Exception e)
		{
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
        	response.sendError(HttpServletResponse.SC_FORBIDDEN);
        	e.printStackTrace();
        }		
	}

	//To add new Skillset to database
	private void SkillAddDetail(HttpServletRequest request, HttpServletResponse response, Connection con) throws IOException {
		String line = "";
		String stream = "";
		String skillName = "";
		String skillDetail = "";
		String comp = "";
		int skillID = 0;
		int skillIDCount = 0;

        StringBuffer addSkillDetails = new StringBuffer();
        JSONArray jsonArray = new JSONArray();
        JSONParser parser = new JSONParser();
        try{
	        PreparedStatement prpdstmtSlAdDl = null;
	        PreparedStatement prpdstmtSlAdDl1 = null;
	        
	        String stssql = "select MAX(Skill_ID) from Tbl_Skill_Set";
	        prpdstmtSlAdDl = con.prepareStatement(stssql);	        
	        ResultSet skillIDCountRS =  prpdstmtSlAdDl.executeQuery();        
			if(skillIDCountRS.next())
			{
				skillIDCount = skillIDCountRS.getInt(1);
				
				BufferedReader reader = request.getReader();
		    	while ((line = reader.readLine()) != null)
		    		addSkillDetails.append(line);
		    	
				Object obj = parser.parse(addSkillDetails.toString());
				jsonArray = (JSONArray) obj;
            
	            for(int i = 0; i < jsonArray.size();i++)
	            {
	            	skillIDCount++;
	            	JSONObject jobj =  (JSONObject) jsonArray.get(i);
	    	        stream = (String) jobj.get("stream");
	    	        skillName = (String) jobj.get("skillName");
	    	        skillDetail = (String) jobj.get("skillDetail");
	    	        comp = (String) jobj.get("comp");
	    	        skillID = skillIDCount;
	                
	    	        //SQL Query to insert new skill details to database.            	
	            	 String sqlSlAdDl1 = "if not exists (select Skill_ID from Tbl_Skill_Set where Skill_Name = ? and Stream = ?)INSERT INTO Tbl_Skill_Set (Skill_ID,Skill_Name,Skill_Detail,Competency,Stream) VALUES (?,?,?,?,?)";
	         		prpdstmtSlAdDl1 = con.prepareStatement(sqlSlAdDl1);
	         		prpdstmtSlAdDl1.setString(1, skillName);
	         		prpdstmtSlAdDl1.setString(2, stream);
	         		prpdstmtSlAdDl1.setInt(3, skillID);
	         		prpdstmtSlAdDl1.setString(4, skillName);
	         		prpdstmtSlAdDl1.setString(5, skillDetail);
	         		prpdstmtSlAdDl1.setString(6, comp);
	         		prpdstmtSlAdDl1.setString(7, stream);
	            	prpdstmtSlAdDl1.executeUpdate();
	            	prpdstmtSlAdDl1.clearParameters();
	            	boolean sts = addSkillProf(stream,skillID,con);
	            	if(sts == false)
	            	{
	            		throw new Exception("Error on loading Employee Proficiency for the new Skill IDs");
	            	}
	            }			
			}
			else
			{
				throw new Exception("Error on fethcing the maximum Skill ID from the Table");
			}
        }
        catch(Exception e)
		{
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
        	response.sendError(HttpServletResponse.SC_FORBIDDEN);
        	e.printStackTrace();
        }		
	}

	private boolean addSkillProf(String stream, int skillID, Connection con) {
		// TODO Auto-generated method stub
		String empIDPrf = "";
		Date DateTimenew = new Date();
		String currentDateTimenew = new SimpleDateFormat("yyyy-MM-dd").format(DateTimenew);
        try
        {
	        PreparedStatement prpdstmtaddEmpProf = null;
	        PreparedStatement prpdstmtaddEmpProf1 = null;
	        PreparedStatement prpdstmtaddEmpProf2 = null;
	        String addEmpProfsql = "select distinct(Emp_ID) as emp from Tbl_Employee_Details where Stream = ?";
	        String addEmpProfsql1 = "insert into Tbl_Proficiency values(?,?,?,?,?,?)";
	        prpdstmtaddEmpProf = con.prepareStatement(addEmpProfsql);
	        prpdstmtaddEmpProf1 = con.prepareStatement(addEmpProfsql1);
	        prpdstmtaddEmpProf.setString(1, stream);
	        ResultSet addEmpProfRS = prpdstmtaddEmpProf.executeQuery();
	        while(addEmpProfRS.next())
	        {
	        	empIDPrf = addEmpProfRS.getString("emp");
	        	String addEmpProfsql2 = "select Last_Modified_Date from Tbl_Proficiency where Emp_ID = ? and Stream = ? and Last_Modified_Date is not null";
	        	prpdstmtaddEmpProf2 = con.prepareStatement(addEmpProfsql2);
	        	prpdstmtaddEmpProf2.setString(1, empIDPrf);
	        	prpdstmtaddEmpProf2.setString(2, stream);
	        	ResultSet addEmpProfRS1 = prpdstmtaddEmpProf2.executeQuery();
	        		        	
	        	prpdstmtaddEmpProf1.setString(1,stream);
	        	prpdstmtaddEmpProf1.setInt(2, skillID);
	        	prpdstmtaddEmpProf1.setString(3, "Basic");
	        	prpdstmtaddEmpProf1.setString(4, empIDPrf);
	        	prpdstmtaddEmpProf1.setString(5, null);
	        	if(addEmpProfRS1.next())
	        	{
	        		prpdstmtaddEmpProf1.setString(6,currentDateTimenew);
	        	}else
	        	{
		        	prpdstmtaddEmpProf1.setString(6, null);
	        	}
	        	prpdstmtaddEmpProf1.addBatch();	        	
	        }
	        prpdstmtaddEmpProf1.executeBatch();
	        prpdstmtaddEmpProf1.clearBatch();
	        return true;
        }
        catch (Exception e)
        {
        	return false;
        }
	}

	//To delete the Skillset from the database
	private void SkillDeleteDetail(HttpServletRequest request, HttpServletResponse response, Connection con) throws IOException {
		String line = "";
		String stream = "";
		String skillName = "";
		String skillDetail = "";
		String comp = "";

        StringBuffer deleteSkillDetails = new StringBuffer();
        JSONArray jsonArray = new JSONArray();
        JSONParser parser = new JSONParser();
        try{
	        PreparedStatement prpdstmtSkDelDet = null;
	        
			BufferedReader reader = request.getReader();
	    	while ((line = reader.readLine()) != null)
	    		deleteSkillDetails.append(line);
	
	        Object obj = parser.parse(deleteSkillDetails.toString());
	        jsonArray = (JSONArray) obj;
	        JSONObject jobj =  (JSONObject) jsonArray.get(0);
	        stream = (String) jobj.get("stream");
	        skillName = (String) jobj.get("skillName");
	        skillDetail = (String) jobj.get("skillDetail");
	        comp = (String) jobj.get("comp");

	        //SQL Query to delete the skill details from the Skill set table.            	
	        String sqlSkDelDet = "delete from Tbl_Skill_Set where Skill_Name = ? and Skill_Detail = ? and Competency = ? and Stream = ?";
	        prpdstmtSkDelDet = con.prepareStatement(sqlSkDelDet);
	        prpdstmtSkDelDet.setString(1, skillName);
	        prpdstmtSkDelDet.setString(2, skillDetail);
	        prpdstmtSkDelDet.setString(3, comp);
	        prpdstmtSkDelDet.setString(4, stream);
	        prpdstmtSkDelDet.executeUpdate();
	        prpdstmtSkDelDet.clearParameters();
        }
        catch(Exception e)
		{
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
        	response.sendError(HttpServletResponse.SC_FORBIDDEN);
        	e.printStackTrace();
        }			
	}

	//To get all the available skills based on the Stream
	private void getAvailableSkillsDetail(HttpServletRequest request, HttpServletResponse response, Connection con) throws IOException {
		String streamName = "";

 		JSONArray skillRecordArray = new JSONArray();        
        try 
        {
	        PreparedStatement prprstmtGtAvSkDet = null;
        	BufferedReader skillDetailreader = request.getReader();
        	streamName = skillDetailreader.readLine();
        	
            
            //SQL Query to get all existing skill details based on the Stream 
        	String sqlGtAvSkDet = "select Skill_ID, Skill_Name, Skill_Detail, Competency from Tbl_Skill_Set where Stream = ? order by Skill_ID";
            prprstmtGtAvSkDet = con.prepareStatement(sqlGtAvSkDet);
            prprstmtGtAvSkDet.setString(1, streamName);
        	ResultSet skillPerStreamRS = prprstmtGtAvSkDet.executeQuery();
        	prprstmtGtAvSkDet.clearParameters();
		
			while(skillPerStreamRS.next())
			{
				JSONObject skillObj = new JSONObject();
				skillObj.put("Name",skillPerStreamRS.getString("Skill_Name"));
				skillObj.put("Info",skillPerStreamRS.getString("Skill_Detail"));
				String comp = skillPerStreamRS.getString("Competency");
				skillObj.put("competency",comp);
				skillRecordArray.add(skillObj);
			}
			response.setContentType("text/json");
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
			response.getWriter().write(skillRecordArray.toJSONString());  	//Response to send the training scheduled on a date
        }
	    catch (Exception e)
        {
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
	    	response.sendError(HttpServletResponse.SC_FORBIDDEN);
	    	e.printStackTrace();			        	
	    }		
	}

	private void updateEmpDetails(HttpServletRequest request, HttpServletResponse response, Connection con) throws IOException {
		String line = "";
		String newEmpId = "";
		String newEmpName = "";
		String newDesignation = "";
		String newEmailId = "";
		String newStream = "";
		String newUserRole = "";
		String newProjectEmployee = "";
		String newProjectRole = "";
        StringBuffer newEmployeeDetails = new StringBuffer();
        JSONArray jsonArray = new JSONArray();
        JSONParser parser = new JSONParser();
        try{
        	PreparedStatement prpdstmtEmpUpd = null;
        	PreparedStatement prpdstmtEmpUpd1 = null;
        	PreparedStatement prpdstmtEmpUpd2 = null;
        	PreparedStatement prpdstmtEmpUpd3 = null;
        	PreparedStatement prpdstmtEmpUpd4 = null;
        	
			BufferedReader reader = request.getReader();
	    	while ((line = reader.readLine()) != null)
	    		newEmployeeDetails.append(line);
	
	        Object obj = parser.parse(newEmployeeDetails.toString());
	        jsonArray = (JSONArray) obj;
	        
	        for(int i = 0; i < jsonArray.size();i++)
	        {
	        	JSONObject jobj =  (JSONObject) jsonArray.get(i);
	        	newEmpId = String.valueOf(jobj.get("newEmpId"));
	        	newEmpName = (String) jobj.get("newEmpName");
	        	newDesignation = (String) jobj.get("newDesignation");
	        	newEmailId = (String) jobj.get("newEmailId");
	        	newStream = (String) jobj.get("newStream");
	        	newUserRole = (String) jobj.get("newUserRole");
	        	newProjectEmployee = (String) jobj.get("newProjectEmployee");
	        	newProjectRole = (String) jobj.get("newProjectRole");
	        	
	 	        String sql1 = "select distinct(Stream) as ExStream from Tbl_Proficiency where Emp_ID = ?";
	 	        prpdstmtEmpUpd1 = con.prepareStatement(sql1);
	 	        prpdstmtEmpUpd1.setString(1, newEmpId);
	 	        ResultSet ExStrmResult = prpdstmtEmpUpd1.executeQuery();
	 	        String ExStreamtmp = "";
	 	        if(ExStrmResult.next())
	 	        {
	 	        	ExStreamtmp = ExStrmResult.getString("ExStream");
	 	        }
	 	        
	        	//SQL Query to insert new Training to Tbl_Training_Topics table.            	           	
	        	 String sql = "update Tbl_Employee_Details set Emp_Name = ?,Email = ?,Designation = ?,Stream = ?,User_Role = ?,Project = ?,Project_Role = ? where Emp_ID = ?";
	        	 
	        	 prpdstmtEmpUpd = con.prepareStatement(sql);
	        	 prpdstmtEmpUpd.setString(1, newEmpName);
	        	 prpdstmtEmpUpd.setString(2, newEmailId);
	        	 prpdstmtEmpUpd.setString(3, newDesignation);
	        	 prpdstmtEmpUpd.setString(4, newStream);
	        	 prpdstmtEmpUpd.setString(5, newUserRole);
	        	 prpdstmtEmpUpd.setString(6, newProjectEmployee);
	        	 prpdstmtEmpUpd.setString(7, newProjectRole);
	        	 prpdstmtEmpUpd.setString(8, newEmpId);
	        	 prpdstmtEmpUpd.executeUpdate();
	 	         prpdstmtEmpUpd.clearParameters();
	 	         
	 	         //Delete existing proficiency details based on Stream change and Update Proficiency table for the new Stream
		         if(!newStream.equals(ExStreamtmp))
		         {
		        	 String sql2 = "delete from Tbl_Proficiency where Emp_ID = ?";
		        	 prpdstmtEmpUpd2 = con.prepareStatement(sql2);
		        	 prpdstmtEmpUpd2.setString(1, newEmpId);
		        	 prpdstmtEmpUpd2.executeUpdate();
		        	 prpdstmtEmpUpd2.clearParameters();
		        	 
					 String sql3 = "select Skill_ID from Tbl_Skill_Set where Stream = ?";
					 prpdstmtEmpUpd3 = con.prepareStatement(sql3);
					 prpdstmtEmpUpd3.setString(1, newStream);
					 ResultSet ExStrmResult1 = prpdstmtEmpUpd3.executeQuery();
					 prpdstmtEmpUpd3.clearParameters();
				    
					 String sql4 = "insert into Tbl_Proficiency values(?,?,?,?,?,?)";
					 prpdstmtEmpUpd4 = con.prepareStatement(sql4);
					 while(ExStrmResult1.next())
					    {
					    	int tempSkillID = ExStrmResult1.getInt("Skill_ID");
					    	prpdstmtEmpUpd4.setString(1, newStream);
					    	prpdstmtEmpUpd4.setInt(2, tempSkillID);
					    	prpdstmtEmpUpd4.setString(3, "Basic");
					    	prpdstmtEmpUpd4.setString(4, newEmpId);
					    	prpdstmtEmpUpd4.setString(5, null);
					    	prpdstmtEmpUpd4.setString(6, null);
					    	prpdstmtEmpUpd4.addBatch();
					    }
					 prpdstmtEmpUpd4.executeBatch();
					 prpdstmtEmpUpd4.clearBatch();		        	 
	            }
	        }
        }
        catch(Exception e)
		{
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
        	response.sendError(HttpServletResponse.SC_FORBIDDEN);
        	e.printStackTrace();
        }		
	}
	
	
	

	private void checkEmpAvailability(HttpServletRequest request, HttpServletResponse response, Connection con) {
		String line = "";
		String newEmpId = "";
		String empstatus = "";
	    StringBuffer newEmployeeDetails = new StringBuffer();
        JSONArray jsonArray = new JSONArray();
        JSONParser parser = new JSONParser();
		JSONArray searchEmpArray = new JSONArray();
        
        try{
	        PreparedStatement prpdstmtEmpAvail = null;
	        
			BufferedReader reader = request.getReader();
	    	while ((line = reader.readLine()) != null)
	    		newEmployeeDetails.append(line);
	
	        Object obj = parser.parse(newEmployeeDetails.toString());
	        jsonArray = (JSONArray) obj;
	        
	        for(int i = 0; i < jsonArray.size();i++)
	        {
	        	JSONObject jobj =  (JSONObject) jsonArray.get(i);
	        	newEmpId = String.valueOf(jobj.get("newEmpId"));
	        }
		
			String sql = "select * from Tbl_Employee_Details where Emp_ID =?";
			prpdstmtEmpAvail = con.prepareStatement(sql);
			prpdstmtEmpAvail.setString(1, newEmpId);
	        ResultSet empIDRs = prpdstmtEmpAvail.executeQuery();
	        prpdstmtEmpAvail.clearParameters();
		
			while(empIDRs.next())
			{
				JSONObject searchempObj = new JSONObject();
				searchempObj.put("searchEmpName", empIDRs.getString("Emp_Name"));
				searchempObj.put("searchEmail", empIDRs.getString("Email"));
				searchempObj.put("searchDesignation", empIDRs.getString("Designation"));
				searchempObj.put("searchStream", empIDRs.getString("Stream"));
				searchempObj.put("searchUserRole", empIDRs.getString("User_Role"));
				searchempObj.put("searchProject", empIDRs.getString("Project"));
				searchempObj.put("searchProjectRole", empIDRs.getString("Project_Role"));
				searchEmpArray.add(searchempObj);
			}
			response.setContentType("text/json");
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
			response.getWriter().write(searchEmpArray.toJSONString());  	//Response to send the training schedule for report generation
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	private void insertEmployeeDetails(HttpServletRequest request, HttpServletResponse response, Connection con) throws IOException {
        
		String line = "";
		String newEmpId = "";
		String newEmpName = "";
		String newDesignation = "";
		String newEmailId = "";
		String newStream = "";
		String newUserRole = "";
		String newProjectEmployee = "";
		String newProjectRole = "";
        StringBuffer newEmployeeDetails = new StringBuffer();
        JSONArray jsonArray = new JSONArray();
        JSONParser parser = new JSONParser();
        try{
	        PreparedStatement prpdstmtInsEmp = null;
	        PreparedStatement prpdstmtInsEmp1 = null;
	        PreparedStatement prpdstmtInsEmp2 = null;
	        
			BufferedReader reader = request.getReader();
	    	while ((line = reader.readLine()) != null)
	    		newEmployeeDetails.append(line);
	
	        Object obj = parser.parse(newEmployeeDetails.toString());
	        jsonArray = (JSONArray) obj;
	        
	        for(int i = 0; i < jsonArray.size();i++)
	        {
	        	JSONObject jobj =  (JSONObject) jsonArray.get(i);
	        	newEmpId = String.valueOf(jobj.get("newEmpId"));
	        	newEmpName = (String) jobj.get("newEmpName");
	        	newDesignation = (String) jobj.get("newDesignation");
	        	newEmailId = (String) jobj.get("newEmailId");
	        	newStream = (String) jobj.get("newStream");
	        	newUserRole = (String) jobj.get("newUserRole");
	        	newProjectEmployee = (String) jobj.get("newProjectEmployee");
	        	newProjectRole = (String) jobj.get("newProjectRole");
	            //SQL Query to insert new Training to Tbl_Training_Topics table.            	    	
	        	String sql = "INSERT INTO Tbl_Employee_Details (Emp_ID,Emp_Name,Designation,Email,Stream,User_Role,Project,Project_Role) VALUES (?,?,?,?,?,?,?,?)";
		     	prpdstmtInsEmp = con.prepareStatement(sql);
		     	prpdstmtInsEmp.setString(1, newEmpId);
		     	prpdstmtInsEmp.setString(2, newEmpName);
		     	prpdstmtInsEmp.setString(3, newDesignation);
		     	prpdstmtInsEmp.setString(4, newEmailId);
		     	prpdstmtInsEmp.setString(5, newStream);
		     	prpdstmtInsEmp.setString(6, newUserRole);
		     	prpdstmtInsEmp.setString(7, newProjectEmployee);
		     	prpdstmtInsEmp.setString(8, newProjectRole);
		     	prpdstmtInsEmp.executeUpdate();
			    prpdstmtInsEmp.clearParameters();
			    
			    //Update the Proficiency Table for the newly inserted employee based on the Stream from Skill Set table, if the Stream is available in Skill Set table.
			    String sql1 = "select Skill_ID from Tbl_Skill_Set where Stream = ?";
			    prpdstmtInsEmp1 = con.prepareStatement(sql1);
			    prpdstmtInsEmp1.setString(1, newStream);
			    ResultSet prpdstmtRst = prpdstmtInsEmp1.executeQuery();
			    prpdstmtInsEmp1.clearParameters();
		    	String sql2 = "insert into Tbl_Proficiency values(?,?,?,?,?,?)";
			    prpdstmtInsEmp2 = con.prepareStatement(sql2);
			    while(prpdstmtRst.next())
			    {
			    	int tempSkillID = prpdstmtRst.getInt("Skill_ID");
				    prpdstmtInsEmp2.setString(1, newStream);
				    prpdstmtInsEmp2.setInt(2, tempSkillID);
				    prpdstmtInsEmp2.setString(3, "Basic");
				    prpdstmtInsEmp2.setString(4, newEmpId);
				    prpdstmtInsEmp2.setString(5, null);
				    prpdstmtInsEmp2.setString(6, null);
				    prpdstmtInsEmp2.addBatch();
			    }
			    prpdstmtInsEmp2.executeBatch();
			    prpdstmtInsEmp2.clearBatch();
	        }
        }
        catch(Exception e)
		{
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
        	response.sendError(HttpServletResponse.SC_FORBIDDEN);
        	e.printStackTrace();
        }
	}
	

	private void addNewTrainingDetails(HttpServletRequest request, HttpServletResponse response, Connection con) throws IOException 
	{
        String line=null;
        String topic=null;
		String area=null;
		String functarea = null;
		int topicId = 0;
		int maxTopicID = 0;

        StringBuffer newTraining = new StringBuffer();
        JSONArray jsonArray = new JSONArray();
        JSONParser parser = new JSONParser();

		try 
        {
	        PreparedStatement prpdstmtNewTrn = null;
	        
	        Statement stmt1 = con.createStatement();

            //SQL Query to fetch the maximum value of Topic ID from the Tbl_Training_Topics table.
			ResultSet maxTopicIDRs = stmt1.executeQuery("select MAX(Training_Topic_ID) as maxtopicid from Tbl_Training_Topics");
			if(maxTopicIDRs.next())
			{
				maxTopicID = maxTopicIDRs.getInt(1);
			
	        BufferedReader reader = request.getReader();
        	while ((line = reader.readLine()) != null)
        		newTraining.append(line);
 
            Object obj = parser.parse(newTraining.toString());
            jsonArray = (JSONArray) obj;
            
            for(int i = 0; i < jsonArray.size();i++)
            {
            	maxTopicID++;
            	JSONObject jobj =  (JSONObject) jsonArray.get(i);
            	area = (String) jobj.get("area");
            	functarea = (String) jobj.get("functarea");
            	topic = (String) jobj.get("Topic");
            	topicId = maxTopicID;
                //SQL Query to insert new Training to Tbl_Training_Topics table.            	          	
             	String sql = "if not exists (select Training_Topic_ID from Tbl_Training_Topics where Training_Topic_Name = ?)INSERT INTO Tbl_Training_Topics (Training_Area,Training_Topic_Name,Training_Topic_ID,Functional_Area) VALUES (?,?,?,?)";
          		prpdstmtNewTrn = con.prepareStatement(sql);
          		prpdstmtNewTrn.setString(1, topic);
          		prpdstmtNewTrn.setString(2, area);
          		prpdstmtNewTrn.setString(3, topic);
          		prpdstmtNewTrn.setInt(4, topicId);
          		prpdstmtNewTrn.setString(5, functarea);
          		prpdstmtNewTrn.executeUpdate();
     			prpdstmtNewTrn.clearParameters();
            }			
			}
			else
			{
				throw new Exception("Error on fethcing the maximum Topic ID from the Training Topics Table");
			}
			stmt1.close();
        }
        catch(Exception e)
		{
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
        	response.sendError(HttpServletResponse.SC_FORBIDDEN);
        	e.printStackTrace();
        }		
	}
	

	private void uploadTrainingDetails(HttpServletRequest request, HttpServletResponse response, Connection con) throws IOException {
		// TODO Auto-generated method stub
		
		Workbook workbook = null;
		PreparedStatement prpdstmtFileUpl = null;
		int rowCount = 0;
		int invalidRow = 1;
		String EmpID = null;
		String TrainingTopic = null;
		String date = null;
		String rowCountString = null;
		String invalidInputA = null;
		JSONObject invalidInput = new JSONObject();
		
		
		try
		{
			BufferedReader reader = request.getReader();
			String line=null;
			StringBuffer trngAtndBulkLoad = new StringBuffer();
	        
			while ((line = reader.readLine()) != null)
				trngAtndBulkLoad.append(line);
		
			JSONObject jsonObj = new JSONObject();
	        JSONParser parser = new JSONParser();

	        Object obj = parser.parse(trngAtndBulkLoad.toString());
	        jsonObj = (JSONObject) obj;
			
			workbook = WorkbookFactory.create(new ByteArrayInputStream(DatatypeConverter.parseBase64Binary((String) jsonObj.get("file"))));
			
			
			int sheetCount = workbook.getNumberOfSheets();
			Boolean inData = true;
			
			//Insert the data to the table if no duplicate
			String query = "if not exists (select Emp_ID, Training_Topic_ID, Date from Tbl_Training_Attendance d where d.Emp_ID = ? and d.Training_Topic_ID = ? and d.Date = ?)insert into Tbl_Training_Attendance (Emp_ID, Training_Topic_ID, Status, Date) values (?, ?, 'Attended', ?)";
			prpdstmtFileUpl = con.prepareStatement(query);
            
			if(sheetCount > 0)
			{
				Sheet firstSheet = workbook.getSheetAt(0);
				Iterator<Row> iterator = firstSheet.iterator();
				if (iterator.hasNext())
				{
					//Skip the title row
					Row firstRow = iterator.next();
					
					while (iterator.hasNext() && inData) {
						Row nextRow = iterator.next();
												
						Iterator<Cell> cellIterator = nextRow.cellIterator();
					
						if (cellIterator.hasNext()) {
							
							Cell cell = cellIterator.next();
												
							EmpID = Integer.toString((int)cell.getNumericCellValue());
							
							if (!cellIterator.hasNext())
							{
								throw new Exception("Training Topic is not available in excelsheet");
							}
							
							cell = cellIterator.next();
							TrainingTopic = cell.getStringCellValue();
							
							if (!cellIterator.hasNext())
							{
								throw new Exception("Training Plan Date is not available in excelsheet");
							}
							
							cell = cellIterator.next();	

								date=  new SimpleDateFormat("yyyy/MM/dd").format(DateUtil.getJavaDate(cell.getNumericCellValue())).toString();
							
							if(EmpID.equals("0") || TrainingTopic.equals("") || date.equals("1899/12/31") )
							{
								throw new Exception("some fields are empty in excelsheet");					   
							}
							
							String TopicID =  GetTopicID(con, TrainingTopic);
							
							Boolean EmpIDValid = VerifyEmpID(con, EmpID);
							Boolean TrainingScheduled = false;
													
							if(EmpIDValid == false)
							{								
								invalidInputA = "Invalid Employee ID "+EmpID+".";
								invalidInput.put("KeyMessage", invalidInputA);
								throw new Exception("Invalid Employee ID " + EmpID);
							}
							
							if(TopicID == null)
							{								
								invalidInputA = "Invalid Training Topic '"+TrainingTopic+"'.";
								invalidInput.put("KeyMessage", invalidInputA);
								throw new Exception("Invalid topic name " + TrainingTopic);							
							}
							else
							{
								TrainingScheduled = VerifyTrainingScheduled(con, TopicID, date);
							}
							
							if(TrainingScheduled == false)
							{
								invalidInputA = "Invalid Training Topic and Training plan date combination. Training Topic = '"+TrainingTopic+"', schedule date = "+date+".";
								invalidInput.put("KeyMessage", invalidInputA);
								throw new Exception("Invalid Training Topic and Plan Date combination " + TrainingTopic+" , "+date);
							}
							prpdstmtFileUpl.setString(1, EmpID);
							prpdstmtFileUpl.setString(2, TopicID);
							prpdstmtFileUpl.setString(3, date);
							prpdstmtFileUpl.setString(4, EmpID);
							prpdstmtFileUpl.setString(5, TopicID);
							prpdstmtFileUpl.setString(6, date);
							prpdstmtFileUpl.addBatch();
							rowCount++;	
							invalidRow++;
						}											
					}
					if (rowCount == 0)
					{
						invalidInputA = "Input file is empty";
						invalidInput.put("KeyMessage", invalidInputA);
						throw new Exception("Input file is empty");
					}
					prpdstmtFileUpl.executeBatch();
					prpdstmtFileUpl.clearBatch();
					
						rowCountString = Integer.toString(rowCount);
						response.setContentType("text/json");
						response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
						response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
						response.setHeader("Expires", "0"); // Proxies.
						response.getWriter().write(rowCountString);
				}else
				{
					invalidInputA = "Input file is empty";
					invalidInput.put("KeyMessage", invalidInputA);
					throw new Exception("Input file is empty");
				}

				}
				else
				{
					invalidInputA = "Input file is empty";
					invalidInput.put("KeyMessage", invalidInputA);
					throw new Exception("Input file is empty");
				}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			if (EmpID == null && invalidInputA == null)
			{
				invalidInputA = "Invalid Employee ID format on row number "+invalidRow+".";
				invalidInput.put("KeyMessage", invalidInputA);
			}
			else if (TrainingTopic == null && invalidInputA == null)
			{
				invalidInputA = "Invalid TrainingTopic format on row number "+invalidRow+".";
				invalidInput.put("KeyMessage", invalidInputA);
			}else if (date == null && invalidInputA == null)
			{
				invalidInputA = "Invalid date format on row number "+invalidRow+".";
				invalidInput.put("KeyMessage", invalidInputA);
			}
			response.setStatus(HttpServletResponse.SC_FORBIDDEN);
			response.setContentType("application/json");
			response.setCharacterEncoding("UTF-8");
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
			response.getWriter().write(invalidInput.toJSONString());
			//response.sendError(HttpServletResponse.SC_FORBIDDEN, invalidInputA);
		}
		
		try {
			workbook.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}	
	}
	
	
	//To verify whether the EmpID from the bulk upload excel is valid.
	private Boolean VerifyEmpID(Connection con, String empid) {
		// TODO Auto-generated method stub
		
		Boolean empstatus = false;
		try {
			PreparedStatement prpdstmtVerEmp = null;
			String sql = "select * from Tbl_Employee_Details where Emp_ID =?";
			prpdstmtVerEmp = con.prepareStatement(sql);
			prpdstmtVerEmp.setString(1, empid);
			ResultSet empIDRs = prpdstmtVerEmp.executeQuery();
			prpdstmtVerEmp.clearParameters();
		
			if(empIDRs.next())
			{
				empstatus = true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		return empstatus;
	}	
	
	private Boolean VerifyTrainingScheduled(Connection con, String topicid, String date)
	{
		Boolean trainingstatus = false;
		try {
			PreparedStatement prpdstmtVerTrn = null;
			String sql = "select * from Tbl_Training_Calendar where Training_Topic_ID = ? and Planned_Date = ?";
			prpdstmtVerTrn = con.prepareStatement(sql);
			prpdstmtVerTrn.setString(1, topicid);
			prpdstmtVerTrn.setString(2, date);			
			ResultSet trainingRs = prpdstmtVerTrn.executeQuery();
			prpdstmtVerTrn.clearParameters();
			if(trainingRs.next())
			{
				trainingstatus = true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		return trainingstatus;
	}
	

	//To get the topic id of the topic name from the Bulk import Excel.
	private String GetTopicID(Connection con, String trainingTopic) {
		// TODO Auto-generated method stub
		
		String TopicID = null;
		try {
			PreparedStatement prpdstmtGetTp = null;
			String sql = "select Training_Topic_ID from Tbl_Training_Topics where Training_Topic_Name =?";
			prpdstmtGetTp = con.prepareStatement(sql);
			prpdstmtGetTp.setString(1, trainingTopic);
			ResultSet selTopicIdRs = prpdstmtGetTp.executeQuery();
			prpdstmtGetTp.clearParameters();
			if(selTopicIdRs.next())
			{
				TopicID = selTopicIdRs.getString("Training_Topic_ID");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return TopicID;
	}

	

	//Function to insert all scheduled active training on the Calendar.
	private void insertTrainingToCalendar(HttpServletRequest request, HttpServletResponse response, Connection con) throws IOException 
	{
        String line=null;
        String topic=null;
		String plandate=null;
		String starttime=null;
		String duration=null;
		String location=null;
		String status=null;
		String trainer=null;
		String topicId=null;
        StringBuffer newtrngpln = new StringBuffer();
        JSONArray jsonArray = new JSONArray();
        JSONParser parser = new JSONParser();

		try 
        {
	        PreparedStatement prpdstmtInTrCal = null;
			PreparedStatement prpdstmtInTrCal1 = null;
	        PreparedStatement prpdstmtInTrCal2 = null;
	        PreparedStatement prpdstmtInTrCal3 = null;
	        BufferedReader reader = request.getReader();
        	while ((line = reader.readLine()) != null)
        		newtrngpln.append(line);
 
            Object obj = parser.parse(newtrngpln.toString());
            jsonArray = (JSONArray) obj;
            
            for(int i = 0; i < jsonArray.size();i++)
            {
            	JSONObject jobj =  (JSONObject) jsonArray.get(i);
            	Object value;
            	topic = (String) jobj.get("topic");
            	plandate = (String) jobj.get("plandate");
            	plandate = plandate.substring(0,10);
            	starttime = (String) jobj.get("starttime");
             	duration = (String) jobj.get("duration");
            	location= (String) jobj.get("location");
            	status = (String) jobj.get("status");
            	trainer = String.valueOf(jobj.get("trainer"));
            }
        
            //select the training topic id with the selected training topic name
            String sql = "select Training_Topic_ID from Tbl_Training_Topics where Training_Topic_Name =?";
            prpdstmtInTrCal = con.prepareStatement(sql);
            prpdstmtInTrCal.setString(1, topic);
            ResultSet selTopicIdRs = prpdstmtInTrCal.executeQuery();
            prpdstmtInTrCal.clearParameters();
	        while(selTopicIdRs.next())
			{
				JSONObject selTopicIdObj = new JSONObject();
				selTopicIdObj.put("topicId", selTopicIdRs.getString("Training_Topic_ID"));
				topicId = (String) selTopicIdObj.get("topicId");
			}
	        
	      //SQL Query to check for any active training setup in the Tbl_Training_Calendar.
	        String sql1 = "SELECT * from Tbl_Training_Calendar where (Training_Topic_ID = ? and Planned_Date= ? and Status <> 'Cancelled') or (Planned_Date= ? and Status <> 'Cancelled' and Start_Time = ? and Location = ?) or (Planned_Date= ? and Status <> 'Cancelled' and Start_Time = ? and Trainer = ?)";
            prpdstmtInTrCal1 = con.prepareStatement(sql1);
	        prpdstmtInTrCal1.setString(1, topicId);
	        prpdstmtInTrCal1.setString(2, plandate);
	        prpdstmtInTrCal1.setString(3, plandate);
	        prpdstmtInTrCal1.setString(4, starttime);
	        prpdstmtInTrCal1.setString(5, location);
	        prpdstmtInTrCal1.setString(6, plandate);
	        prpdstmtInTrCal1.setString(7, starttime);
	        prpdstmtInTrCal1.setString(8, trainer);
	        
    		ResultSet selTrainingsRs = prpdstmtInTrCal1.executeQuery();
    		prpdstmtInTrCal1.clearParameters();
            if (selTrainingsRs.next())
            {
            	//The training already present in the Training Calendar Table on the same date.
    			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
    			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
    			response.setHeader("Expires", "0"); // Proxies.
            	response.sendError(HttpServletResponse.SC_NOT_ACCEPTABLE);
            }
            else
            {
            	//SQL Query to verify the trainer information.
            	String sql2 = "SELECT * from Tbl_Employee_Details where Emp_ID = ?";
            	prpdstmtInTrCal2 = con.prepareStatement(sql2);
            	prpdstmtInTrCal2.setString(1, trainer);
            	ResultSet selTrainerRS = prpdstmtInTrCal2.executeQuery();
            	prpdstmtInTrCal2.clearParameters();
            	if(selTrainerRS.next())
            	{
            		//SQL Query to insert Training Schedules to the Tbl_Training_Calendar table.
            		String sql3 = "INSERT INTO Tbl_Training_Calendar (Training_Topic_ID,Planned_Date,Actual_Date,Status,Planned_Hrs,Actual_Hrs,Location,Trainer,Start_Time) VALUES (?, ?, ?, ?, ?, ?, ?, ?,?)";
            		prpdstmtInTrCal3 = con.prepareStatement(sql3);
            		prpdstmtInTrCal3.setString(1, topicId);
            		prpdstmtInTrCal3.setString(2, plandate);
            		prpdstmtInTrCal3.setString(3, plandate);
            		prpdstmtInTrCal3.setString(4, status);
            		prpdstmtInTrCal3.setString(5, duration);
            		prpdstmtInTrCal3.setString(6, duration);
            		prpdstmtInTrCal3.setString(7, location);
            		prpdstmtInTrCal3.setString(8, trainer);
            		prpdstmtInTrCal3.setString(9, starttime);
            		prpdstmtInTrCal3.executeUpdate();
            		prpdstmtInTrCal3.clearParameters();
            	}
            	else
            	{
        			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
        			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
        			response.setHeader("Expires", "0"); // Proxies.
            		response.sendError(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
            	}
            }
        }
        catch(Exception e)
		{
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
        	response.sendError(HttpServletResponse.SC_FORBIDDEN);
        	e.printStackTrace();
        }
	}

	//Function to update the training attendance by the Trainee.
	private void updateTrainingAttendance(HttpServletRequest request, HttpServletResponse response, Connection con) throws IOException 
	{
		String line = "";
        String topic="";
		String plandate="";
		String attendancestatus="";
		String userid="";
		String topicId="";
		StringBuffer recordAttendance = new StringBuffer();
        JSONArray jsonArray = new JSONArray();
        JSONParser parser = new JSONParser();
        
		try 
        {
	        PreparedStatement prpdstmtUpTrAt = null;
			PreparedStatement prpdstmtUpTrAt1 = null;
            PreparedStatement prpdstmtUpTrAt2 = null;
            PreparedStatement prpdstmtUpTrAt3 = null;
            PreparedStatement prpdstmtUpTrAt4 = null;
			BufferedReader reader = request.getReader();
        	line = reader.readLine();
        	recordAttendance.append(line);

            Object obj = parser.parse(recordAttendance.toString());
            jsonArray = (JSONArray) obj;
            
            for(int i = 0; i < jsonArray.size();i++)
            {
            	JSONObject jobj =  (JSONObject) jsonArray.get(i);
            	topic = (String) jobj.get("topic");
            	plandate = (String) jobj.get("plandate");
            	plandate = plandate.substring(0,10);
            	attendancestatus = (String) jobj.get("attendancestatus");
            	userid = (String) jobj.get("userid");
            }
            
            //select the training topic id with the selected training topic name
            String sql = "select Training_Topic_ID from Tbl_Training_Topics where Training_Topic_Name = ?";
            prpdstmtUpTrAt = con.prepareStatement(sql);
            prpdstmtUpTrAt.setString(1, topic);
            ResultSet selTopicIdRs = prpdstmtUpTrAt.executeQuery();
            prpdstmtUpTrAt.clearParameters();
            while(selTopicIdRs.next())
            {
            	JSONObject selTopicIdObj = new JSONObject();
            	selTopicIdObj.put("topicId", selTopicIdRs.getString("Training_Topic_ID"));
            	topicId = (String) selTopicIdObj.get("topicId");
            }
            
            if (attendancestatus.equals("Not Attended"))
            {
            	//SQL Query to delete the record from the Tbl_Training_Attendance table
		        String sqldelete = "delete from Tbl_Training_Attendance where Date = ? and Training_Topic_ID = ? and Emp_ID= ?";
		        prpdstmtUpTrAt1 = con.prepareCall(sqldelete);
		        prpdstmtUpTrAt1.setString(1, plandate);
		        prpdstmtUpTrAt1.setString(2, topicId);
		        prpdstmtUpTrAt1.setString(3, userid);
		        prpdstmtUpTrAt1.executeUpdate();
		        prpdstmtUpTrAt1.clearParameters();
            }
            else
            {  			        
            //SQL Query to Add/update Training attendance to the Tbl_Training_Attendance.
                String sqlsel = "SELECT * from Tbl_Training_Attendance where Training_Topic_ID = ? and Date= ? and Emp_ID= ?";
                prpdstmtUpTrAt2 = con.prepareStatement(sqlsel);
                prpdstmtUpTrAt2.setString(1, topicId);
                prpdstmtUpTrAt2.setString(2, plandate);
                prpdstmtUpTrAt2.setString(3, userid);
                ResultSet selRecorddRs = prpdstmtUpTrAt2.executeQuery();
                prpdstmtUpTrAt2.clearParameters();
            if (selRecorddRs.next())
            {
            	//SQL Query to update Training Status to the Tbl_Training_Attendance table by the Trainee
		        String sqlupdate = "update Tbl_Training_Attendance set Status = ? where Date = ? and Training_Topic_ID = ? and Emp_ID= ?";
		        prpdstmtUpTrAt3 = con.prepareStatement(sqlupdate);
		        prpdstmtUpTrAt3.setString(1, attendancestatus);
		        prpdstmtUpTrAt3.setString(2, plandate);
		        prpdstmtUpTrAt3.setString(3, topicId);
		        prpdstmtUpTrAt3.setString(4, userid);
		        prpdstmtUpTrAt3.executeUpdate();
		        prpdstmtUpTrAt3.clearParameters();
            }
            else
            {			        
            	//SQL Query to add Training Status to the Tbl_Training_Attendance table by the Trainee
		        String sqlupdate1 = "INSERT INTO Tbl_Training_Attendance (Emp_ID,Training_Topic_ID,Status,Date) VALUES (?, ?, ?, ?)";
		        prpdstmtUpTrAt4 = con.prepareStatement(sqlupdate1);
		        prpdstmtUpTrAt4.setString(1, userid);
		        prpdstmtUpTrAt4.setString(2, topicId);
		        prpdstmtUpTrAt4.setString(3, attendancestatus);
		        prpdstmtUpTrAt4.setString(4, plandate);
		        prpdstmtUpTrAt4.executeUpdate();
		        prpdstmtUpTrAt4.clearParameters();
            }
            }
        }
        catch(Exception e)
		{
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
        	response.sendError(HttpServletResponse.SC_FORBIDDEN);
        	e.printStackTrace();
        }
	}

	//Function to update the training status by the trainer.
	private void updateTrainingStatus(HttpServletRequest request, HttpServletResponse response, Connection con) throws IOException 
	{
        String topic=null;
		String plandate=null;
		String updateddate=null;
		String updatedduration=null;
		String updatedstatus=null;
		String line = null;
		String topicId =null;
		StringBuffer updatestatus = new StringBuffer();
        JSONArray jsonArray = new JSONArray();
        JSONParser parser = new JSONParser();
		try 
        {
	        PreparedStatement prpdstmtUpTrSt = null;
	        PreparedStatement prpdstmtUpTrSt1 = null;
			BufferedReader reader = request.getReader();
        	line = reader.readLine();
        	updatestatus.append(line);         

            Object obj = parser.parse(updatestatus.toString());
            jsonArray = (JSONArray) obj;			            
            
            for(int i = 0; i < jsonArray.size();i++)
            {
            	JSONObject jobj =  (JSONObject) jsonArray.get(i);
            	Object value;
            	topic = (String) jobj.get("topic");
            	plandate = (String) jobj.get("plandate");
            	updateddate = (String) jobj.get("updateddate");
            	updatedduration = jobj.get("updatedduration").toString();
            	updatedstatus = (String) jobj.get("updatedstatus");
            	String trainer = (String) jobj.get("trainer");
            }

			//select the training topic id with the selected training topic name
            String sql = "select Training_Topic_ID from Tbl_Training_Topics where Training_Topic_Name = ?";
            prpdstmtUpTrSt = con.prepareStatement(sql);
            prpdstmtUpTrSt.setString(1, topic);            
            ResultSet selTopicIdRs = prpdstmtUpTrSt.executeQuery();
            prpdstmtUpTrSt.clearParameters();
            while(selTopicIdRs.next())
            {
            	JSONObject selTopicIdObj = new JSONObject();
            	selTopicIdObj.put("topicId", selTopicIdRs.getString("Training_Topic_ID"));
            	topicId = (String) selTopicIdObj.get("topicId");
            }
		        
            //SQL Query to update Training Status to the Tbl_Training_Calendar table by the Trainer
            String sqlupd = "update Tbl_Training_Calendar set Actual_Date = ?, Actual_Hrs = ?, Status = ? where Training_Topic_ID = ? and Planned_Date = ?";
            prpdstmtUpTrSt1 = con.prepareStatement(sqlupd);
            prpdstmtUpTrSt1.setString(1, updateddate);
            prpdstmtUpTrSt1.setString(2, updatedduration);
            prpdstmtUpTrSt1.setString(3, updatedstatus);
            prpdstmtUpTrSt1.setString(4, topicId);
            prpdstmtUpTrSt1.setString(5, plandate);
            prpdstmtUpTrSt1.executeUpdate();
            prpdstmtUpTrSt1.clearParameters();
        }
        catch(Exception e)
		{
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
        	response.sendError(HttpServletResponse.SC_FORBIDDEN);
        	e.printStackTrace();
        }
	}

    //Function to display all the trainings scheduled by the login user as trainer
	private void getTrainingBasedOnTrainer(HttpServletRequest request, HttpServletResponse response, Connection con) throws IOException 
	{
		String TrnrEmpID = "";
		String Date = "";
        String trline = "";
        String userRole="";
		StringBuffer trainerEmpID = new StringBuffer();
        JSONObject jsonObj = new JSONObject();
        JSONParser tparser = new JSONParser();
		JSONArray trainingArray = new JSONArray();
        
        try 
        {
	        PreparedStatement prpdstmtGtTr = null;
	        PreparedStatement prpdstmtGtTr1 = null;
	        PreparedStatement prpdstmtGtTr2 = null;
        	BufferedReader trainerEmpIDreader = request.getReader();
        	trline = trainerEmpIDreader.readLine();
        	trainerEmpID.append(trline);   

            Object tobj = tparser.parse(trainerEmpID.toString());
            jsonObj = (JSONObject) tobj; 
            
            TrnrEmpID = (String)jsonObj.get("trnrid");
            Date = (String)jsonObj.get("Date");
                        
            //SQL query to check whether the logged in user is an Admin user or not. 
            String sqlgettr = "select User_Role from Tbl_Employee_Details where Emp_ID = ?";
            prpdstmtGtTr = con.prepareStatement(sqlgettr);
            prpdstmtGtTr.setString(1, TrnrEmpID);            
            ResultSet userRs = prpdstmtGtTr.executeQuery();
            prpdstmtGtTr.clearParameters();
    		while (userRs.next())
    		{
				userRole = userRs.getString("User_Role");
    		}
			//SQL Query to get all training from the Tbl_Training_Calendar table based on the selected Date.
    		if(userRole.equalsIgnoreCase("Admin"))
    		{
    			String sqlgettr1 = "select A.Training_Topic_Name, A.Training_Area, B.Planned_Date, B.Status, B.Planned_Hrs, A.Functional_Area from Tbl_Training_Topics A inner join Tbl_Training_Calendar B on B.Training_Topic_ID = A.Training_Topic_ID where B.Planned_Date= ? and B.Status <> 'Cancelled'";
    			
    			prpdstmtGtTr1 = con.prepareStatement(sqlgettr1);
    			prpdstmtGtTr1.setString(1,Date);
    			ResultSet trainingAdminRs = prpdstmtGtTr1.executeQuery();
    			prpdstmtGtTr1.clearParameters();
    			while(trainingAdminRs.next())
    			{
    				JSONObject trainingObj = new JSONObject();
    				trainingObj.put("topic", trainingAdminRs.getString("Training_Topic_Name"));
    				trainingObj.put("Area", trainingAdminRs.getString("Training_Area"));
    				trainingObj.put("FunctionalArea", trainingAdminRs.getString("Functional_Area"));
    				trainingObj.put("planneddate", trainingAdminRs.getString("Planned_Date"));
    				trainingObj.put("status", trainingAdminRs.getString("Status"));
    				trainingObj.put("duration", trainingAdminRs.getString("Planned_Hrs"));
			
    				trainingArray.add(trainingObj);
    			}
    		}
			//SQL Query to get all training based on the trainer id and selected date from the Tbl_Training_Calendar table 	
    		else
    		{		
    			String sqlgettr2 = "select A.Training_Topic_Name, A.Training_Area, B.Planned_Date, B.Status, B.Planned_Hrs, A.Functional_Area from Tbl_Training_Topics A inner join Tbl_Training_Calendar B on B.Training_Topic_ID = A.Training_Topic_ID where B.Trainer = ? and B.Planned_Date= ? and B.Status <> 'Cancelled'";
    			prpdstmtGtTr2 = con.prepareStatement(sqlgettr2);
    			prpdstmtGtTr2.setString(1, TrnrEmpID);
    			prpdstmtGtTr2.setString(2, Date);
    			ResultSet trainingRs = prpdstmtGtTr2.executeQuery();
    			prpdstmtGtTr2.clearParameters();
    			while(trainingRs.next())
    			{
    				JSONObject trainingObj = new JSONObject();
    				trainingObj.put("topic", trainingRs.getString("Training_Topic_Name"));
    				trainingObj.put("Area", trainingRs.getString("Training_Area"));
    				trainingObj.put("FunctionalArea", trainingRs.getString("Functional_Area"));
    				trainingObj.put("planneddate", trainingRs.getString("Planned_Date"));
    				trainingObj.put("status", trainingRs.getString("Status"));
    				trainingObj.put("duration", trainingRs.getString("Planned_Hrs"));
			
    				trainingArray.add(trainingObj);
    			}
    		}
			response.setContentType("text/json");
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
			response.getWriter().write(trainingArray.toJSONString());  	//Response to send the training scheduled for a trainer
		}
	    catch (Exception e)
        {
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
	    	response.sendError(HttpServletResponse.SC_FORBIDDEN);
	    	e.printStackTrace();			        	
	    }	
	}
    
	//Function to display all the trainings scheduled based on the planned date selected by the user.
	private void getTrainingDate(HttpServletRequest request, HttpServletResponse response, Connection con) throws IOException 
	{
		String Date = "";
        String trline = null;
		StringBuffer RecordDate = new StringBuffer();
        JSONObject jsonObj = new JSONObject();
        JSONParser tparser = new JSONParser();
		JSONArray trainingRecordArray = new JSONArray();
        
        try 
        {
        	BufferedReader RecordDatereader = request.getReader();
        	trline = RecordDatereader.readLine();
        	RecordDate.append(trline);

            Object tobj = tparser.parse(RecordDate.toString());
            jsonObj = (JSONObject) tobj;        
            Date = (String)jsonObj.get("Date");
            
            //SQL Query to get all training based on the plandate from the Tbl_Training_Calendar table 			
	        PreparedStatement prpdstmt = con.prepareStatement("select A.Training_Topic_Name, B.Planned_Date from Tbl_Training_Topics A inner join Tbl_Training_Calendar B on B.Training_Topic_ID = A.Training_Topic_ID where B.Planned_Date= ? and B.Status <> 'Cancelled'");
	        prpdstmt.setString(1, Date);
	        
	        ResultSet trainingRs = prpdstmt.executeQuery();
	        prpdstmt.clearParameters();
			while(trainingRs.next())
			{
				JSONObject trainingObj = new JSONObject();
				trainingObj.put("topic", trainingRs.getString("Training_Topic_Name"));
				trainingObj.put("plannedDate", trainingRs.getString("Planned_Date"));
				trainingRecordArray.add(trainingObj);
			}
			response.setContentType("text/json");
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
			response.getWriter().write(trainingRecordArray.toJSONString());  	//Response to send the training scheduled on a date
		}
	    catch (Exception e)
        {
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
	    	response.sendError(HttpServletResponse.SC_FORBIDDEN);
	    	e.printStackTrace();			        	
	    }
	}

	//Function for Attendance Report generation
	private void trainingAttendanceReport(HttpServletRequest request, HttpServletResponse response, Connection con) throws IOException 
	{
		String startDate = null;
		String endDate = null;
        String trline = null;
		StringBuffer ReportDate = new StringBuffer();
        JSONObject jsonObj = new JSONObject();
        JSONParser tparser = new JSONParser();
		JSONArray trainingAttendanceArray = new JSONArray();

        try 
        {
	        PreparedStatement prpdstmtTrAtRp = null;
        	BufferedReader ReportDatereader = request.getReader();
        	trline = ReportDatereader.readLine();
        	ReportDate.append(trline);
  
            Object tobj = tparser.parse(ReportDate.toString());
            jsonObj = (JSONObject) tobj;        
            startDate = (String)jsonObj.get("startDate");
            endDate = (String)jsonObj.get("endDate");

            //SQL Query to get all training attendance for Report generation 			
            String sqlAtRp = "select q3.Training_Area,q3.Date,q3.Training_Topic_Name, C.Emp_Name, q3.Actual_Hrs, q3.Attendance from "
            		+ "(select q2.Training_Area,q2.Date,q2.Training_Topic_Name,q2.Attendance, B.Trainer, B.Actual_Hrs from "
            		+ "(select q1.Training_Topic_ID,q1.Date,q1.Attendance,A.Training_Area,A.Training_Topic_Name from Tbl_Training_Topics A inner join "
            		+ "(select Training_Topic_ID,Date, COUNT(Emp_ID) as Attendance from Tbl_Training_Attendance "
            		+ "where Date between ? and ? and Status = 'Attended' group by Date, Training_Topic_ID) as q1 "
            				+ "on A.Training_Topic_ID = q1.Training_Topic_ID) as q2 inner join Tbl_Training_Calendar B on "
            				+ "q2.Training_Topic_ID = B.Training_Topic_ID and q2.Date = B.Planned_Date) q3 inner join Tbl_Employee_Details C on "
            				+ "q3.Trainer = C.Emp_ID order by q3.Date";
		
             prpdstmtTrAtRp = con.prepareStatement(sqlAtRp);
             prpdstmtTrAtRp.setString(1, startDate);
             prpdstmtTrAtRp.setString(2, endDate);
             
             ResultSet attendanceReportRs = prpdstmtTrAtRp.executeQuery();
             prpdstmtTrAtRp.clearParameters();
		
			while(attendanceReportRs.next())
			{
				JSONObject trainingObj = new JSONObject();
				trainingObj.put("area", attendanceReportRs.getString("Training_Area"));
				trainingObj.put("topicName", attendanceReportRs.getString("Training_Topic_Name"));
				trainingObj.put("trainer", attendanceReportRs.getString("Emp_Name"));
				trainingObj.put("date", attendanceReportRs.getString("Date"));
				trainingObj.put("duration", attendanceReportRs.getString("Actual_Hrs"));	
				trainingObj.put("noOfAttendees", attendanceReportRs.getString("Attendance"));							
				trainingAttendanceArray.add(trainingObj);
			}
			response.setContentType("text/json");
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
			response.getWriter().write(trainingAttendanceArray.toJSONString());  	//Response to send the training attendance for report generation
        }
        catch (Exception e)
        {
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
        	response.sendError(HttpServletResponse.SC_FORBIDDEN);
        	e.printStackTrace();			        	
	    }
	}

	//Function for Scheduled Training Report generation
	private void scheduledTrainingReport(HttpServletRequest request, HttpServletResponse response, Connection con) throws IOException 
	{
		String startDate = null;
		String endDate = null;
        String trline = null;
		StringBuffer ReportDate = new StringBuffer();
        JSONObject jsonObj = new JSONObject();
        JSONParser tparser = new JSONParser();
		JSONArray trainingReportArray = new JSONArray();
		
		try
		{
	        PreparedStatement prpdstmtScTrRp = null;
			
			BufferedReader ReportDatereader = request.getReader();
	        trline = ReportDatereader.readLine();
	        ReportDate.append(trline);
	
	        Object tobj = tparser.parse(ReportDate.toString());
	        jsonObj = (JSONObject) tobj;        
	        startDate = (String)jsonObj.get("startDate");
	        endDate = (String)jsonObj.get("endDate");
	        
	        //SQL Query to get all training scheduled for Report generation 			
			String sqlScTrRp = "select q1.Training_Area, q1.Training_Topic_Name, q1.Planned_Date, q1.Status, C.Emp_Name from "
					+ "(select B.Training_Area,B.Training_Topic_Name,A.Planned_Date,A.Trainer,A.Status from Tbl_Training_Calendar A "
					+ "inner join Tbl_Training_Topics B on A.Training_Topic_ID = B.Training_Topic_ID "
					+ "where A.Planned_Date between ? and ? and Status <> 'Cancelled') as q1 inner join Tbl_Employee_Details C on q1.Trainer = C.Emp_ID order by q1.Planned_Date";
			
			prpdstmtScTrRp = con.prepareStatement(sqlScTrRp);
			prpdstmtScTrRp.setString(1, startDate);
			prpdstmtScTrRp.setString(2, endDate);
			ResultSet trainingReportRs = prpdstmtScTrRp.executeQuery();
			prpdstmtScTrRp.clearParameters();
			while(trainingReportRs.next())
			{
				JSONObject trainingObj = new JSONObject();
				trainingObj.put("area", trainingReportRs.getString("Training_Area"));
				trainingObj.put("topicName", trainingReportRs.getString("Training_Topic_Name"));
				trainingObj.put("trainer", trainingReportRs.getString("Emp_Name"));
				trainingObj.put("date", trainingReportRs.getString("Planned_Date"));
				trainingObj.put("status", trainingReportRs.getString("Status"));
				trainingReportArray.add(trainingObj);
			}
			response.setContentType("text/json");
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
			response.getWriter().write(trainingReportArray.toJSONString());  	//Response to send the training schedule for report generation
		}
		catch(Exception e)
		{
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
			response.sendError(HttpServletResponse.SC_FORBIDDEN);
			e.printStackTrace();
		}
	}

	//Function to establish the database connection.
	private Connection getConnection() {
	
		Connection con = null;
		try
		{
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			con = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=Academydatabase;user=superadmin;password=Port123tel*");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return con;
		
	}
	
	//Function for login
	private void login(HttpServletRequest request, HttpServletResponse response, Connection con) throws IOException 
	{			
		StringBuffer logindata = new StringBuffer();
        String loginline = "";
        JSONArray loginArray = new JSONArray();
        String logid = "";
        String pwd = ""; 
        String dn = "";
        
        //String userPrincipalName = "";
        String strloginres = "";
        String errorCode = "";
        JSONArray ljsonArray = new JSONArray();
        JSONParser lparser = new JSONParser();
        
        try
        {        
	        BufferedReader loginreader = request.getReader();
	        loginline = loginreader.readLine();
	    	logindata.append(loginline);
	    	PreparedStatement prpdstmtlog = null;
	        Object lobj = lparser.parse(logindata.toString());
	        ljsonArray = (JSONArray) lobj;
            JSONObject loginresult = new JSONObject();
	        
	        //Ensure that the array is valid.
	        if(ljsonArray.size() > 0)
	        {
	        	//Only a single object is passed. Hence hence we should index the 0th position
	        	JSONObject ljobj =  (JSONObject) ljsonArray.get(0);
	        	logid = (String) ljobj.get("loginid");
	        	pwd = (String) ljobj.get("passwordtxt");
	        	strloginres = (String) ljobj.get("loginid");
	        	//userPrincipalName = logid+"@CTS.COM";
	        	if(logid == null || logid.isEmpty())
	        	{
	        		logid = "";
	        		strloginres = "";
	        		errorCode = "SC_BAD_REQUEST";
		       		//response.sendError(HttpServletResponse.SC_BAD_REQUEST); //Employee not found in LDAP.
	        	}
	        	if(pwd == null || pwd.isEmpty())
	        	{
	        		pwd = "";
	        		errorCode = "SC_BAD_REQUEST";
		       		//response.sendError(HttpServletResponse.SC_BAD_REQUEST); //Employee not found in LDAP.
	        	}
	        }
	        else
	        {
	        	errorCode = "SC_BAD_REQUEST";
	        	//response.sendError(HttpServletResponse.SC_BAD_REQUEST); //Login credentials are missing
	        }	        
        	
        	if(errorCode != "SC_BAD_REQUEST")
        	{
        		try 
        		{
        			//User credential verification using LDADP	        
			        Hashtable<String, String> env = new Hashtable<String, String>();
			        env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
			        env.put(Context.PROVIDER_URL, "ldap://10.224.133.60:389/DC=cts;DC=com");
			        // Needed for the Bind (User Authorized to Query the LDAP server)
			        env.put(Context.SECURITY_AUTHENTICATION, "simple");
			        ////Binding the LDAP authentication with the distinguished name of Service Account ID = STelstraAcademy
			        // CN=TelstraAcademy,OU=ServiceAccounts,OU=India,OU=APAC,OU=Cognizant,DC=cts,DC=com
			        // T111111#
			        env.put(Context.SECURITY_PRINCIPAL, "CN=TelstraAcademy,OU=ServiceAccounts,OU=India,OU=APAC,OU=Cognizant,DC=cts,DC=com");
			        env.put(Context.SECURITY_CREDENTIALS, "Pa86868686*");
			        
			        // Create the initial context
			        DirContext ctx = new InitialDirContext(env);
			        DirContext ctx1 = null;
			            
			        //LDAP Search for the user who is trying to login
			        SearchControls ctls = new SearchControls();
			        	
			        ctls.setSearchScope(SearchControls.SUBTREE_SCOPE);
			       	
			        //String filter = "CN=TelstraAcademy,OU=ServiceAccounts,OU=India,OU=APAC,OU=Cognizant,DC=cts,DC=com";
			        String filter = "(&(objectClass=user)(sAMAccountName=" + logid + "))";
			        	
			        NamingEnumeration<SearchResult> results = ctx.search("", filter, ctls);
			        	
			        if (results.hasMore()) {
			       		Properties env1 = new Properties();
			               env1.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
			               env1.put(Context.PROVIDER_URL, "ldap://10.224.133.60:389/DC=cts;DC=com");
			               SearchResult result = (SearchResult) results.next();
			               Attributes attrs = result.getAttributes();
			               Attribute dnAttr = attrs.get("distinguishedName");
			               dn = (String) dnAttr.get();
			               env1.put(Context.SECURITY_PRINCIPAL, dn);
			               env1.put(Context.SECURITY_CREDENTIALS,pwd);
			    	       ctx1 = new InitialDirContext(env1);
			               //new InitialDirContext(env1);
			        }
			        else
			        {
						response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
						response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
						response.setHeader("Expires", "0"); // Proxies.
			        	response.sendError(HttpServletResponse.SC_BAD_REQUEST); //Employee not found in LDAP.
			        }            
		
			        //To proceed with login           
			        loginresult.put("loginres", strloginres);
						
			        //Verify the user role by querying the Tbl_Employee_Details table.
			        String sqlLog = "select User_Role, Emp_Name, Project, Stream from Tbl_Employee_Details where Emp_ID = ?";
			        prpdstmtlog = con.prepareStatement(sqlLog);
			        prpdstmtlog.setString(1, logid);
			        ResultSet userroleRs = prpdstmtlog.executeQuery();
			        prpdstmtlog.clearParameters();
			        if(userroleRs.next())
			        {	
				    	loginresult.put("role", userroleRs.getString("User_Role"));
				       	loginresult.put("empName", userroleRs.getString("Emp_Name"));
				       	loginresult.put("StreamFromEmpTbl", userroleRs.getString("Stream"));
				       	String projectName = userroleRs.getString("Project");
				       	
				       	if (projectName.equals("Telstra"))
				       	{
				       	//Successfully logged in. Create cookies now
					       	//Cookie UserIDCookie = new Cookie("userid", (String) loginresult.get("loginres"));
					       	//Cookie UserNameCookie = new Cookie("username", (String) loginresult.get("empName"));
					       // setting cookie to expiry in 60 mins
					       	//UserIDCookie.setMaxAge(60 * 60);
					       	//UserNameCookie.setMaxAge(60 * 60);
					        //response.addCookie(UserIDCookie);
					        //response.addCookie(UserNameCookie);
				       	}
				       	else
				       	{
					       	//The user is not part of Telstra Project, make the login fail
							response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
							response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
							response.setHeader("Expires", "0"); // Proxies.
				       		response.sendError(HttpServletResponse.SC_PRECONDITION_FAILED); //User not found in Telstra Project.
				       	}				       	
				    }
				    else
				    {
				       	//Couldn't find the role, make the login fail
						response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
						response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
						response.setHeader("Expires", "0"); // Proxies.
				    	response.sendError(HttpServletResponse.SC_PRECONDITION_FAILED); //Role not found in Telstra Employee Details table.
				    }		        
			        
			        loginArray.add(loginresult);
					response.setContentType("text/json");
					response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
					response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
					response.setHeader("Expires", "0"); // Proxies.
					response.getWriter().write(loginArray.toJSONString()); //Response of credential verification.	            
					//End of login procedure
		            ctx.close();
		            ctx1.close();
			         
		        } catch (AuthenticationNotSupportedException ex) {
		            System.out.println("The authentication is not supported by the server");
					response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
					response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
					response.setHeader("Expires", "0"); // Proxies.
		            response.sendError(HttpServletResponse.SC_FORBIDDEN);
		        } catch (AuthenticationException ex) {
		            System.out.println("incorrect password or username");
					response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
					response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
					response.setHeader("Expires", "0"); // Proxies.
		            response.sendError(HttpServletResponse.SC_BAD_REQUEST);
		        } catch (NamingException ex) {
		            System.out.println("error when trying to create the context");
					response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
					response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
					response.setHeader("Expires", "0"); // Proxies.
		            response.sendError(HttpServletResponse.SC_BAD_REQUEST);
		        }	        
		        //End of user credential verification using LDAP
        	}
        	else
        	{
    			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
    			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
    			response.setHeader("Expires", "0"); // Proxies.
        		response.sendError(HttpServletResponse.SC_BAD_REQUEST); //Login credentials are missing
        	}
	        }
		catch(Exception e)
		{
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setHeader("Expires", "0"); // Proxies.
			response.sendError(HttpServletResponse.SC_FORBIDDEN);
			e.printStackTrace();
		}

	}
}
