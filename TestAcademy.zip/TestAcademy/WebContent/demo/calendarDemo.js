/**
 * calendarDemoApp - 0.9.0
 */
angular.module('calendarDemoApp', ['ui.calendar', 'ui.bootstrap', 'ngCookies','nvd3'])
        .controller('CalendarCtrl', CalendarCtrl)
		.filter('pagination', pagination)
		.directive('ngEnter', function () 
				{ return function (scope, element, attrs) 
					{ element.bind("keydown keypress", function (keyenterevent) 
							{ if(keyenterevent.which === 13) 
								{ scope.$apply(function ()
										{scope.$eval(attrs.ngEnter);});
								keyenterevent.preventDefault();
								}
							});
					};
				});

function CalendarCtrl($scope, $cookieStore, $compile, $timeout, uiCalendarConfig, $http, $window) {
	
	var date = new Date();
    var d = date.getDate();
    var m = date.getMonth();
    var nyr = date.getFullYear();
    var currentdate = "";
    var skillAvailSts = false;
    
    //Miscellaneous tab
	$scope.newAddEmpId = "";
	$scope.skillEmpSearch = "";
	$scope.newEmpName = "";
	$scope.newDesignation = "";
	$scope.newEmailId = "";
	$scope.newStream = "";
	$scope.newUserRole = "User";
	$scope.newProjectEmployee = "Telstra";
	$scope.newProjectRole = "Analyst";
	
    
    //Add New Training Tab 
	$scope.countOne = false;
	$scope.countTwo = false;
	$scope.countThree = false;
	$scope.countFour = false;
	$scope.countFive = false;
	
	$scope.addArea = "existingArea";
	$scope.newTopicOne = "";
	$scope.newTopicTwo = "";
	$scope.newTopicThree = "";
	$scope.newTopicFour = "";
	$scope.newTopicFive = "";
	$scope.newArea = "";
	$scope.showdwnld = false;
	
	$scope.empSkillDetails = [];
	$scope.empSkillDetailsHdr = [];
	$scope.streamData = "";
	
	$scope.proficiencyOn = false;
   
    //AngularJS Pagination and Search
    $scope.curPage = 0;
    $scope.pageSize = 10;  
    $scope.emppageSize = 5; 
    $scope.empcurindex = 2;
    
    $scope.chart1show = true;
    $scope.chart2show = true;
    $scope.chart3show = true;
    $scope.chart4show = true;
    $scope.chart1Closeshow = false;
    $scope.chart2Closeshow = false;
    $scope.chart3Closeshow = false;
    $scope.chart4Closeshow = false;
    
    $scope.graphBorderscope = "graphBorder";
    
    $scope.graphheight = "200px";

    
    $scope.reSizeClick = function(streamval,chartname)
    {
    	if(chartname == "chart1")
    	{
    	    $scope.chart2show = false;
    	    $scope.chart3show = false;
    	    $scope.chart4show = false;
    	    $scope.chart1Closeshow = true;
    	}
    	else if(chartname == "chart2")
    	{
    	    $scope.chart1show = false;
    	    $scope.chart3show = false;
    	    $scope.chart4show = false;
    	    $scope.chart2Closeshow = true;
    	}
    	else if(chartname == "chart3")
    	{
    	    $scope.chart1show = false;
    	    $scope.chart2show = false;
    	    $scope.chart4show = false;
    	    $scope.chart3Closeshow = true;
    	}
    	else if(chartname == "chart4")
    	{
    	    $scope.chart1show = false;
    	    $scope.chart2show = false;
    	    $scope.chart3show = false;
    	    $scope.chart4Closeshow = true;
    	}
        $scope.graphBorderscope = "fullgraphBorder";
        $scope.graphheight = "400px";
        $scope.DshBrdStrmChng(streamval,chartname);    		
    }
    
    $scope.CloseGraphZoom = function(streamvalue, chartnmdata){
        $scope.graphBorderscope = "graphBorder"; 
        $scope.graphheight = "200px";
        $scope.chart1show = true;
        $scope.chart2show = true;
        $scope.chart3show = true;
        $scope.chart4show = true;
        $scope.chart1Closeshow = false;
        $scope.chart2Closeshow = false;
        $scope.chart3Closeshow = false;
        $scope.chart4Closeshow = false;
        $scope.DshBrdStrmChng(streamvalue,chartnmdata);
        
    }
    
    $scope.searchFish   = '';     // set the default search/filter term
    
    // Remove the alert messages on radio button click on Miscellaneous Tab
    $('input:radio[name="newTraining"]').change(
    	    function(){
    	    	$scope.miscellaneousMessage = "";
    	    	miscellaneousalert.hide();
    	    });
    
   //For Bulk Upload - Attendance tab
    var alert = $("#my-alert");    
    alert.on("close.bs.alert", function () {
        alert.hide(); //hide the alert
        return false; //don't remove it from DOM
    });

    //For Indiviual Attendance update tab
    var indUpdAlert = $("#individualUpdate-alert");    
    indUpdAlert.on("close.bs.alert", function () {
    	indUpdAlert.hide(); //hide the alert
        return false; //don't remove it from DOM
    });

    //For Report Tab alert
    var reportalert = $("#report-alert");    
    reportalert.on("close.bs.alert", function () {
        reportalert.hide(); //hide the alert
        return false; //don't remove it from DOM
    });
    
    //For update training status tab
    var updateTrnStsalert = $("#updateTrnSts-alert");    
    updateTrnStsalert.on("close.bs.alert", function () {
    	updateTrnStsalert.hide(); //hide the alert
        return false; //don't remove it from DOM
    });    
    
    //For Miscellaneous tab
    var miscellaneousalert = $("#miscellaneous-alert");    
    miscellaneousalert.on("close.bs.alert", function () {
    	miscellaneousalert.hide(); //hide the alert
        return false; //don't remove it from DOM
    }); 
    
    //For Schedule training tab
    var scheduleTrngalert = $("#scheduleTrng-alert");    
    scheduleTrngalert.on("close.bs.alert", function () {
    	scheduleTrngalert.hide(); //hide the alert
        return false; //don't remove it from DOM
    });  
   
    //For Add New Skill tab
    var addSkillAlert = $("#addSkill-alert");    
    addSkillAlert.on("close.bs.alert", function () {
    	addSkillAlert.hide(); //hide the alert
        return false; //don't remove it from DOM
    });
    
    //For Add Proficiency tab
    var addProficiencyAlert = $("#addProficiency-alert");    
    addProficiencyAlert.on("close.bs.alert", function () {
    	addProficiencyAlert.hide(); //hide the alert
        return false; //don't remove it from DOM
    });   
    
    //For kill Report Tab
    //For Add Proficiency tab
    var skillReportAlert = $("#SkillReport-alert");    
    skillReportAlert.on("close.bs.alert", function () {
    	skillReportAlert.hide(); //hide the alert
        return false; //don't remove it from DOM
    }); 
    
    
    function GetCurrentDate() 
    {
    	currentdate = new Date();
    	var currentday = currentdate.getDate();
    	var currentmonth = currentdate.getMonth()+1; //January is 0!
    	var currentyear = currentdate.getFullYear();

    	if(currentday<10) {
    		currentday='0'+currentday
    	} 

    	if(currentmonth<10) {
    		currentmonth='0'+currentmonth
    	} 

    	currentdate = currentmonth+'/'+currentday+'/'+currentyear;
    	
    	return currentdate;
    }
    
    $scope.endDate = GetCurrentDate();

   $scope.SelectedDate = "";
   $scope.Duration = ""; 
   $scope.clicktitle = "";
   $scope.clickarea = "";
   $scope.clickdate = "";
   $scope.clickduration = "";
   $scope.clickstatus = "";
   $scope.clicklocation = "";
   $scope.clicktrainer = "";
   $scope.tooltipclicked = false;
   $scope.tempReportData = [];
   
   $scope.reportShown = false;

   $scope.importbutton = false;
   
   $scope.adminuser = false;
   $scope.loginvalid = false;
   $scope.mainpills = "";
   $scope.tabcursor = "tabcursoroffclass";
   
     
	$scope.duration = "";
	$scope.plandate = "";
	$scope.starttime = "";
	$scope.location="";
	$scope.status = "Yet to start";
	$scope.updatedStatus = "Completed";
	$scope.attendanceStatus = "Attended";
	$scope.Trainer = "";
	$scope.area = "";
	//Initializes the selectedOption and SelectedArea before getting the date from calendar UI topics select box
	$scope.selectedOption = null;
	$scope.SelectedArea = "";
	$scope.SelectedFunctionalArea = "";
	
	$scope.existingArea = "";
	var newTrainingData = [];
	
	//Initializes variables for login verification and user role verification.
	$scope.loginresponse="";
	$scope.loginstatus = false;

	$scope.StatusMessage = "";
	$scope.reportMessage = "";
	$scope.individualUpdateMessage = "";
	$scope.trainingStatusUpdate = "";
	$scope.updateTrnStsMessage = "";
	$scope.scheduleTrngMessage = "";
	$scope.miscellaneousMessage = "";
	$scope.addSkillMessage = "";
	skillReportAlert.hide();
	$scope.SkilReportlMessage = "";
	var tempSkillEmpID = "";
	
	var lngth = 0;
	var loginiddata="";
	var roledata="";
	var loginEmpName = "";
	$scope.loginEmp = "";
	$scope.StreamFromEmpTbl = "";
	var skillCountPerStream = "";
	
	//New Skill Set Tab
	$scope.newSkillSet = "";
	$scope.newSkillDetail = "";
	
	
	//Initializes variables for searching the Training scheduled for a particular Trainer
	$scope.AvailableTrainings="";
	$scope.selectedTopicOption="";
	$scope.trainnigArea="";
	$scope.trainnigplandate="";
	$scope.trainnigcurrentstatus="";

   $scope.trainingData = [{topic:"", area:"", ScheduledDate:"", Status:""}];
   $scope.trainingRecord = [{topic:"", plannedDate:""}];
   
   $scope.hours = ["0:30","1:00","1:30","2:00","2:30","3:00","3:30","4:00","4:30","5:00","5:30","6:00","6:30","7:00","7:30","8:00"];
   $scope.reports = ["- Select the Report -","Scheduled Trainings","Training Attendance","Trainings by Functional Area"];
   $scope.competencyOption = ["Basic","Intermediate","Proficient","Expert"];
   $scope.competencyUpdateOption = ["Basic","Intermediate","Proficient","Expert","Not Applicable"];
   $scope.validityOption = ["Yes","No"];
   $scope.roles = ["Tester","Senior Tester","Test Architect","Test Engineer","Test Manager","Senior Test Manager","Program Test Manager","Program Manager"];
   $scope.skillReportOptions = ["Skill Summary Report","Employee Skill Report"];
   //$scope.streamToSelect = ["TCO-IRM","TCO-Data","TCO-Defect","TCO-FDR","O2A","Billing","NFT","Digital"];
   //$scope.newStream = $scope.streamToSelect[0];
   $scope.selectedSkillReport = "";
   $scope.SelectedSkillReportStream = "";
   $scope.streamForSkillReport = false;
   $scope.reportHeaderForSkillReport = false;
   $scope.reportHeaderForEmpSkillRpt = false;
   
   $scope.AllFunctionalArea = "";
   
   addProficiencyAlert.hide();
   $scope.addProficicencyMessage = "";
   var dashBrdClk = false;
   
   
   //Display Skill Matrix Dash board	
	$scope.displayDashBoard = function()
	{
		dashBrdClk = true;
		$scope.getAvailableStreamsFunc();
		$scope.findEmpSkillProfData();
	}
	
	//To find the Emp Skill Proficiency Count details for Dash Board
	$scope.findEmpSkillProfData = function(){
		$http.get("getEmpSkillProfGraphData").then(function(response) 
				{
				if (response == "")
					{
						window.alert("No data available for DashBoard.");
					}
				else if (response == 403)
					{
						window.alert("Failed due to technical issues. Please contact the Administrator."); 
					}
				else
					{
						var wholeDashBoardData = response.data;
						$scope.drawGraph(wholeDashBoardData);
					}
				});
	}
	
	//To populate data for Graph
	$scope.drawGraph = function(graphDataAll){
		
		setTimeout(function()
				{
					var w = window,
					d = document,
					e = d.documentElement,
					g = d.getElementsByClassName('graphBorder'),
					x = w.innerWidth || e.clientWidth || g.clientWidth,
					y = w.innerHeight|| e.clientHeight|| g.clientHeight;
					var chart1 = nv.models.multiBarChart().stacked(false).showControls(true);
					var chart2 = nv.models.multiBarChart().stacked(false).showControls(true);
					var chart3 = nv.models.multiBarChart().stacked(false).showControls(true);
					var chart4 = nv.models.multiBarChart().stacked(false).showControls(true);
					chart1.xAxis.rotateLabels(-45);
					chart2.xAxis.rotateLabels(-45);
					chart3.xAxis.rotateLabels(-45);
					chart4.xAxis.rotateLabels(-45);
					
					d3.select('#chart1 svg').datum(graphDataAll[0].dshbrddata).transition().attr("width", x).attr("height", y).duration(500).call(chart1);
					d3.select('#chart2 svg').datum(graphDataAll[1].dshbrddata).transition().attr("width", x).attr("height", y).duration(500).call(chart2);
					d3.select('#chart3 svg').datum(graphDataAll[2].dshbrddata).transition().attr("width", x).attr("height", y).duration(500).call(chart3);
					d3.select('#chart4 svg').datum(graphDataAll[3].dshbrddata).transition().attr("width", x).attr("height", y).duration(500).call(chart4);
				}, 400);
	}
   
	//Display Graph based on the Stream selected
	$scope.DshBrdStrmChng = function(chartStreamValue, chartid){
		//var yAxisMax1 = 0;
		if(chartStreamValue != null && chartid != null)
		{
			var dshBrdchartStreamValue = chartStreamValue.stream;
			$http.post("getEmpSkillProfGraphDataperStrm", dshBrdchartStreamValue).success(function(response)
					{		    		
						
			    		if(response.length > 0)
			    		{
			    			var streamDashBoardData = response;
			    			setTimeout(function()
			    					{
			    						var w = window,
			    						d = document,
			    						e = d.documentElement,
			    						g = d.getElementsByClassName('graphBorder'),
			    						x = w.innerWidth || e.clientWidth || g.clientWidth,
			    						y = w.innerHeight|| e.clientHeight|| g.clientHeight;
			    						
			    						if(chartid == 'chart1')
			    						{
			    							var chart1 = nv.models.multiBarChart().stacked(false).showControls(true);   							
			    							chart1.xAxis.rotateLabels(-45);	
				    						d3.select('#chart1 svg').datum(streamDashBoardData[0].dshbrddata).transition().attr("width", x).attr("height", y).duration(500).call(chart1);
			    						} else if(chartid == 'chart2')
			    						{
			    							var chart2 = nv.models.multiBarChart().stacked(false).showControls(true);
			    							chart2.xAxis.rotateLabels(-45);
				    						d3.select('#chart2 svg').datum(streamDashBoardData[0].dshbrddata).transition().attr("width", x).attr("height", y).duration(500).call(chart2);
			    						} else if(chartid == 'chart3')
			    						{
			    							var chart3 = nv.models.multiBarChart().stacked(false).showControls(true);
			    							chart3.xAxis.rotateLabels(-45);
				    						d3.select('#chart3 svg').datum(streamDashBoardData[0].dshbrddata).transition().attr("width", x).attr("height", y).duration(500).call(chart3);
			    						} else
			    						{
			    							var chart4 = nv.models.multiBarChart().stacked(false).showControls(true);
			    							chart4.xAxis.rotateLabels(-45);
				    						d3.select('#chart4 svg').datum(streamDashBoardData[0].dshbrddata).transition().attr("width", x).attr("height", y).duration(500).call(chart4);
			    						}  						
			    					}, 400);
			    		}
			    		else
			    		{
			    			window.alert("No data available");
			    		}
					})
			   		.error(function(data, status) {
							window.alert("Server is unvailable"); 
		   			});
		}
	}
	
   //On The Skill Report Name Change
   $scope.changeSkillReportName = function(data)
   {
	   var skillReportName = data;
	   $scope.reportHeaderForSkillReport = false;
	   $scope.reportHeaderForEmpSkillRpt = false;
	   $scope.skillReportdetails = {};
	   skillReportAlert.hide();
	   $scope.SkilReportlMessage = "";
		
	   if(skillReportName == "Skill Summary Report" ||skillReportName == "Employee Skill Report")
	   {
		   $scope.streamForSkillReport = true;
		   $scope.getAvailableStreamsFunc();
	   }
	   else
	   {
		   $scope.streamForSkillReport = false;
	   }
   }
   
   //To select the planned Training for Register attendance
   $scope.OnClickDateToRecord=function()
   {
	   var inputfieldStatus = true; //sreeja
	   $scope.trainingRecord = "";  
	   var planDateStatus = $scope.validateDateFieldmmddyyyy($scope.SelectedDateToRecord); //sreeja
		
	   if(planDateStatus == false) //sreeja
		{
			inputfieldStatus = false;
			indUpdAlert.show();
			$scope.individualUpdateMessage = "Invalid Training Planned Date. Valid Date format is mm/dd/yyyy";
		}
		
		if(inputfieldStatus) //sreeja
		{
			$scope.individualUpdateMessage = ""; //sreeja
			indUpdAlert.hide();
			
			var obj = {"Date":$scope.SelectedDateToRecord};
			  
			$http.post("getrainingdateurl", obj).success(function(response)
					{		    		
			    		if(response.length > 0)
			    		{
				    		$scope.trainingRecord = response;
				    		$scope.SelectedRecordTopic = $scope.trainingRecord[0];
			    		}
			    		else
			    		{
			    			indUpdAlert.show();
			    			$scope.individualUpdateMessage = "No training scheduled on the selected date. Please select a valid date.";
			    		}
					})
			   		.error(function(data, status) {
						if (status == 403)
						{
							indUpdAlert.show();
							$scope.individualUpdateMessage = "Failed due to technical issues. Please contact the Administrator."; 
						}
						else {
							indUpdAlert.show();
							$scope.individualUpdateMessage = "Server is unvailable"; 
						}
		   			});
		}
   }
   
   $scope.onChangeReportDateRange = function(){
	   clearReportData();
   }
   
	//Clear Reports once the Clear button is clicked.
	$scope.OnClearReportClick = function()
	{
		clearReportData();
	}
	
   //to get the information to generate the report
   $scope.OnGenerateReportClick = function()
   {	   
	   var inputfieldStatus = true; //sreeja
	   var startDateStatus = $scope.validateDateFieldmmddyyyy($scope.startDate); //sreeja
	   var endDateStatus = $scope.validateDateFieldmmddyyyy($scope.endDate); //sreeja
		
	   if(startDateStatus == false) //sreeja
		{
			inputfieldStatus = false;
			reportalert.show();
			$scope.reportMessage = "Invalid Start Date. Valid Date format is mm/dd/yyyy"; 
			$scope.selectedreport = $scope.reports[0];
		}
	   else if(endDateStatus == false) //sreeja
			{
				inputfieldStatus = false;
				reportalert.show();
				$scope.reportMessage = "Invalid End Date. Valid Date format is mm/dd/yyyy"; 
				$scope.selectedreport = $scope.reports[0];
			}
		
		if(inputfieldStatus) //sreeja
		{
			var obj = {"startDate":$scope.startDate, "endDate":$scope.endDate};
		   var tempStartDate = $scope.startDate;
		   var tempEndDate = $scope.endDate;
		   
		   if($scope.startDate == null || $scope.endDate == null)
		   {
			   reportalert.show();
			   $scope.reportMessage = "Please select the date range";
			   clearReportData();
		   }
		   else if($scope.selectedreport != "Training Attendance" && $scope.selectedreport != "Scheduled Trainings" && $scope.selectedreport !="Trainings by Functional Area")
		   {
			   reportalert.show();
			   $scope.reportMessage = "Please select the Report to be generated";
			   clearReportData();
		   }
		   else if(new Date(tempStartDate) > new Date(tempEndDate))
			{
			   reportalert.show();
			   $scope.reportMessage = "Please select a valid date range";
			   clearReportData();
			}
		   
		   else
			{
			   if($scope.selectedreport == 'Trainings by Functional Area')
			   {
				   reportalert.hide();
				   $scope.reportMessage = "";
				   $http.post("getAttendancePerFunctAreaRpturl",obj).success(function(response)
					{
					   if (response == "")
					   {
						   reportalert.show();
						   $scope.reportMessage = "No data available for the selected date range!";
					   }else
					   {
						   $scope.reportHeader = "AttendancePerFunctionalAreaReportHeader";
						   $scope.reportShown = true;
						   $scope.tempAttendancePerFuncAreaReportData = response;
					   }
					})
					.error(function(data, status) {
						if (status == 403)
						{
							reportalert.show();
							$scope.reportMessage = "Failed due to technical issues. Please contact the Administrator."; 
						}
						else {
							reportalert.show();
							$scope.reportMessage = "Server is unvailable"; 
						}
					});		
			   }
			   else if ($scope.selectedreport == 'Training Attendance')
			   {
				   reportalert.hide();
				   $scope.reportMessage = "";
				   $http.post("getTrainingAttendanceReporturl",obj).success(function(response)
					{
					   if (response == "")
					   {
						   reportalert.show();
						   $scope.reportMessage = "No data available for the selected date range!";
					   }else
					   {
						   $scope.reportHeader = "trainingAttendanceReportHeader";
						   $scope.reportShown = true;
						   $scope.tempAttendanceReportData = response;
					   }
					})
					.error(function(data, status) {
						if (status == 403)
						{
							reportalert.show();
							$scope.reportMessage = "Failed due to technical issues. Please contact the Administrator."; 
						}
						else {
							reportalert.show();
							$scope.reportMessage = "Server is unvailable"; 
						}
					});		
			   }
			   else if ($scope.selectedreport == 'Scheduled Trainings')
			   {
				   reportalert.hide();
				   $scope.reportMessage = "";
				   $http.post("getScheduledTrainingReporturl",obj).success(function(response)
					{
					   if (response == "")
					   {
						   reportalert.show();
						   $scope.reportMessage = "No data available for the selected date range!";
					   }else{
						   $scope.reportHeader = "scheduledTrainingReportHeader";
						   $scope.reportShown = true;
						   $scope.tempReportData = response;
					   }			
					})
					.error(function(data, status) {
						if (status == 403)
						{
							reportalert.show();
							$scope.reportMessage = "Failed due to technical issues. Please contact the Administrator."; 
						}
						else
						{
							reportalert.show();
							$scope.reportMessage = "Server is unvailable"; 
						}
					});			
			   }
			}
		}
   }
   
   
   //Pagination to get the number of pages
   $scope.numberOfPages = function() 
   {
	   if($scope.reportHeader == "scheduledTrainingReportHeader")
	   {
		   return Math.ceil($scope.tempReportData.length / $scope.pageSize);
	   }
	   else if($scope.reportHeader == "trainingAttendanceReportHeader")
	   {
		   return Math.ceil($scope.tempAttendanceReportData.length / $scope.pageSize);
	   }
	   else if($scope.reportHeader == "AttendancePerFunctionalAreaReportHeader")
	   {
		   return Math.ceil($scope.tempAttendancePerFuncAreaReportData.length / $scope.pageSize);
	   }
	   else if($scope.selectedSkillReport == "Employee Skill Report")
	   {
		   if($scope.empSkillDetailsHdr.length > 0)
		   {
			   return Math.ceil(($scope.empSkillDetailsHdr.length-2) / $scope.emppageSize);
		   }
	   }
   };
   
   
   //To Select the planned Training based on the Trainer ID
   $scope.OnClickDate = function()
   {   	
	   $scope.SelectedTrainerTopic = []; //sreeja
	   
	   var inputfieldStatus = true; //sreeja
	   var planDateStatus = $scope.validateDateFieldmmddyyyy($scope.SelectedDate); //sreeja
		
	   if(planDateStatus == false) //sreeja
		{
			inputfieldStatus = false;
			updateTrnStsalert.show();
			$scope.updateTrnStsMessage = "Invalid Training Planned Date. Valid Date format is mm/dd/yyyy";
			$scope.SelectedTrainerTopic = [];
		}
		
		if(inputfieldStatus)
		{
		   var obj = {"trnrid":$scope.username, "Date":$scope.SelectedDate};
	    	
	    	//Write the logic to fetch the data from the db through a rest call
	    	$http.post("searchTrainingurl", obj).success(function(response)
			{   
				updateTrnStsalert.hide(); 
				$scope.updateTrnStsMessage = "";
	    		$scope.trainingData = response;
	    		
	    		if(response.length > 0)
	    		{
					$scope.SelectedTrainerTopic.area = response[0]["Area"];
					$scope.SelectedTrainerTopic.functionalarea = response[0]["FunctionalArea"];
					$scope.SelectedTrainerTopic.Status = response[0]["status"];
					$scope.SelectedTrainerTopic.topic = response[0]["topic"];
					$scope.SelectedTrainerTopic.duration = response[0]["duration"];
	    		}
	    		else
	    		{
	    			updateTrnStsalert.show();
	    			$scope.updateTrnStsMessage = "There are no Training scheduled on the selected date.";
					$scope.SelectedTrainerTopic.area = "";
					$scope.SelectedTrainerTopic.functionalarea = "";
					$scope.SelectedTrainerTopic.Status = "";
					$scope.SelectedTrainerTopic.topic = "";
					$scope.SelectedTrainerTopic.duration = "";
	    		}
			})
	   		.error(function(data, status) 
	   		{
				if (status == 403)
				{
					updateTrnStsalert.show();
					$scope.updateTrnStsMessage = "Failed due to technical issues. Please contact the Administrator."; 
				}
				else {
					updateTrnStsalert.show();
					$scope.updateTrnStsMessage = "Server is unvailable"; 
				}
	   		});
		}
    }
    
    //To select the topic related information for updating the current status by the trainer.
    $scope.OnChangeTopic = function(TrainerTopic) 
    {
    	$scope.SelectedTrainerTopic.area = TrainerTopic["Area"];
    	$scope.SelectedTrainerTopic.functionalarea = TrainerTopic["FunctionalArea"];
		$scope.SelectedTrainerTopic.Status = TrainerTopic["status"];
		$scope.SelectedTrainerTopic.topic = TrainerTopic["topic"];
		$scope.SelectedTrainerTopic.duration = TrainerTopic["duration"];
    }
    
    //On change the Topic Count in Add New Training tab
    $scope.onChangeTopicCount = function(topicCount)
    {
		miscellaneousalert.hide();	//sreeja	
		$scope.miscellaneousMessage = ""; //sreeja

    	var count = topicCount[0];
    	
    	if(count == 1)
    		{
    			$scope.countOne = true;
    			$scope.countTwo = false;
    			$scope.countThree = false;
    			$scope.countFour = false;
    			$scope.countFive = false;
    		}
    	else if(count == 2)
    		{
    			$scope.countOne = true;
    			$scope.countTwo = true;
    			$scope.countThree = false;
    			$scope.countFour = false;
    			$scope.countFive = false;
    		}
    	else if(count == 3)
		{
			$scope.countOne = true;
			$scope.countTwo = true;
			$scope.countThree = true;
			$scope.countFour = false;
			$scope.countFive = false;
		}
    	else if(count == 4)
		{
			$scope.countOne = true;
			$scope.countTwo = true;
			$scope.countThree = true;
			$scope.countFour = true;
			$scope.countFive = false;
		}
    	else if(count == 5)
		{
			$scope.countOne = true;
			$scope.countTwo = true;
			$scope.countThree = true;
			$scope.countFour = true;
			$scope.countFive = true;
		}
    	else
		{
		$scope.countOne = false;
		$scope.countTwo = false;
		$scope.countThree = false;
		$scope.countFour = false;
		$scope.countFive = false;
		miscellaneousalert.show();	//sreeja	
		$scope.miscellaneousMessage = "Enter the number of topics needs to be added. Min is 1 and Max is 5"; //sreeja
		}
    }
    
    //To set the date and duration of the training when the status is being updated as cancelled.
    $scope.onChangeStatus = function(updatedStatus)
    {
    	var status = updatedStatus;
    	if(status == "Cancelled"){
    		$scope.updatedDate = $scope.SelectedDate ;
    		$scope.updatedDuration = $scope.SelectedTrainerTopic.duration;
    	}
    	else
    	{
    		$scope.updatedDate = "" ;
    		$scope.updatedDuration = "0:30";
    	}
    }
    
    //To register the training attendance by trainee.
    $scope.OnChangeRecordTopic = function(RecordTopic) 
    {
   		if(RecordTopic != null)
    	{
	    	$scope.SelectedRecordTopic.topic = RecordTopic["topic"];
			$scope.SelectedRecordTopic.date = RecordTopic["plannedDate"];
    	}
    }
    
    $scope.SelectedRecordTopic = $scope.trainingRecord[0];   
    $scope.SelectedTrainerTopic = $scope.trainingData[0];
	
	//Login
	 $scope.login = function() 
	 {
		var logindata = [];
		var loginIDfieldstatus = $scope.validateEmpIDSearchField($scope.loginidtxt);
		if(loginIDfieldstatus == true)
		{
	    	logindata.push({
	            loginid: $scope.loginidtxt,
	            passwordtxt: $scope.passwordtxt            
	          });

	    	if($scope.loginidtxt == "999999")
	    	{
	    		if($scope.passwordtxt == "guest2016"){
		    		$scope.username = $scope.loginidtxt;
			    	$scope.loginEmp = "Guest";
			    	$scope.loginidtxt = "";
		    		$scope.passwordtxt = "";
		    		$scope.loginstatus = true;
		    		$scope.adminuser = false;
		    		//$scope.adminuser = true;
					$scope.loginvalid = true;
					$scope.mainpills = "pill";
					$scope.tabcursor = "tabcursoronclass";
					$scope.getAllStreams();
					$scope.getAllTrainingDocs();
					$scope.getAvailableStreamsFunc();
					$scope.getAvailableAreaOnLogin();
					$scope.getUserInfoOnLogin();
					$scope.displayDashBoard();
	    		}else{
	    			window.alert("Invalid Login credentials");
	    			$scope.passwordtxt = "";
	    		}	    		
	    	}else
	    	{
		    	$http.post("loginurl", logindata).success(function(response){
		    		$scope.loginresponse = response;
		    		loginiddata=$scope.loginresponse[0].loginres;
		    		roledata=$scope.loginresponse[0].role;
		    		loginEmpName = $scope.loginresponse[0].empName;
		    		$scope.StreamFromEmpTbl = $scope.loginresponse[0].StreamFromEmpTbl;
		    		
		    		if(loginiddata == "")
					{
						$scope.loginstatus = false;
					}
		    		else
					{
		    			$scope.username = $scope.loginidtxt;
		    			$scope.loginEmp = loginEmpName;
		    			$scope.loginidtxt = "";
		    			$scope.passwordtxt = "";
		    			$scope.loginstatus = true;
						if (roledata == "User")
						{
							$scope.adminuser = false;
						}
						else
						{
							$scope.adminuser = true;
						}
						$scope.loginvalid = true;
						$scope.mainpills = "pill";
						$scope.tabcursor = "tabcursoronclass";
						$scope.getAvailableStreamsFunc();
						$scope.getAllStreams();
						$scope.getAllTrainingDocs();
						$scope.getAvailableAreaOnLogin();
						$scope.getUserInfoOnLogin();
						$scope.displayDashBoard();
					}
		    	
		    	})
		    	.error(function(data, status) {
		    		$scope.loginvalid = false;
					$scope.mainpills = "";
					$scope.tabcursor = "tabcursoroffclass";
		    		if(status == 400)
		    			{
		    				window.alert("Invalid login credentials.");
		    				$scope.passwordtxt = "";
		    			}
		    		else if(status == 503)
		    			{
		    				window.alert("Server is unvailable.");			
		    			}
		    		else if(status == 412)
					{
						window.alert("Access Denied.");	
					}
		    		else if (status == 403)
						{
							window.alert("Failed due to technical issues. Please contact the Administrator."); 
						}
				});
	    	}
			//
			
		}
		else
			window.alert("Invalid Login ID");
    }
	
	//Logout
    $scope.onClickLogout = function(){
    	
    	$window.location.reload();
    }
    
    //To get the Area available in Tbl_Training_Topics table.
    $scope.getAvailableAreaOnLogin = function(){
    	$http.get("getAvailableArea").then(function(response) 
    			{
    				$scope.AvailableArea = [];		
    				if (response == "")
    						{
    							window.alert("No records present in Table.");
    						}
    				else if (response == 403)
    						{
    							window.alert("Failed due to technical issues. Please contact the Administrator."); 
    						}
    				else
    						{
    							$scope.AvailableArea = response.data;
    							$scope.existingArea = $scope.AvailableArea[0];
    							$scope.existingFunctionalArea = $scope.existingArea.functionalarea;
    							$scope.getAvailableFunctArea();
    						}
    			});
    }
    
    //On Area value change
	$scope.OnChangeExistArea = function(data)
	{
		$scope.existingFunctionalArea = data.functionalarea;
	}
	
	//To get the topics available in Tbl_Training_Topics table.
	$scope.getUserInfoOnLogin = function(){
		$http.get("getUserInfo").then(function(response) 
			{
				if (response == "")
				{
					window.alert("Training topics are not available.");
				}
				else if (response == 403)
				{
					window.alert("Failed due to technical issues. Please contact the Administrator."); 
				}
				else
				{
					$scope.AvailableTopics = response.data;
					$scope.selectedOption = $scope.AvailableTopics[0];
					$scope.SelectedArea=$scope.AvailableTopics[0].Area;
					$scope.SelectedFunctionalArea = $scope.AvailableTopics[0].FunctionalArea;
				}
			});
	}
	
	$scope.getAllTrainingDocs = function(){
		$http.get("getAllTrainingDocs").then(function(response){
			if (response == "")
			{
				window.alert("There are no documents available.");
			}
			else
			{
				$scope.listOfDocs = response.data;
			}
		});
	}
	
	
	
	$scope.downloadFile = function(path, name){
		var fileDetails = {"url":path,"filename":name};
        var index = name.indexOf(".");
        var extension = name.substring(index+1); 
        $http({
        
        	url: 'downloadFile',
        	method: "POST",
            data: fileDetails,
            headers: {
                'Content-type': 'application/json'
             },
             responseType: 'arraybuffer'
        }).success(function(data)
				{
					
						if(extension == 'xlsx')
						{
						    var blob = new Blob([data], {
						     'type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
						  });							
						    var a = document.createElement('a');
					        a.href = window.URL.createObjectURL(blob);
					        a.download = name;
					        a.click();
						    
						}
						else if(extension == 'txt')
						{
							contentType = 'APPLICATION/OCTET-STREAM';	
					        var a = document.createElement('a');
					        var blob = new Blob([data], {'type':contentType});
					        a.href = window.URL.createObjectURL(blob);
					        a.download = name;
					        a.click();
						}
	
				})
				.error(function(data,status) {
					window.alert("Error on download");
				});	
	}
	
	$scope.getAllStreams = function(){
		$http.get("getAllDomains").then(function(response){
			$scope.streamToSelect = "";	
			if (response == "")
				{
					window.alert("Streams not available in the database.");
				}
			else if (response == 403)
				{
					window.alert("Failed due to technical issues. Please contact the Administrator."); 
				}
			else
				{
					$scope.streamToSelect = response.data;
					$scope.newStream = $scope.streamToSelect[0];
				}
		});
	}
	
	
	$scope.getAvailableStreamsFunc = function(){
	//To get available Streams from the Employee Details table
		$http.get("getAvailableStreams").then(function(response) 
				{
				$scope.streamData = "";	
				if (response == "")
					{
						window.alert("Streams not available in the database.");
					}
				else if (response == 403)
					{
						window.alert("Failed due to technical issues. Please contact the Administrator."); 
					}
				else
					{
						$scope.streamData = response.data;
						$scope.SelectedStream = $scope.streamData[0];
						if(dashBrdClk)
						{
							$scope.chart1StreamValue = $scope.streamData[0];
							$scope.chart2StreamValue = $scope.streamData[1];
							$scope.chart3StreamValue = $scope.streamData[2];
							$scope.chart4StreamValue = $scope.streamData[3];
							dashBrdClk = false;
						}
						else
						{
							var tempStream = $scope.streamData[0].stream;
							$scope.GetExistingSkillDetails(tempStream);
						}
					}
				});
	}
	
	//To fetch all available Functional Area from Training Topics Table
	$scope.getAvailableFunctArea = function()
	{
		$http.get("getAvailableFunctArea").then(function(response) 
				{
				if (response == "")
					{
						window.alert("Functional Area not available in the database.");
					}
				else if (response == 403)
					{
						window.alert("Failed due to technical issues. Please contact the Administrator."); 
					}
				else
					{
						$scope.AllFunctionalArea = response.data;
						$scope.functionalAreaSelected = $scope.AllFunctionalArea[0];
					}
				});
	}
	
	$scope.changedSkill = function(streamData)
	{
		var temp = streamData.stream;
		$scope.GetExistingSkillDetails(temp);
	}
	
	//To get the skill details for Reporting.
	$scope.changedSkillforReport = function(data)
	{
	    $scope.emppageSize = 5; 
	    $scope.empcurindex = 2;
	    $scope.curPage = 0;
		var tempStream = "";
		if(data != null)
		{
			tempStream = data.stream;
		}
		$scope.reportHeaderForSkillReport = false;
		$scope.reportHeaderForEmpSkillRpt = false;
		skillReportAlert.hide();
		$scope.SkilReportlMessage = "";
		
		if($scope.selectedSkillReport == "Skill Summary Report")
		{
			if(tempStream != "")
			{
				$scope.skillReportdetails = {};
		
				$http.post("getSkillCount", tempStream).success(function(response)
				{
					if(response.length > 0)
					{
						$scope.reportHeaderForSkillReport = true;
						$scope.skillReportdetails = response;
					}
					else
					{
						$scope.reportHeaderForSkillReport = false;
						skillReportAlert.show();
						$scope.SkilReportlMessage = "Skill set not available for the selected Stream";	
					}
		
				})
				.error(function(data,status) {
					$scope.reportHeaderForSkillReport = false;
					skillReportAlert.show();
					$scope.SkilReportlMessage = "Failed due to technical issues. Please contact the Administrator";	
				});	
			}
		}
		else if($scope.selectedSkillReport == "Employee Skill Report")
		{
			if(tempStream != "")
			{
				$scope.reportHeaderForEmpSkillRpt = true;
	
				$http.post("getEmpSkilHdr", tempStream).success(function(response)
						{
							if(response.length > 2)
							{
								$scope.reportHeaderForEmpSkillRpt = true;
								$scope.empSkillDetailsHdr = response;
								
								$http.post("getEmpSkillSummary", tempStream).success(function(response)
										{
											if(response.length > 0)
											{
												$scope.empSkillDetails = response;
											}
											else
											{
												$scope.reportHeaderForEmpSkillRpt = false;
												skillReportAlert.show();
												$scope.SkilReportlMessage = "Employe Skill Summary not available for the selected Stream";	
											}
								
										})
										.error(function(data,status) {
											$scope.reportHeaderForEmpSkillRpt = false;
											skillReportAlert.show();
											$scope.SkilReportlMessage = "Failed due to technical issues. Please contact the Administrator";	
										});
							}
							else
							{
								$scope.reportHeaderForEmpSkillRpt = false;
								skillReportAlert.show();
								$scope.SkilReportlMessage = "Employe Skill Summary not available for the selected Stream";	
							}
				
						})
						.error(function(data,status) {
							$scope.reportHeaderForEmpSkillRpt = false;
							skillReportAlert.show();
							$scope.SkilReportlMessage = "Failed due to technical issues. Please contact the Administrator";	
						});			
			}
	}
	else
	{
		$scope.reportHeaderForSkillReport = false;
		$scope.reportHeaderForEmpSkillRpt = false;
		$scope.skillReportdetails = {};
	}
}
	
	//Show next page Employee Skill Summary Report details
	$scope.OnClickNextEmpColumn = function()
	{
		$scope.reportHeaderForEmpSkillRpt = true;
		$scope.empcurindex = $scope.empcurindex + $scope.emppageSize;
		$scope.curPage = $scope.curPage + 1;
	}
	
	//Show previous page Employee Skill Summary Report details
	$scope.OnClickPrevEmpColumn = function()
	{
		$scope.reportHeaderForEmpSkillRpt = true;
		if($scope.emppageSize > $scope.empcurindex)
		$scope.empcurindex = $scope.emppageSize - $scope.empcurindex;
		else
		$scope.empcurindex = $scope.empcurindex - $scope.emppageSize;	
		$scope.curPage = $scope.curPage - 1;
	}

	//On Click the First link in Employee Skill Summary Report
	$scope.OnClickFirts = function()
	{
	    $scope.curPage = 0;
	    $scope.empcurindex = 2;
	}
	
	//On click the last link in Employee Skill Summary Report
	$scope.OnClickLast = function()
	{
	    var PageCnt = 0;
	    var dataColCnt = 0;
	    var pageindex = 0;
	    var temp = 0;
	    
	   if($scope.empSkillDetailsHdr !=null)
	    {
		    dataColCnt = $scope.empSkillDetailsHdr.length-2;
			if(dataColCnt > 0)
			{
				PageCnt = Math.ceil(($scope.empSkillDetailsHdr.length-2) / $scope.emppageSize);
				pageindex = (dataColCnt + 2) - (dataColCnt - $scope.emppageSize*(PageCnt-1));
				if(pageindex >= 2)
				{
					$scope.empcurindex = pageindex;
					$scope.curPage = PageCnt-1;
				}
			}
	    }
	}

	
	//To load the existing SkillSet details in the Add New Skills page.
	$scope.GetExistingSkillDetails = function(stream)
	{
		$scope.skilldetails = {};
		var temp = stream;
		addSkillAlert.hide();
		$scope.addSkillMessage = "";
		$http.post("getAvailableSkills", temp).success(function(response) 
				{
					skillCountPerStream = response.length;
					
					if(response.length > 0)
			    		{
							$scope.skilldetails = response;
							skillAvailSts = true;
			    		}
					else
						{
							addSkillAlert.show();
							$scope.addSkillMessage = "Skill Set not available for the selected Stream";	
						}
				})
				.error(function(data,status) {
						addSkillAlert.show();
						$scope.addSkillMessage = "Failed due to technical issues. Please contact the Administrator";	
				});		
	}
	
	//Clear the rows when the EMPID is blank
	var tempEmpid = "";
	$scope.verifyEmpIDNull = function(data)
	{
		var tempEmpid = data;
		if(tempEmpid == "")
			$scope.ClearSkillProfData();		
	}
	
	//Clear the Proficiency data
	$scope.ClearSkillProfData = function()
	{
		$scope.EmpNameFromEmpTbl = "";
		$scope.StreamFromEmpTbl = "";
		$scope.RoleFromEmpTbl = "";	
		$scope.proficiencySkillDetails = {};
		$scope.proficiencyOn = "false";
		addProficiencyAlert.hide();
		$scope.addProficicencyMessage = "";
	}
	
	//To Search the Employee Details from Employee Details table
	$scope.OnSearchSkillEmpClick = function(data){
		var tempSkillEmpID = data;
		if (tempSkillEmpID == "")
			{
				$scope.ClearSkillProfData();
    	    	addProficiencyAlert.show();	
    			$scope.addProficicencyMessage = "Enter Employee ID to search";
			}
		else{
			addProficiencyAlert.hide();	
			$scope.addProficicencyMessage = "";
	    	var empDetails = [];
	    	
	    	empDetails.push({
	                newEmpId : tempSkillEmpID
	               });
			
			$http.post("searchEmployee",empDetails).success(function(response){
				var profData = {};
	    		
	    		if(response.length > 0)
	    		{
					$scope.EmpNameFromEmpTbl = response[0]["searchEmpName"];
					$scope.StreamFromEmpTbl = response[0]["searchStream"];
					$scope.RoleFromEmpTbl = response[0]["searchProjectRole"];
					var profData = {empID : tempSkillEmpID,stream : $scope.StreamFromEmpTbl};
		    		$scope.getProficiencyDetail(profData);
	    		}
	    		else
	    		{
	    			$scope.ClearSkillProfData();
	    	    	addProficiencyAlert.show();	
	    			$scope.addProficicencyMessage = "Employee details are not available";
	    		}		
			})
			.error(function(data,status){
				$scope.ClearSkillProfData();
				addProficiencyAlert.show();
        		$scope.addProficicencyMessage = "Failed due to technical issues. Please contact the Administrator";				
			});
		}
	}
	
    
	//To get existing proficiency information from database
	$scope.getProficiencyDetail = function(data)
	{
		$scope.proficiencySkillDetails = {};
		var profData = data;
		$http.post("getAvailableProficiency",profData).success(function(response) 
		{
			if(response.length > 0)
		    {
				$scope.proficiencySkillDetails = response;
				$scope.proficiencyOn = true;
		    }
			else
			{
				addProficiencyAlert.show();
				$scope.addProficicencyMessage = "Skill Set not available for the selected Stream";	
			}
		})
		.error(function(data,status) {
			addProficiencyAlert.show();
			$scope.addProficicencyMessage = "Failed due to technical issues. Please contact the Administrator";	
		});
	}
	
	//To set the Background color and text color when the Actual Proficiency is changed
	$scope.colorOnChange = function(index)
	{
		var indx = index;
		var colorCodeSet = false;
		var competArray = ["Expert","Proficient","Intermediate","Basic","Not Applicable"];
		var actualProficiency = $scope.proficiencySkillDetails[indx].proficiency;
		var exptProficiency = $scope.proficiencySkillDetails[indx].competency;
		
		if(actualProficiency == exptProficiency)
		{
			$scope.proficiencySkillDetails[indx].setBgColor =  "#52D017";
			$scope.proficiencySkillDetails[indx].setColor =  "black";
			colorCodeSet = true;
		}
		else if(actualProficiency == "Not Applicable")
		{
			$scope.proficiencySkillDetails[indx].setBgColor =  "#ADD8E6";
			$scope.proficiencySkillDetails[indx].setColor =  "black";
			colorCodeSet = true;
		}
		else
		{
			for(var i=0; i<5; i++)
			{
				if(exptProficiency == competArray[i])
				{
					if((actualProficiency == competArray[i+1]))
					{
						$scope.proficiencySkillDetails[indx].setBgColor =  "yellow";
						$scope.proficiencySkillDetails[indx].setColor =  "black";
						colorCodeSet = true;
					}
					else
					{
						for(var j=i-1; j >= 0; j--)
						{
							if((actualProficiency == competArray[j]))
							{
								$scope.proficiencySkillDetails[indx].setBgColor =  "green";
								$scope.proficiencySkillDetails[indx].setColor =  "white";
								colorCodeSet = true;
							}
						}
					}
				}
			}
		}
		if(colorCodeSet == false)
		{
			$scope.proficiencySkillDetails[indx].setBgColor =  "red";
			$scope.proficiencySkillDetails[indx].setColor =  "white";
			colorCodeSet = true;
		}
		$scope.proficiencyOn = "true";
	}
	
	//To Refresh the Proficiency details
	$scope.OnClearProfUpdateClick = function()
	{
		addProficiencyAlert.hide();
		$scope.addProficicencyMessage = "";
		var profData = {empID : $scope.skillEmpSearch,stream : $scope.StreamFromEmpTbl};
		$scope.getProficiencyDetail(profData);
	}
	
	//To Export the Skill Summary Report to Excel sheet
	$scope.ExportSkillSummaryReportClick = function()
	{		
		$scope.ExportHTMLData("skillSummaryReportTableToExport");	    
	}
	
	//Show all Data to download the report
	$scope.ShowAll = function()
	{
		$scope.empcurindex = 2;
		$scope.emppageSize = $scope.empSkillDetailsHdr.length;
		$scope.showdwnld = true;
	}
	
	//To Export the Employee Skill Summary Report to Excel sheet
	$scope.ExportEmpSkillSummaryReportClick = function()
	{		
		$scope.ExportHTMLData("EmpskillSummaryReportTableToExport");
	}
	
	$scope.ExportHTMLData = function(expdata)
	{
		var tab_text="<table border='2px'>";
	    var textRange; 
	    var j=0;
	    var tab = document.getElementById(expdata); // id of table
	    var lines = tab.rows.length;
	    
	    // the first headline of the table
	    if (lines > 0) {
	        tab_text = tab_text + '<tr bgcolor="#DFDFDF">' + tab.rows[0].innerHTML + '</tr>';
	    }
	    
	    // table data lines, loop starting from 1
	    for(j = 1 ; j < lines ; j++) 
	    {     
	    	tab_text = tab_text + "<tr>" + tab.rows[j].innerHTML + "</tr>";
	    }

	    tab_text=tab_text+"</table>";
	    tab_text= tab_text.replace(/<A[^>]*>|<\/A>/g, "");//remove if u want links in your table
	    tab_text= tab_text.replace(/<img[^>]*>/gi,""); // remove if u want images in your table
	    tab_text= tab_text.replace(/<input[^>]*>|<\/input>/gi, ""); // reomves input params

	    $window.open( 'data:application/vnd.ms-excel,' + encodeURIComponent(tab_text));
	    
	    if(expdata == "EmpskillSummaryReportTableToExport")
	    	{
				$scope.empcurindex = 2;
				$scope.emppageSize = 5;
				$scope.showdwnld = false;
	    	}
	}
	
	//To add/update the Actual Proficiency to the database
	$scope.OnAddProficiencyClick = function(data)
	{
		var proficiencyDetails = [];
		var tempStream = $scope.StreamFromEmpTbl;
		var tempSearchEmpID = $scope.skillEmpSearch;
    	var count = data.length;
		for(var i=0;i<count;i++)
		{
			proficiencyDetails.push({
				stream : tempStream,
				empID : tempSearchEmpID,
				loginEmpID : $scope.username,
				skillName : data[i].skillName,
				proficiency : data[i].proficiency
	               });
		}
		addProficiencyAlert.hide();
		$scope.addProficicencyMessage = "";
		$http.post("ProficiencyAdd",proficiencyDetails).success(function(response){
			$scope.proficiencyDetails = [];
			$scope.proficiencyOn = false;
			$scope.OnClearProfUpdateClick();
			addProficiencyAlert.show();
			$scope.addProficicencyMessage = "Proficiency updated successfully";
		})
		.error(function(data,status){
			addProficiencyAlert.show();
			$scope.addProficicencyMessage = "Failed due to technical issues. Please contact the Administrator";
		});
	}
	
	
	//To upload the file
	$scope.uploadSpreadsheet = function(element) {

		$scope.rowCount="";
        
		$scope.$apply(function(scope) {
            var f = element.files[0];
            var r = new FileReader();
            r.onloadend = function(e) {
                var data = {};
                data.lastModified = f.lastModified;
                data.lastModifiedDate = f.lastModifiedDate;
                data.name = f.name;
                data.size = f.size;
                var dataUrl = e.target.result;
                var index = dataUrl.indexOf(";base64,");
                data.file = dataUrl.substring(index + 8);
                alert.show();
                $scope.StatusMessage = "Upload is in progress, please wait";
                $http.post("UploadDetails", data).success(function(response) {
                	$scope.rowCount = response;
                	var importMessage = "Upload is successful. ";
                	alert.show();
                	$scope.StatusMessage = importMessage.concat("No. of records uploaded is ",$scope.rowCount);
                	
                	if(document.getElementById("file-upload") != null)
                	{
                		document.getElementById("file-upload").value = "";
                	}
                })
                .error(function(data,status) {
                             	
                	var bulkLoadErrorMessage = data;
                	var KeyMessage = data.KeyMessage;
                	if(status == 403)
                	{
                		alert.show();
                		$scope.StatusMessage = "Upload failed. ".concat(KeyMessage);         		
                	}
                	else
                	{
                		alert.show();
                		$scope.StatusMessage = "Upload failed due to technical issues. Please contact the Administrator.";
                	}
                	if(document.getElementById("file-upload") != null)
                	{
                		document.getElementById("file-upload").value = "";
                	}
                });
            }
            r.readAsDataURL(f);            
        });		
    }
	
	
	//to get the dynamic value in area
	$scope.changedValue=function(item)
	{
		$scope.SelectedArea = item.Area;
		$scope.SelectedTopic = item.topic;
		$scope.SelectedFunctionalArea = item.FunctionalArea;
	}
		
    $scope.changeTo = 'Hungarian';
    
    /* event source that pulls from google.com */
    $scope.eventSource = {
			url: "",
            className: 'gcal-event',           // an option!
            currentTimezone: 'Asia/Kolkata' // an option!
    };
    
    /* event source that contains custom events on the scope */
    $scope.events = [];
    
    /* event source that calls a function on every view switch */
    $scope.eventsF = function (start, end, timezone, callback) 
    {
    	var s = new Date(start).getTime() / 1000;
    	var e = new Date(end).getTime() / 1000;
    	var m = new Date(start).getMonth();
    	var events =  $scope.events;
    	callback(events);
    };

    $scope.calEventsExt = 
    {
    	color: '#f00',
    	textColor: 'yellow',
    	events: [
          {type:'party',title: 'Lunch',start: new Date(nyr, m, d, 12, 0),end: new Date(nyr, m, d, 14, 0),allDay: false},
          {type:'party',title: 'Lunch 2',start: new Date(nyr, m, d, 12, 0),end: new Date(nyr, m, d, 14, 0),allDay: false},
          {type:'party',title: 'Click for Google',start: new Date(nyr, m, 28),end: new Date(nyr, m, 29),url: 'http://google.com/'}
        ]
    };
    
    /* Clear Tool Tip Click details*/
    
    $scope.ClearToolTipDetail = function()
    {
    	$scope.tooltipclicked = false;
    }
    
    
    /* alert on eventClick */
    $scope.alertOnEventClick = function( date, jsEvent, view)
    {    	
    	$scope.tooltipclicked = true;
    	$scope.clicktitle = date.title;
    	$scope.clickarea = date.area;
    	$scope.clickFunctArea = date.funcarea;
    	var index = (date.start.toString().indexOf("GMT"))-10;
    	$scope.clickdate = date.start.toString().substr(0,index);
    	var tempstarttime = date.starttime;
    	var temphr = tempstarttime.substr(0,2);
    	var tempmin = tempstarttime.substr(3,2);
    	var temp ="";
    	if(temphr == 12 & tempmin == 0)
    		{
    		tempupdatedstarttime = temphr+":"+tempmin+" pm";
    		}
    	else if(temphr == 12 & tempmin > 0)
    		{
    			tempupdatedstarttime = temphr+":"+tempmin+" pm";
    		}
    	else if(temphr > 12)
    		{    		
    			temp = temphr-12;
    			tempupdatedstarttime = temp+":"+tempmin+" pm";
    		}
    	else
    		{
    			tempupdatedstarttime = temphr+":"+tempmin+" am";
    		}
    	
    	$scope.clickstarttime = tempupdatedstarttime;
    	$scope.clickduration = date.duration;
    	$scope.clickstatus = date.status;
    	$scope.clicklocation = date.location;
    	$scope.clicktrainer = date.trainer;
    };
    
    /* alert on Drop */
    $scope.alertOnDrop = function(event, delta, revertFunc, jsEvent, ui, view){
    	 $scope.alertMessage = ('Event Droped to make dayDelta ' + delta);
    };
    
    /* alert on Resize */
    $scope.alertOnResize = function(event, delta, revertFunc, jsEvent, ui, view ){
    	$scope.alertMessage = ('Event Resized to make dayDelta ' + delta);
    };
    
    /* add and removes an event source of choice */
    $scope.addRemoveEventSource = function(sources,source) {
    	var canAdd = 0;
    	angular.forEach(sources,function(value, key){
    		if(sources[key] === source){
    			sources.splice(key,1);
    			canAdd = 1;
    		}
    	});
    	if(canAdd === 0){
    		sources.push(source);
    	}
    };
    
	//to clear the Add Employee details
	$scope.OnClearNewEmployeeClick = function(){
		$scope.newAddEmpId = "";
		$scope.newEmpName = "";
		$scope.newDesignation = "";
		$scope.newEmailId = "";
		$scope.newStream = "";
		$scope.newUserRole = "User";
		$scope.newProjectEmployee = "Telstra";	
		$scope.newProjectRole = "Analyst";
		miscellaneousalert.hide(); //sreeja
		$scope.miscellaneousMessage = ""; //sreeja
	}
    
    //Search whether the Employee already exist in database
	var tempEmpID = "";
	$scope.OnSearchEmpClick = function(data){
		var tempEmpID = data;
    	miscellaneousalert.hide();
    	$scope.miscellaneousMessage = "";
		if (tempEmpID == "")
			{
	    		miscellaneousalert.show();		
	    		$scope.miscellaneousMessage = "Enter Employee ID to search.";
	    		$scope.OnClearNewEmployeeClick();
			}
		else{
	    	var empidSearchStatus = $scope.validateEmpIDSearchField(tempEmpID); //sreeja
	    	
	    	if(empidSearchStatus == false) //sreeja
	    	{
        		miscellaneousalert.show();
        		$scope.miscellaneousMessage = "Invalid Employee ID";
	    	}
	    	else //sreeja
			{
		    	var empDetails = [];
		    	
		    	empDetails.push({
		                newEmpId : tempEmpID
		               });
				
				$http.post("searchEmployee",empDetails).success(function(response){
		    		
		    		if(response.length > 0)
		    		{
						$scope.newEmpName = response[0]["searchEmpName"];
						$scope.newDesignation = response[0]["searchDesignation"];
						$scope.newEmailId = response[0]["searchEmail"];
						$scope.newStream = response[0]["searchStream"];
						$scope.newUserRole = response[0]["searchUserRole"];
						$scope.newProjectEmployee = response[0]["searchProject"];
						$scope.newProjectRole = response[0]["searchProjectRole"];
		    		}
		    		else
		    		{
		    	    	miscellaneousalert.show();	
		    			$scope.miscellaneousMessage = "Employee details are not available.";
		    			$scope.OnClearNewEmployeeClick();
		    		}		
				})
				.error(function(data,status){
	        		miscellaneousalert.show();
	        		$scope.miscellaneousMessage = "Failed due to technical issues. Please contact the Administrator.";	
	        		$scope.OnClearNewEmployeeClick();
				});
			}
		}
	}
	
	
	//add new Employee Details to Employee Details table
    $scope.OnAddEmployeeClick = function(){
   	
    	var empDetails = [];
    	miscellaneousalert.hide();
    	$scope.miscellaneousMessage = "";

    	var addfieldstatus = true;
    	
    	var empIdStatus = $scope.validateEmpIDSearchField($scope.newAddEmpId);
    	var empNameStatus = $scope.validateEmpNameField($scope.newEmpName);
    	var designStatus = $scope.validateStringField($scope.newDesignation);
    	var streamStatus = $scope.validateStringField($scope.newStream);
    	var emailStatus = $scope.validateEmailField($scope.newEmailId);
    	
    	if(empIdStatus == false)
    	{
    		addfieldstatus = false;
    		miscellaneousalert.show();
    		$scope.miscellaneousMessage = "Invalid Employee ID";
    	}
    	else if(empNameStatus == false)
    	{
    		addfieldstatus = false;
    		miscellaneousalert.show();
    		$scope.miscellaneousMessage = "Invalid Employee Name";
    	}
    	else if(designStatus == false)
    	{
    		addfieldstatus = false;
    		miscellaneousalert.show();
    		$scope.miscellaneousMessage = "Invalid Designation";
    	}
       	else if(emailStatus == false)
    	{
    		addfieldstatus = false;
    		miscellaneousalert.show();
    		$scope.miscellaneousMessage = "Invalid Email ID";
    	}
    	else if(streamStatus == false)
    	{
    		addfieldstatus = false;
    		miscellaneousalert.show();
    		$scope.miscellaneousMessage = "Invalid Stream";
    	}

    	if(addfieldstatus == true)
    	{
	    	empDetails.push({
	                newEmpId : $scope.newAddEmpId,
	                 newEmpName: $scope.newEmpName,
	                 newDesignation: $scope.newDesignation,
	                 newEmailId: $scope.newEmailId,
	                 newStream: $scope.newStream,
	                 newUserRole: $scope.newUserRole,
	                 newProjectEmployee: $scope.newProjectEmployee, 
	                 newProjectRole: $scope.newProjectRole
	               });
	    	
	    	$http.post("checkEmpAvailability", empDetails).success(function(response){
	    		if(response != "")
	    			{
	    			var r = window.confirm("The Employee is already present. Do you want to update?");
	      	      		if(r == true)
	      	      		{      	      			
		      	      		$http.post("updateEmpDetails", empDetails).success(function(response)
		      	      		{
		                		
		      	      			$scope.OnClearNewEmployeeClick();		      	      			
		      	      			miscellaneousalert.show();
		      	      			$scope.miscellaneousMessage = "Successfully updated";
		                	})
		                	.error(function(data, status) {
		                		
		                		miscellaneousalert.show();
	                			$scope.miscellaneousMessage = "Failed due to technical issues. Please contact the Administrator.";
		            		});         		
	      	      		}
	      	      		else
	      	      		{
	      	      			$scope.OnClearNewEmployeeClick();
	      	      		}
	    			}   		
	    		else
	    		{
	            	$http.post("InsertToEmpDetails", empDetails).success(function(response){
	            		
	            		$scope.OnClearNewEmployeeClick();
	            		miscellaneousalert.show();
	            		$scope.miscellaneousMessage = "Successfully added";
	            	})
	            	.error(function(data, status) {
	            			
	            		miscellaneousalert.show();
	            		$scope.miscellaneousMessage = "Failed due to technical issues. Please contact the Administrator.";
	        		});
	    		}
	    	})
	    	.error(function(data, status) {	    		
	    		miscellaneousalert.show();
	   			$scope.miscellaneousMessage = "Failed due to technical issues. Please contact the Administrator.";
			});
    	}
    }
    
    /* add custom event*/
    $scope.addEvent = function() {
   	
    	var eventData = [];
    	GetCurrentDate();
    	
    	var inputvaluestatus = true; //sreeja
    	
    	var dateStatus = $scope.validateDateFieldmmddyyyy($scope.plandate); //sreeja
    	var timeStatus = $scope.validateTimeField($scope.starttime); //sreeja
    	if(typeof $scope.Trainer !== 'undefined') //sreeja
    	{
    		var trnrempStatus = $scope.validateTrnrEmpIDField($scope.Trainer);
    	}
    	else
    	{
    		$scope.Trainer = "";
    	}
    	
    	if(dateStatus == false) //sreeja
    	{
    		inputvaluestatus = false;
    		scheduleTrngalert.show();
			$scope.scheduleTrngMessage = "Invalid Planned Date. Valid Date format is mm/dd/yyyy";
    	}
    	else if(timeStatus == false) //sreeja
    	{
    		inputvaluestatus = false;
    		scheduleTrngalert.show();
			$scope.scheduleTrngMessage = "Invalid Start Time. Valid Time Format is hh:mm";
    	}
    	else if(trnrempStatus == false || $scope.Trainer == "")
    	{
    		inputvaluestatus = false;
    		scheduleTrngalert.show();
			$scope.scheduleTrngMessage = "Invalid Trainer Employee ID";
    	}
    	    		
    	if(inputvaluestatus) //sreeja
    	{ 
	    	if ($scope.plandate < currentdate){
	    		
	    		scheduleTrngalert.show();
	    		$scope.scheduleTrngMessage = "Training Plan Date should not be less than current Date.";
	    	}
	    	else
	    	{
	    	scheduleTrngalert.hide();
	    	$scope.scheduleTrngMessage = "";
	    	var tempSubject = $scope.selectedOption.topic;
	    	var tempLocation = $scope.location;
	    	var tempStartDate = $scope.plandate; 		//07/19/2016
	    	var tempyr = tempStartDate.slice(-4);
	    	var tempmnth = tempStartDate.substring(0,2);
	    	var tempdy = tempStartDate.substring(3,5);
	    	var tempStartTime	= $scope.starttime;  	//9:00am
	    	var tempmin = tempStartTime.slice(-4,-2);
	    	var temphr = tempStartTime.substring(0,tempStartTime.indexOf(':'));

	    	if(tempStartTime.slice(-2) == 'am')
	    	{
	    		if(temphr.length == 1)
	    		{
	    			var StartDate = tempyr + tempmnth + tempdy + 'T0' + temphr + tempmin + 00;
	    		}
	    		else
	    		{
	    			var StartDate = tempyr + tempmnth + tempdy + 'T' + temphr + tempmin + 00;
	    		}
	    	}
	    	else
	    	{
    			var StartDate = tempyr + tempmnth + tempdy + 'T0' + (12 + parseInt(temphr)) + tempmin + 00;
	    	}
	    	
	    	eventData.push({
	            topic: $scope.selectedOption.topic,
	            plandate: $scope.plandate,
	            starttime: $scope.starttime,
	            duration: $scope.duration,
	            location: $scope.location,
	            status: $scope.status,
	            trainer: $scope.Trainer            
	          });
	    	
	    	$http.post("InsertToCalendar", eventData).success(function(response){
	    		
	    		$scope.clearInputs();
	        	$scope.events.splice(0, $scope.events.length);  //clear events array
	        	$scope.retrieveEvent();
	    		scheduleTrngalert.show();
	    		$scope.scheduleTrngMessage = "Successfully added";
		    	var icsMSG = "BEGIN:VCALENDAR\n" +
    			"VERSION:2.0\n" +
    			"BEGIN:VEVENT\n" +
    			"UID:sreeja.sudhakaran@cognizant.com\n" +
    			"DTSTART:"+StartDate+"\n" +
    			"LOCATION:"+tempLocation+"\n" +
    			"SUMMARY:"+tempSubject+"\n" +
    			"END:VEVENT\n" +
    			"END:VCALENDAR";
		    	window.open( "data:text/calendar;charset=utf8," + escape(icsMSG));
	    		
	    	})
	    	.error(function(data, status) {
	    		if (status == 406)
	    		{
	    			scheduleTrngalert.show();
	    			$scope.scheduleTrngMessage = "Training is not Scheduled, since there is an overlap with an existing training";
	    		}
	    		else if (status == 405)
	        	{
	    			scheduleTrngalert.show();
	    			$scope.scheduleTrngMessage = "Invalid Trainer ID";
	        	}
	    		else
	    		{
	    			scheduleTrngalert.show();
	    			$scope.scheduleTrngMessage = "Failed due to technical issues. Please contact the Administrator.";
	    		}
			});
	    }
    	}
    }

    
    //To Add New Training Topics
    $scope.OnAddTrainingClick = function()
    {
    	miscellaneousalert.hide();
    	$scope.miscellaneousMessage = "";
    	
    	if($scope.newTopicOne == "" && $scope.newTopicTwo =="" && $scope.newTopicThree=="" && $scope.newTopicFour=="" && $scope.newTopicFive=="")
    	{
    		miscellaneousalert.show();
    		$scope.miscellaneousMessage = "Atleast one Topic should be added.";
    	}
    	else if($scope.addArea =="existingArea")
    	{
    		if($scope.newTopicOne != "")
		    {
		    	newTrainingData.push({
		    		area: $scope.existingArea.area,
		    		functarea: $scope.existingFunctionalArea,
		    		Topic: $scope.newTopicOne
		    	});  
		    }
		    if($scope.newTopicTwo != "")
		    {
		    	newTrainingData.push({
		    		area: $scope.existingArea.area,
		    		functarea: $scope.existingFunctionalArea,
		    		Topic: $scope.newTopicTwo
		    	});  
		    }
		    if($scope.newTopicThree != "")
		    {
		    	newTrainingData.push({
		      	area: $scope.existingArea.area,
		      	functarea: $scope.existingFunctionalArea,
		       	Topic: $scope.newTopicThree
		       	});  
		    }
		    if($scope.newTopicFour != "")
		    {
		    	newTrainingData.push({
		    	area: $scope.existingArea.area,
		    	functarea: $scope.existingFunctionalArea,
		    	Topic: $scope.newTopicFour
		    	});  
		    }
		    if($scope.newTopicFive != "")
		    {
		    	newTrainingData.push({
		    	area: $scope.existingArea.area,
		    	functarea: $scope.existingFunctionalArea,
		    	Topic: $scope.newTopicFive
		    	});
		    }
		    $scope.AddNewTrainingAreaAndTopics(newTrainingData);
    	}
	    else if($scope.addArea == "newArea")
	    {
	    	if($scope.newAreaToAdd != "")
	    	{
	    		if($scope.newTopicOne != "")
	    		{
		       		newTrainingData.push({
		       		area: $scope.newAreaToAdd,
		       		functarea: $scope.functionalAreaSelected.functArea,
		       		Topic: $scope.newTopicOne
		       		});  
		       	}
		       	if($scope.newTopicTwo != "")
		       	{
		       		newTrainingData.push({
		       		area: $scope.newAreaToAdd,
		       		functarea: $scope.functionalAreaSelected.functArea,
		       		Topic: $scope.newTopicTwo
		       		});  
		       	}
		       	if($scope.newTopicThree != "")
		       	{
		       		newTrainingData.push({
		       		area: $scope.newAreaToAdd,
		       		functarea: $scope.functionalAreaSelected.functArea,
		       		Topic: $scope.newTopicThree
		       		});  
		       	}
		       	if($scope.newTopicFour != "")
		       	{
		       		newTrainingData.push({
		       		area: $scope.newAreaToAdd,
		       		functarea: $scope.functionalAreaSelected.functArea,
		       		Topic: $scope.newTopicFour
		       		});  
		       	}
		       	if($scope.newTopicFive != "")
		       	{
		       		newTrainingData.push({
		       		area: $scope.newAreaToAdd,
		       		functarea: $scope.functionalAreaSelected.functArea,
		       		Topic: $scope.newTopicFive
		       		});
		       	}
		       	$scope.AddNewTrainingAreaAndTopics(newTrainingData);
	       	}
	    	else
	    	{
				miscellaneousalert.show();
				$scope.miscellaneousMessage = "Enter new Training Area";
	    	}
    	}
	    else if($scope.addArea == "newFunctArea")
	    {
	    	if($scope.newFunctAreaInput == "")
	    	{
				miscellaneousalert.show();
				$scope.miscellaneousMessage = "Enter new Functional Area";
	    	}
	    	else if($scope.newAreaToAdd == "")
	    	{
				miscellaneousalert.show();
				$scope.miscellaneousMessage = "Enter new Training Area";
	    	}
	    	else
	    	{
	    		if($scope.newTopicOne != "")
	    		{
		       		newTrainingData.push({
		       		area: $scope.newAreaToAdd,
		       		functarea: $scope.newFunctAreaInput,
		       		Topic: $scope.newTopicOne
		       		});  
		       	}
		       	if($scope.newTopicTwo != "")
		       	{
		       		newTrainingData.push({
		       		area: $scope.newAreaToAdd,
		       		functarea: $scope.newFunctAreaInput,
		       		Topic: $scope.newTopicTwo
		       		});  
		       	}
		       	if($scope.newTopicThree != "")
		       	{
		       		newTrainingData.push({
		       		area: $scope.newAreaToAdd,
		       		functarea: $scope.newFunctAreaInput,
		       		Topic: $scope.newTopicThree
		       		});  
		       	}
		       	if($scope.newTopicFour != "")
		       	{
		       		newTrainingData.push({
		       		area: $scope.newAreaToAdd,
		       		functarea: $scope.newFunctAreaInput,
		       		Topic: $scope.newTopicFour
		       		});  
		       	}
		       	if($scope.newTopicFive != "")
		       	{
		       		newTrainingData.push({
		       		area: $scope.newAreaToAdd,
		       		functarea: $scope.newFunctAreaInput,
		       		Topic: $scope.newTopicFive
		       		});
		       	}
		       	$scope.AddNewTrainingAreaAndTopics(newTrainingData);
	       	}
	    }
    }
    
    $scope.AddNewTrainingAreaAndTopics = function(data)
    {    	
	    $http.post("AddNewTrainingurl", data).success(function(response)
	    	    {    	
	    	    	//To get the topics available in Tbl_Training_Topics table.
	    	    	$http.get("getUserInfo").then(function(response) 
	    	    		{
	    	    			if (response == "")
	    	    			{
	    	    				miscellaneousalert.show();
	    	    				$scope.miscellaneousMessage = "Training topics are not available.";
	    	    			}
	    	    			if (response == 403)
	    	    			{
	    	    				miscellaneousalert.show();
	    	    				$scope.miscellaneousMessage = "Failed due to technical issues. Please contact the Administrator."; 
	    	    			}
	    	    			else
	    	    			{
	    	    				$scope.AvailableTopics = response.data;
	    	    				$scope.selectedOption = $scope.AvailableTopics[0];
	    	    				$scope.SelectedArea = $scope.AvailableTopics[0].Area;
	    	    				$scope.SelectedFunctionalArea = $scope.AvailableTopics[0].FunctionalArea;
	    	    				$scope.getAvailableAreaOnLogin();
	    	    			}
	    	    		});
	    	    	$scope.OnClearTrainingClick();
	    	    	miscellaneousalert.show();
	    	    	$scope.miscellaneousMessage = "Successfully added.";    	
	    	    })
	    	    .error(function(data, status) {
	    			if (status == 403)
	    			{
	    				miscellaneousalert.show();
	    				$scope.miscellaneousMessage = "Failed due to technical issues. Please contact the Administrator."; 
	    			}
	    			else {
	    				miscellaneousalert.show();
	    				$scope.miscellaneousMessage = "Server is unvailable"; 
	    			}
	    		});
    }
    
   
    //To update the training attendance to database by trainee
    $scope.OnRecordAddUpdate = function()
    {
    	var updatedData = [];
    	updatedData.push({
            topic: $scope.SelectedRecordTopic.topic,
            plandate: $scope.SelectedRecordTopic.plannedDate,
            attendancestatus: $scope.attendanceStatus,
            userid: $scope.username
          });
    	
    	if($scope.SelectedRecordTopic.topic == null || $scope.SelectedRecordTopic.plannedDate == null || $scope.SelectedRecordTopic.topic == "" || $scope.SelectedRecordTopic.plannedDate == "")
    	{
    		indUpdAlert.show();
    		$scope.individualUpdateMessage = "All fields are Mandatory.";
    	}
    	else
    	{
	    	$http.post("AddUpdateRecordStatusurl", updatedData).success(function(response)
	    	{
	    		$scope.clearRecordInputs();
	    		indUpdAlert.show();
	    		$scope.individualUpdateMessage = "Successfully updated.";
	    	})
	    	.error(function(data, status) {
				if (status == 403)
				{
					indUpdAlert.show();
					$scope.individualUpdateMessage = "Failed due to technical issues. Please contact the Administrator."; 
				}
				else {
					indUpdAlert.show();
					$scope.individualUpdateMessage = "Server is unvailable"; 
				}
			});
    	}
    }
    
    //To update the current training status to database by Trainer
    $scope.onUpdateCancelClick = function(){    	
    	var updatedData = [];
    	var inputfieldStatus = true; //sreeja
    	
    	GetCurrentDate();
    	
     	var actualDateStatus = $scope.validateDateFieldmmddyyyy($scope.updatedDate); //sreeja
    	
    	if (actualDateStatus == false) //sreeja
    	{
    		inputfieldStatus = false;
    		updateTrnStsalert.show();
    		$scope.updateTrnStsMessage = "Invalid Actual Training Date. Valid Date format is mm/dd/yyyy";
    	}
    	
    	if(inputfieldStatus)
    	{
	    	if ($scope.updatedDate > currentdate && $scope.updatedStatus == "Completed")
	    	{
	    		updateTrnStsalert.show();
	    		$scope.updateTrnStsMessage = "Actual Training date should not be a future date";
	    	}
	    	else
	    	{
		    	if ($scope.updatedDate > currentdate && $scope.updatedStatus == "Completed")
		    	{
		    		updateTrnStsalert.show();
		    		$scope.updateTrnStsMessage = "Actual Training date should not be a future date";
		    	}
		    	else
		    	{  		
		    	updatedData.push({
		            topic: $scope.SelectedTrainerTopic.topic,
		            plandate: $scope.SelectedDate,
		            updateddate:$scope.updatedDate,
		            updatedduration: $scope.updatedDuration,
		            updatedstatus: $scope.updatedStatus,
		            trainer: $scope.username            
		          });
				updateTrnStsalert.hide();
				$scope.updateTrnStsMessage = "";
		    	$http.post("UpdateCancelTrainingStatusurl", updatedData).success(function(response){
		    		$scope.clearUpdateInputs();
		        	$scope.events.splice(0, $scope.events.length);  //clear events array
		        	$scope.retrieveEvent();
		    		updateTrnStsalert.show();
		    		$scope.updateTrnStsMessage = "Status successfully updated";
		    	})
		    	.error(function(data, status) {
					if (status == 403)
					{
						updateTrnStsalert.show();
						$scope.updateTrnStsMessage = "Failed due to technical issues. Please contact the Administrator."; 
					}
		    		else {
		    			updateTrnStsalert.show();
		    			$scope.updateTrnStsMessage = "Server is unvailable"; 
		    		}
				}); 	
		    	}
	    	}
    	}
    }

    //To show the planned training data on calendar.
    $scope.events.splice(0, $scope.events.length);  //clear events array

	//To get the calendar data available in Tbl_Training_Calendar table.
    $scope.retrieveEvent = function() {
		$http.get("getSchdTrngInfo").success(function(response) 
		{
			if (response == "")
				{
					window.alert("There are no training scheduled.")
				}
			else
				{
					var temp = response;
					
					for(i = 0; i < temp.length; i++)
					{
						var obj = temp[i];
						var tempTime = obj["start"];
						var from = tempTime.split("-");
						var starttime = obj["starttime"];
						var hr = starttime.substr(0, 2);
						var min = starttime.substr(3, 2);
						
						$scope.events.push({
							title: obj["title"],
							start: new Date(from[0], from[1] - 1, from[2], hr, min), 
							end: new Date(from[0], from[1] - 1, from[2]),
							starttime: obj["starttime"],
							area: obj["schdTrngArea"],
							funcarea: obj["schdFuncArea"],
							duration: obj["schdTrngHrs"],
							status: obj["schdTrngSts"],
							location: obj["schdTrngLoc"],
							trainer: obj["schdTrngTrnr"]			
						});
					}			
				}
		})
		.error(function(data, status) {
			if (status == 403)
			{
				window.alert("Failed due to technical issues. Please contact the Administrator."); 
			}
			else
			{
				window.alert("Server is unvailable"); 
			}
		});
	};
	
	$scope.retrieveEvent();
	
	//To draw the Calendar when click on Academy tab.
	$scope.OnClickAcademy = function()
	{	
		$timeout(function() {
			$("#calendar").fullCalendar('render');
	  	  },400);
	}	
	
	//To draw the Calendar when click on Calendar tab.
	$scope.onClickCalendarTab = function()
	{	
		$timeout(function() {
			$("#calendar").fullCalendar('refetchEvents');
	  	  }, 400);
		
		//$("#calendar").fullCalendar('render');
	}

	//To clear the attendance inputs from the page
	$scope.clearRecordInputs = function()
	{
		$scope.trainingRecord = [];
		$scope.SelectedDateToRecord = "";
		$scope.attendanceStatus = "Attended";
		$scope.individualUpdateMessage = ""; //sreeja
		indUpdAlert.hide(); //sreeja
	}
	
	//To delete the skill set
	$scope.OnNewSkillDelete = function(data)
	{
		var skillDetails = [];
		var currentStream = $scope.SelectedStream.stream;
    	
		skillDetails.push({
			stream : currentStream,
			skillName : data.Name,
			skillDetail : data.Info,
			comp : data.competency
               });
		
		addSkillAlert.hide();
		$scope.addSkillMessage = "";
		if(window.confirm("Are you sure you want to delete the Skillset?"))
		{
			$http.post("SkillDelete",skillDetails).success(function(response){
				
				addSkillAlert.show();
				$scope.addSkillMessage = "Skillset successfully deleted";
				
				$scope.GetExistingSkillDetails(currentStream);
			})
			.error(function(data,status){
				addSkillAlert.show();
				$scope.addSkillMessage = "Failed due to technical issues. Please contact the Administrator";
			});
		}		
	}
	
	var rowCounts = 0;
	$scope.newSkillRow = [];
	$scope.Row = false;
	//To add New Rows to enter new Skill details
	$scope.OnNewSkillAddRow = function()
	{
		rowCounts = rowCounts + 1;
		$scope.Row = true;
		
		$scope.newSkillRow.push({Name: "",Info: "",competency:""});
	}
	
	//To clear a newly added row from the web page
	$scope.OnNewRowDelete = function(index)
	{
		$scope.newSkillRow.splice(index,1);
		rowCounts = rowCounts - 1;
		if(rowCounts == 0)
			{
				$scope.Row = false;
			}
	}
	
	//To Add the new Skill details to database
	$scope.OnClickSkillAdd = function(data)
	{
		var newSkillDetails = [];
		var currentStream = $scope.SelectedStream.stream;
    	var count = data.length;
		for(var i=0;i<count;i++)
		{
			newSkillDetails.push({
				stream : currentStream,
				skillName : data[i].Name,
				skillDetail : data[i].Info,
				comp : data[i].competency
	               });
		}
		addSkillAlert.hide();
		$scope.addSkillMessage = "";
		$http.post("SkillAdd",newSkillDetails).success(function(response){
			addSkillAlert.show();
			$scope.addSkillMessage = "Skillset added successfully";

			$scope.newSkillRow = [];
			$scope.Row = false;
			$scope.GetExistingSkillDetails(currentStream);
		})
		.error(function(data,status){
			addSkillAlert.show();
			$scope.addSkillMessage = "Failed due to technical issues. Please contact the Administrator";
		});
		
	}
	
	//To clear the Add New Topic screen data
	$scope.OnClearTrainingClick = function()
	{
    	$scope.countOne = false;
    	$scope.countTwo = false;
    	$scope.countThree = false;
    	$scope.countFour = false;
    	$scope.countFive = false;    		
    	$scope.addArea = "existingArea";
		$scope.existingArea = $scope.AvailableArea[0];
		$scope.existingFunctionalArea = $scope.existingArea.functionalarea;
		$scope.newAreaToAdd = "";
		$scope.functionalAreaSelected = $scope.AllFunctionalArea[0];
		$scope.newFunctAreaInput = "";
    	$scope.topicCount = [];
    	$scope.newTopicOne = "";
    	$scope.newTopicTwo = "";
    	$scope.newTopicThree = "";
    	$scope.newTopicFour = "";
    	$scope.newTopicFive = "";
    	$scope.newArea = "";
	}
	
	
	//To clear the data from the input fields in the Calendar Add to Calendar panel.
	$scope.clearInputs=function(){
		$scope.duration = "";
		$scope.plandate = "";
		$scope.starttime ="";
		$scope.location="";
		$scope.status = "Yet to start";
		$scope.Trainer = "";
		}
	
	
	//To clear the data from Schedule training tab.
	$scope.clearScheduleClick=function(){
		
        $scope.plandate = "";
        $scope.starttime = "";
        $scope.duration = "0:30";
        $scope.location = "";
        $scope.status = "Yet to start";
        $scope.Trainer = "";
		scheduleTrngalert.hide(); //sreeja
		$scope.scheduleTrngMessage = ""; //sreeja
	}
	
	//To clear the Report Data if the inputs are invalid.
	   function clearReportData()
	   {
		   $scope.reportHeader = "";
		   $scope.reportShown = false;
		   $scope.tempReportData = [];
		   $scope.tempAttendanceReportData = [];
		   $scope.tempAttendancePerFuncAreaReportData = [];		   
		   $scope.curPage = 0;
		   reportalert.hide(); //sreeja
		   $scope.reportMessage = "";  //sreeja
	   }
	
	//To clear the data from Update Training Status page, once the status is updated by the trainer.
	$scope.clearUpdateInputs=function(){
		$scope.SelectedDate="";
		$scope.SelectedTrainerTopic.area = "";
		$scope.SelectedTrainerTopic.functionalarea = "";
		$scope.SelectedTrainerTopic.Status = "";
		$scope.SelectedTrainerTopic.duration = "";
		$scope.updatedDate="";
        $scope.updatedDuration=$scope.hours[0];
        $scope.updatedStatus="Completed";
        $scope.trainingData = [];
	}
    
    /* remove event */
    $scope.remove = function(index) {
      $scope.events.splice(index,1);
    };
    
    /* Change View */
    $scope.changeView = function(view,calendar) {
      uiCalendarConfig.calendars[calendar].fullCalendar('changeView',view);
    };
    
    /* Change View */
    $scope.renderCalender = function(calendar) {
      $timeout(function() {
        if(uiCalendarConfig.calendars[calendar]){
          uiCalendarConfig.calendars[calendar].fullCalendar('render');
        }
      });
    };
    
   //To get the dynamic value in training Area and plan date
   $scope.changedTrainingValue=function(trainingitem){
		$scope.trainnigArea = trainingitem.Area;
		$scope.trainnigplandate = trainingitem.planneddate;
   };
    
    /* Render Tooltip */
    $scope.eventRender = function( event, element, view ) {
        element.attr({'tooltip': event.title,
                      'tooltip-append-to-body': true});
        $compile(element)($scope);
    };
    
    /* config object */
    $scope.uiConfig = {
      calendar:{
        height: 450,
        editable: true,
        header:{
          left: 'title',
          center: '',
          right: 'today prev,next'
        },
        eventClick: $scope.alertOnEventClick,
        eventDrop: $scope.alertOnDrop,
        eventResize: $scope.alertOnResize,
        eventRender: $scope.eventRender
      }
    };

    $scope.changeLang = function() {
      if($scope.changeTo === 'Hungarian'){
        $scope.uiConfig.calendar.dayNames = ["Vasárnap", "Hétfő", "Kedd", "Szerda", "Csütörtök", "Péntek", "Szombat"];
        $scope.uiConfig.calendar.dayNamesShort = ["Vas", "Hét", "Kedd", "Sze", "Csüt", "Pén", "Szo"];
        $scope.changeTo= 'English';
      } else {
        $scope.uiConfig.calendar.dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
        $scope.uiConfig.calendar.dayNamesShort = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
        $scope.changeTo = 'Hungarian';
      }
    };
    
    /* event sources array*/
    $scope.eventSources = [$scope.events, $scope.eventSource, $scope.eventsF];
    $scope.eventSources2 = [$scope.calEventsExt, $scope.eventsF, $scope.events];
    
    
    /* Input field validation Scripts starts here */
    /* ------------------------------------------ */
    
    //Email ID field validation
    $scope.validateEmailField = function(inputemailid)
    {
    	var status =false;
    	var tempmatch = inputemailid.match(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/);
    	
    	if (tempmatch != null)//Basic check for valid date format
    	{
    		status = true;
    	}
    	return status;
    }
    
    //Designation and Stream field validation
    $scope.validateStringField = function(inputstring)
    {
    	var status =false;
    	var tempmatch = inputstring.match(/^[a-zA-Z0-9 -]{1,100}$/);
    	
    	if (tempmatch != null)//Basic check for valid date format
    	{
    		status = true;
    	}
    	return status;
    }
    
    //Employee Name field validation
    $scope.validateEmpNameField = function(inputName)
    {
    	var status =false;
    	var tempmatch = inputName.match(/^[a-zA-Z0-9,'"\. ]{2,100}$/);
    	
    	if (tempmatch != null)//Basic check for valid date format
    	{
    		status = true;
    	}
    	return status;
    }
    
    //Employee ID validation
    $scope.validateEmpIDSearchField = function(inputempid)
    {
    	var status =false;
    	var tempmatch = inputempid.match(/^[0-9]+$/);
    	
    	if (tempmatch != null)//Basic check for valid date format
    	{
    		status = true;
    	}
    	
    	return status; 
    	//return true;
    }
    
    //Trainer EmpID field validation
    $scope.validateTrnrEmpIDField = function(inputTrnr) //sreeja
    {
    	var status =false;
  	
    	if (inputTrnr >= 0)//Basic check for valid date format
    	{
    		status = true;
    	}
    	return status; 
    }
    
    //Time Field validation
    $scope.validateTimeField = function(inputTime) //sreeja
    {
    	var status =false;
    	var tempmatch = inputTime.match(/^\d{1,2}:\d{2}([ap]m)?$/);
    	
    	if (tempmatch != null)//Basic check for valid date format
    	{
    		status = true;
    	}
    	return status; 
    }
    
    //Date Field validation
    $scope.validateDateFieldmmddyyyy = function(inputdate) //sreeja
    {
    	var status =false;
    	var tempmatch = inputdate.match(/^\d{2}\/\d{2}\/\d{4}$/); //Basic check for valid date format
    	
    	if (tempmatch != null)//Detailed check for valid date ranges
    	{ 
    		var monthfield=inputdate.split("/")[0];
    		var dayfield=inputdate.split("/")[1];
    		var yearfield=inputdate.split("/")[2];
    		
    		var dayobj = new Date(yearfield, monthfield-1, dayfield);
    	
    		if ((dayobj.getMonth()+1!=monthfield)||(dayobj.getDate()!=dayfield)||(dayobj.getFullYear()!=yearfield))
    			status = false;
    		else
    			status=true;
    	}
    	return status; 	
    }
    
}

//Pagination
function pagination()
{
	return function(input, start)
	 {
		if (!input || !input.length) 
			{ return; }
		start = +start;
		return input.slice(start);
	 };
}
/* EOF */