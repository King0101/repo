/**
 * loginApp - 0.9.0
 */
angular.module('loginApp', ['ui.calendar', 'ui.bootstrap'])
        .controller('LoginCtrl', LoginCtrl);

function LoginCtrl($scope,  $compile, $timeout, uiCalendarConfig, $http, $window) {
	$scope.loginresponse="";
    $scope.loginstatus = false;
	$scope.adminuser = false;
	var lngth = 0;
	var loginiddata="";
	var roledata="";
	
	//Login
	 $scope.login = function() {
		var logindata = [];
    	logindata.push({
            loginid: $scope.loginidtxt,
            passwordtxt: $scope.passwordtxt            
          }); 	
    	$http.post("loginurl", logindata).success(function(response){
    		$scope.loginresponse = response;
    		loginiddata=$scope.loginresponse[0].loginres;
    		roledata=$scope.loginresponse[0].role;
    		if(loginiddata == "")
    			{
    			$scope.loginstatus = false;
    			}
    		else
    			{
    			$scope.loginstatus = true;
    			if (roledata == "Normal")
    				{
    				$scope.adminuser = false;
    				}
    			else
    				{
    				$scope.adminuser = true;
    				}
    			$window.location = "/calendar.html";
    			}
    	})
    	.error(function(data, status) {
    		$scope.message = "Error in Login!!!!"
		})
    };		
}
/* EOF */